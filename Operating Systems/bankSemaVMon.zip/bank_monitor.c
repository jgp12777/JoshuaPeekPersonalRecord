#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>

#define NUM_CUSTOMERS 5
#define NUM_TRANSACTIONS 10

typedef struct {
    double balance;
    pthread_mutex_t lock;
} BankAccount;

BankAccount account;

void deposit(int id, double amount) {
    pthread_mutex_lock(&account.lock);
    account.balance += amount;
    printf("Customer %d deposited $%.2f. New balance: $%.2f\n", id, amount, account.balance);
    pthread_mutex_unlock(&account.lock);
}

void withdraw(int id, double amount) {
    pthread_mutex_lock(&account.lock);
    if (account.balance >= amount) {
        account.balance -= amount;
        printf("Customer %d withdrew $%.2f. New balance: $%.2f\n", id, amount, account.balance);
    } else {
        printf("Customer %d failed to withdraw $%.2f due to insufficient funds. Balance: $%.2f\n", id, amount, account.balance);
    }
    pthread_mutex_unlock(&account.lock);
}

void *customer(void *arg) {
    int id = *(int *)arg;
    for (int i = 0; i < NUM_TRANSACTIONS; i++) {
        int action = rand() % 2; // Randomly choose between deposit (1) and withdrawal (0)
        double amount = (rand() % 100) + 1; // Amount between $1 and $100

        if (action) {
            deposit(id, amount);
        } else {
            withdraw(id, amount);
        }

        usleep(1000); // Simulate processing time
    }
    pthread_exit(NULL);
}

int main() {
    pthread_t threads[NUM_CUSTOMERS];
    int thread_ids[NUM_CUSTOMERS];

    account.balance = 1000.0;
    pthread_mutex_init(&account.lock, NULL);

    for (int i = 0; i < NUM_CUSTOMERS; i++) {
        thread_ids[i] = i + 1;
        pthread_create(&threads[i], NULL, customer, &thread_ids[i]);
    }

    for (int i = 0; i < NUM_CUSTOMERS; i++) {
        pthread_join(threads[i], NULL);
    }

    pthread_mutex_destroy(&account.lock);

    printf("Final balance: $%.2f\n", account.balance);
    return 0;
}
