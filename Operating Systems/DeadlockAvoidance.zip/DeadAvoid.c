#include <stdio.h>
#include <pthread.h>
#include <stdlib.h>
#include <unistd.h>
#include <time.h>
//Joshua Peek 21081733 cst315
// Mutex to represent a shared resource
pthread_mutex_t resource_lock;
FILE *activity_log;

void *process_function(void *arg) {
    int process_id = *((int *)arg);
    time_t start_time, current_time;
    int is_starved = 0;
    
    // Log process starting
    fprintf(activity_log, "Process %d: started\n", process_id);

    // Start timer
    time(&start_time);

    while (1) {
        // Try to lock the resource
        if (pthread_mutex_trylock(&resource_lock) == 0) {
            fprintf(activity_log, "Process %d: accessing resource\n", process_id);
            sleep(2); // Simulate resource usage
            pthread_mutex_unlock(&resource_lock);
            fprintf(activity_log, "Process %d: released resource\n", process_id);
            break;
        } else {
            // Check if process is starved
            time(&current_time);
            if (difftime(current_time, start_time) > 5) { // 5-second starvation threshold
                fprintf(activity_log, "Process %d: starved, restarting\n", process_id);
                is_starved = 1;
                break;
            } else {
                fprintf(activity_log, "Process %d: waiting for resource\n", process_id);
                sleep(1);
            }
        }
    }
    
    if (is_starved) {
        // Restart the process
        process_function(arg);
    }

    pthread_exit(NULL);
}

int main() {
    pthread_t processes[5];
    int process_ids[5];
    activity_log = fopen("activity_log.txt", "w");

    if (pthread_mutex_init(&resource_lock, NULL) != 0) {
        printf("Mutex init failed\n");
        return 1;
    }

    // Create processes
    for (int i = 0; i < 5; i++) {
        process_ids[i] = i + 1;
        pthread_create(&processes[i], NULL, process_function, &process_ids[i]);
    }

    // Wait for processes to finish
    for (int i = 0; i < 5; i++) {
        pthread_join(processes[i], NULL);
    }

    pthread_mutex_destroy(&resource_lock);
    fclose(activity_log);
    
    return 0;
}
