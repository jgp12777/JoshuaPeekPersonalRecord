#!/bin/bash

# 1. whoami: Display the current user
echo "Current user (whoami):"
whoami
echo ""

# 2. users: Show which users are logged into the system
echo "Users currently logged in (users):"
users
echo ""

# 3. ls: List files with additional arguments
echo "Listing files in the current directory (ls -lah):"
ls -lah
echo ""

# 4. chmod: Change file permissions (creating a test file first)
echo "Creating a test file and changing its permissions (chmod u+rwx):"
touch testfile.txt
chmod u+rwx testfile.txt
ls -l testfile.txt
echo ""

# 5. echo: Check the value of three environment variables
echo "Checking environment variables (HOME, PATH, SHELL):"
echo "HOME: $HOME"
echo "PATH: $PATH"
echo "SHELL: $SHELL"
echo ""

# 6. grep: Search for specific content in a file
echo "Searching for the word 'Hello' in testfile.txt using grep:"
echo "Hello World!" > testfile.txt
grep "Hello" testfile.txt
echo ""

# 7. sort, grep, piping: Search for a string in files and sort the output
echo "Using grep and sort to search for 'Hello' and sort the results:"
echo "Hello again!" >> testfile.txt
echo "Another Hello" >> testfile.txt
grep "Hello" testfile.txt | sort
echo ""

# 8. sudo su: Explain superuser (superuser action skipped for script safety)
echo "The superuser (sudo su) would be used to perform admin tasks like installing software or changing system settings. You typically use 'sudo' before commands to temporarily gain superuser privileges."
echo ""

# 9. man: Explore five additional commands using the manual (only listed in the script for practical reasons)
echo "Use the 'man' command to explore other useful Linux commands:"
echo "Try 'man ls', 'man ps', 'man df', 'man du', and 'man top' in your terminal."
echo ""

# 10. Shell script test.sh running five different commands
echo "Running five different commands inside this script:"
echo "1. whoami"
whoami
echo "2. ls -l"
ls -l
echo "3. df -h"
df -h
echo "4. echo \$PATH"
echo $PATH
echo "5. grep 'Hello' in testfile.txt"
grep "Hello" testfile.txt
