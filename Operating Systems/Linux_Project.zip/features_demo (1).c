#include <stdio.h>
#include <stdlib.h>
#include <dirent.h>
#include <pwd.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <errno.h>

// Function to list files in the current directory
void list_files() {
    struct dirent *de; // Pointer for directory entry
    DIR *dr = opendir(".");
  
    if (dr == NULL) {  // opendir returns NULL if couldn't open directory
        perror("Could not open current directory");
        return;
    }

    printf("\nFiles in the current directory:\n");
    while ((de = readdir(dr)) != NULL) {
        printf("%s\n", de->d_name);
    }
    closedir(dr);
}

// Function to display the current user's name
void show_user() {
    struct passwd *pw;
    uid_t uid = geteuid();  // Get user ID
    pw = getpwuid(uid);     // Get password structure based on user ID

    if (pw) {
        printf("\nCurrent user: %s\n", pw->pw_name);
    } else {
        perror("getpwuid");
    }
}

// Function to display running processes
void show_processes() {
    printf("\nRunning processes:\n");
    system("ps");  // Execute 'ps' command to show running processes
}

// Function to check and change file permissions
void check_file_permissions(const char *filename) {
    struct stat fileStat;
    
    if (stat(filename, &fileStat) < 0) {
        perror("Could not retrieve file status");
        return;
    }
    
    printf("\nFile: %s\n", filename);
    printf("File Permissions: \n");
    printf("User: Read(%c) Write(%c) Execute(%c)\n",
           (fileStat.st_mode & S_IRUSR) ? 'Y' : 'N',
           (fileStat.st_mode & S_IWUSR) ? 'Y' : 'N',
           (fileStat.st_mode & S_IXUSR) ? 'Y' : 'N');

    printf("Do you want to change file permissions? (y/n): ");
    char choice;
    scanf(" %c", &choice);
    
    if (choice == 'y' || choice == 'Y') {
        printf("Changing file to read-only for the owner.\n");
        if (chmod(filename, S_IRUSR) < 0) {
            perror("Error changing permissions");
        } else {
            printf("Permissions changed successfully.\n");
        }
    }
}

// Function to display environment variables
void show_env_var(const char *var_name) {
    char *var_value = getenv(var_name);
    if (var_value) {
        printf("\n%s: %s\n", var_name, var_value);
    } else {
        printf("%s not found.\n", var_name);
    }
}

int main() {
    // List files in the current directory
    list_files();

    // Show current user
    show_user();

    // Display running processes
    show_processes();

    // Check and change file permissions
    const char *filename = "testfile.txt";
    FILE *fp = fopen(filename, "w");
    if (fp == NULL) {
        perror("Failed to create test file");
    } else {
        fprintf(fp, "This is a test file.\n");
        fclose(fp);
        check_file_permissions(filename);
    }

    // Display environment variables
    show_env_var("HOME");
    show_env_var("PATH");
    show_env_var("SHELL");

    return 0;
}
