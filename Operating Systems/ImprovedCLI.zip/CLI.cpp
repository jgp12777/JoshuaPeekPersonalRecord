#include <iostream>     // For input/output operations
#include <sys/types.h>   // For data types used in system calls
#include <sys/wait.h>    // For waitpid() to make the parent wait for child processes
#include <unistd.h>      // For fork(), execvp(), and other POSIX functions
#include <vector>        // For using vectors to store command arguments
#include <string.h>      // For string manipulation (strtok)
#include <fstream>       // For reading from batch files

using namespace std;

// Function to handle command chaining by splitting input on ';'
vector<string> splitBySemicolon(const string &input) {
    vector<string> commands;
    size_t start = 0, end = 0;
    while ((end = input.find(';', start)) != string::npos) {
        commands.push_back(input.substr(start, end - start));
        start = end + 1;
    }
    commands.push_back(input.substr(start));
    return commands;
}

// Function to check if the command is 'ls' and add '-F' to the arguments for file type indicators
bool isLSCommandWithFlag(vector<char*> &args) {
    if (strcmp(args[0], "ls") == 0) {
        // Append the -F flag to the ls command for file type indicators
        args.push_back((char*)"-F");
        return true;
    }
    return false;
}

// Function to parse a command input into arguments
vector<char*> parseCommand(const string &command) {
    vector<char*> args;
    char* token = strtok(const_cast<char*>(command.c_str()), " ");
    while (token != nullptr) {
        args.push_back(token);
        token = strtok(nullptr, " ");
    }
    args.push_back(nullptr);  // Null-terminate the argument list for execvp
    return args;
}

// Function to handle multiple commands in sequence
void handleMultipleCommands(const string &command) {
    vector<string> command_list = splitBySemicolon(command);
    for (const string& single_command : command_list) {
        vector<char*> args = parseCommand(single_command);

        // Check if it's an ls command and append '-F'
        isLSCommandWithFlag(args);

        if (args.empty()) {
            continue;
        }

        pid_t pid = fork();
        if (pid == -1) {
            perror("fork failed");
            exit(1);
        } else if (pid == 0) {
            if (execvp(args[0], args.data()) == -1) {
                perror("Command execution failed");
                exit(1);
            }
        } else {
            wait(nullptr);
        }
    }
}

// Batch file processing function to execute commands in sequence
void processBatchFile(const string &filename) {
    ifstream batchFile(filename);
    string line;
    if (!batchFile) {
        cerr << "Error: Cannot open batch file " << filename << endl;
        return;
    }

    while (getline(batchFile, line)) {
        cout << "SlopeShell > " << line << endl;
        handleMultipleCommands(line);
    }
}

// Main function for the shell
void shellLoop(bool isBatchMode = false, const string &batchFilename = "") {
    string command;

    if (isBatchMode) {
        processBatchFile(batchFilename);
    } else {
        while (true) {
            cout << "SlopeShell > ";
            getline(cin, command);

            if (command == "quit") {
                break;
            }

            handleMultipleCommands(command);
        }
    }
}
// Function to handle the 'cd' command for changing directories
bool isCDCommand(vector<char*> &args) {
    if (strcmp(args[0], "cd") == 0) {
        if (args.size() == 1) {
            // If no directory is specified, go to the home directory
            const char* home = getenv("HOME");
            if (home == nullptr) {
                cerr << "cd: HOME environment variable not set" << endl;
            } else {
                if (chdir(home) != 0) {
                    perror("cd");
                }
            }
        } else if (chdir(args[1]) != 0) {
            // If the directory is specified and changing it fails, print an error
            perror("cd");
        }
        return true;
    }
    return false;
}


// Main function that starts the shell
int main(int argc, char *argv[]) {
    if (argc == 2) {
        shellLoop(true, argv[1]);
    } else {
        shellLoop();
    }

    return 0;
}
