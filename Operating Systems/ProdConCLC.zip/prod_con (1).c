#include <stdio.h>
#include <pthread.h>
#include <unistd.h>

#define BUFFER_SIZE 5

//Joshua Peek built producer and Osbaldo Juarez built consumer.

// Shared buffer and associated variables
int buffer[BUFFER_SIZE];
int put_index = 0, get_index = 0, count = 0;

// Function declarations
void *producer(void *arg);
void *consumer(void *arg);

// Producer function
void *producer(void *arg) {
    int data = 0;
    while (1) {
        // Check if buffer is full
        if (count == BUFFER_SIZE) {
            printf("Buffer full. Producer sleeping...\n");
            sleep(1);  // Sleep until space is available
        } else {
            buffer[put_index] = ++data;  // Produce data
            printf("Produced: %d at index %d\n", data, put_index);
            put_index = (put_index + 1) % BUFFER_SIZE;  // Circular buffer logic
            count++;

            // Simulate some delay to mimic real-world production
            sleep(1);
        }
    }
    return NULL;
}

// Consumer function
void *consumer(void *arg) {
    while (1) {
        // Check if buffer is empty
        if (count == 0) {
            printf("Buffer empty. Consumer sleeping...\n");
            sleep(1);  // Sleep until there is data available
        } else {
            int data = buffer[get_index];  // Consume data
            printf("Consumed: %d from index %d\n", data, get_index);
            get_index = (get_index + 1) % BUFFER_SIZE;  // Circular buffer logic
            count--;

            // Simulate some delay to mimic real-world consumption
            sleep(1);
        }
    }
    return NULL;
}

int main() {
    pthread_t prod_thread, cons_thread;

    // Create producer and consumer threads
    pthread_create(&prod_thread, NULL, producer, NULL);
    pthread_create(&cons_thread, NULL, consumer, NULL);

    // Wait for both threads to finish (which will not happen in this infinite loop)
    pthread_join(prod_thread, NULL);
    pthread_join(cons_thread, NULL);

    return 0;
}
/* Explanation:
Global Variables:
buffer[BUFFER_SIZE]: The shared buffer between the producer and the consumer.
put_index: The index where the producer will place the next produced item.
get_index: The index where the consumer will take the next item from the buffer.
count: The number of items currently in the buffer (helps to avoid buffer overflows and underflows).
Producer Thread (producer()):
The producer checks whether the buffer is full (count == BUFFER_SIZE).
If the buffer is full, the producer calls sleep(1) to simulate waiting.
If there is space, the producer adds data to the buffer at the put_index, increments the put_index circularly, and increments the count to keep track of the number of items.
The producer then sleeps for a short period (sleep(1)) to simulate the time taken to produce data.
Consumer Thread (consumer()):
The consumer checks whether the buffer is empty (count == 0).
If the buffer is empty, the consumer calls sleep(1) to simulate waiting.
If there is data, the consumer retrieves the data from the buffer at get_index, increments get_index circularly, and decrements the count.
The consumer then sleeps for a short period (sleep(1)) to simulate the time taken to consume data.
Key Points:
Sleep/Wakeup: In this solution, we use sleep() to make the producer or consumer wait when the buffer is either full or empty. Since we can't use traditional synchronization mechanisms like semaphores, the producer and consumer simply check the buffer state in each iteration and sleep if they can't proceed.
Circular Buffer: Both put_index and get_index use the modulo operator (% BUFFER_SIZE) to wrap around, simulating a circular buffer. This way, both the producer and consumer can continuously use the buffer if space and data are available.
Infinite Loops: In this example, the producer and consumer run in infinite loops, as the goal is continuous production and consumption. In a real-world application, you might introduce termination conditions or more advanced logic for thread control.*/
