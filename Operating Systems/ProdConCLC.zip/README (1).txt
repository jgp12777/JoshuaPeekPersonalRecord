Joshua Peek & Osbaldo Juarez 
Citro - CST - 315 
CLC - Assignment 1: Producer and Consumer


Joshua Peek coded the producer & Osbaldo Juarez coded the consumer.

Explanation:
Global Variables:
buffer[BUFFER_SIZE]: The shared buffer between the producer and the consumer.
put_index: The index where the producer will place the next produced item.
get_index: The index where the consumer will take the next item from the buffer.
count: The number of items currently in the buffer (helps to avoid buffer overflows and underflows).
Producer Thread (producer()):
The producer checks whether the buffer is full (count == BUFFER_SIZE).
If the buffer is full, the producer calls sleep(1) to simulate waiting.
If there is space, the producer adds data to the buffer at the put_index, increments the put_index circularly, and increments the count to keep track of the number of items.
The producer then sleeps for a short period (sleep(1)) to simulate the time taken to produce data.
Consumer Thread (consumer()):
The consumer checks whether the buffer is empty (count == 0).
If the buffer is empty, the consumer calls sleep(1) to simulate waiting.
If there is data, the consumer retrieves the data from the buffer at get_index, increments get_index circularly, and decrements the count.
The consumer then sleeps for a short period (sleep(1)) to simulate the time taken to consume data.
Key Points:
Sleep/Wakeup: In this solution, we use sleep() to make the producer or consumer wait when the buffer is either full or empty. Since we can't use traditional synchronization mechanisms like semaphores, the producer and consumer simply check the buffer state in each iteration and sleep if they can't proceed.
Circular Buffer: Both put_index and get_index use the modulo operator (% BUFFER_SIZE) to wrap around, simulating a circular buffer. This way, both the producer and consumer can continuously use the buffer if space and data are available.
Infinite Loops: In this example, the producer and consumer run in infinite loops, as the goal is continuous production and consumption. In a real-world application, you might introduce termination conditions or more advanced logic for thread control.



