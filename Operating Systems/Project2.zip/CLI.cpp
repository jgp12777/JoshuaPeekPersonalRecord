#include <iostream>     // For input/output operations
#include <sys/types.h>   // For data types used in system calls
#include <sys/wait.h>    // For waitpid() to make the parent wait for child processes
#include <unistd.h>      // For fork(), execvp(), and other POSIX functions
#include <vector>        // For using vectors to store command arguments
#include <string.h>      // For string manipulation (strtok)
#include <fstream>       // For reading from batch files

using namespace std;

// Function to parse a command input into arguments
// This function will split the command string into individual arguments using space as a delimiter
// Returns a vector of char pointers which will be passed to execvp
vector<char*> parseCommand(const string &command) {
    vector<char*> args;  // Vector to store arguments
    // strtok splits the command string by spaces and returns tokens (individual arguments)
    char* token = strtok(const_cast<char*>(command.c_str()), " ");
    while (token != nullptr) {
        args.push_back(token);  // Add each token to the args vector
        token = strtok(nullptr, " ");  // Get the next token
    }
    args.push_back(nullptr);  // Null-terminate the argument list (required for execvp)
    return args;  // Return the vector of arguments
}

// Function to execute a command
// This function will create a child process using fork(), and the child will run the command using execvp()
// The parent process waits for the child to complete
void executeCommand(const string &command) {
    vector<char*> args = parseCommand(command);  // Parse the command into arguments
    pid_t pid = fork();  // Create a new process

    if (pid == 0) {  // In the child process
        // In the child process, use execvp to replace the process image with the command to be executed
        if (execvp(args[0], args.data()) == -1) {
            perror("execvp failed");  // If execvp fails, print an error
        }
        exit(EXIT_FAILURE);  // If execvp fails, terminate the child process with an error
    } else if (pid > 0) {  // Parent process
        // Parent process waits for the child to finish execution using waitpid()
        int status;
        waitpid(pid, &status, 0);  // Wait for the specific child process to terminate
    } else {
        perror("fork failed");  // If fork fails, print an error
    }
}

// Function to handle multiple commands separated by semicolons
// This function splits a line of commands by semicolons and executes each command individually
void handleMultipleCommands(string line) {
    size_t pos;
    string command;
    // Loop through the command string and execute each command separated by a semicolon
    while ((pos = line.find(";")) != string::npos) {
        command = line.substr(0, pos);  // Get the command before the semicolon
        executeCommand(command);  // Execute the command
        line.erase(0, pos + 1);  // Remove the executed command from the input string
    }
    // Execute the last command (or the only command if no semicolons were found)
    if (!line.empty()) {
        executeCommand(line);
    }
}

// Function to process a batch file
// The batch file contains a list of commands, one per line. Each line is treated as a separate command
// This function reads the batch file line by line, and executes the commands in sequence
void processBatchFile(const string &filename) {
    ifstream batchFile(filename);  // Open the batch file for reading
    string line;  // Variable to store each line of the file
    if (!batchFile) {  // If the file cannot be opened, print an error
        cerr << "Error: Cannot open batch file " << filename << endl;
        return;
    }
    // Read the batch file line by line and execute each line as a command
    while (getline(batchFile, line)) {
        cout << "SlopeShell > " << line << endl;  // Print the command being executed
        handleMultipleCommands(line);  // Execute the command(s)
    }
}

// Main function for the shell
// If batch mode is enabled, process the batch file. Otherwise, enter interactive mode
void shellLoop(bool isBatchMode = false, const string &batchFilename = "") {
    string command;  // Variable to store the user's input

    if (isBatchMode) {
        // If the shell is running in batch mode, process the batch file
        processBatchFile(batchFilename);
    } else {
        // Interactive shell mode: keep prompting the user for commands
        while (true) {
            cout << "SlopeShell > ";  // Print the shell prompt
            getline(cin, command);  // Read the user's input

            // If the user types "quit", exit the shell
            if (command == "quit") {
                break;  // Exit the loop and terminate the shell
            }

            // Handle and execute the command (including handling multiple commands separated by semicolons)
            handleMultipleCommands(command);
        }
    }
}

// Main function that starts the shell
int main(int argc, char *argv[]) {
    if (argc == 2) {
        // If a batch file is provided as a command-line argument, run the shell in batch mode
        shellLoop(true, argv[1]);
    } else {
        // If no batch file is provided, run the shell in interactive mode
        shellLoop();
    }

    return 0;  // Exit the program
}
