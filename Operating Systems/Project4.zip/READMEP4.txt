﻿Project Title: Project 4: Pager – A Virtual Memory Manager
Name: Joshua Peek
Student ID: 21081733
Class: CST-315
Professor: Citro


Description:
This project adds a Virtual Memory Manager (VMM) to an existing Unix/Linux shell. The VMM enables efficient memory handling by implementing paging to manage limited physical memory and swap space. This component facilitates memory allocation for processes by translating virtual addresses to physical addresses and handling page faults and segmentation faults dynamically.


Approach: 
The approach involves implementing paging for memory segments and utilizing demand paging, where pages are loaded only when required. We designed a VMM that maintains virtual and physical memory mappings through page tables and frame tables. The VMM employs a memory allocation algorithm to manage frame allocation dynamically, aiming to balance performance and memory constraints. 


Assumptions:
* Physical Memory: Limited to a fixed frame size.
* Page Size: Set to 4,096 bytes for consistency.
* Demand Paging: Only loads pages when accessed, minimizing initial memory load.
* Swapping: Modifications are swapped out; read-only pages are preserved.
* Parallelism: Page faults will not block other processes unless I/O is required.


These assumptions optimize memory usage and support multitasking by minimizing unnecessary memory loading and preserving system responsiveness.


Responses to Required Points
1. Physical Memory Size: The physical memory frame is limited, requiring efficient page management.
2. Virtual Memory Size: Virtual memory is larger than physical memory, allowing more pages than frames.
3. Process Memory Needs: Each process requests virtual pages based on its memory needs, loaded on demand.
4. Virtual Page Size: Fixed at 4,096 bytes, ensuring continuous allocation.
5. Page Calculation and Allocation: Pages are calculated per process, allocating kernel and virtual pages as needed.
6. Page Table Management: Uses an array-based structure for storing page tables, dynamically allocated as needed.
7. Page Frame Management: Maintains a frame table for tracking physical memory frames; frames are allocated per demand paging.
8. Memory Allocation Algorithm: Implements a Least Recently Used (LRU) algorithm for efficient page replacement.
9. Page Swapping Decision: Pages are swapped when physical memory is full, prioritizing modified pages for write-back.
10. Page and Segmentation Fault Management:
a. Pages are demand-paged, loading segments as needed.
b. Modified pages are written to swap on eviction; read-only pages remain untouched.
c. Parallel processing is supported, enabling other processes to continue on I/O wait.
11. Resource Management on Termination: Frees page and frame resources associated with terminated processes.
Paging Algorithm Description


The VMM uses a demand-paging algorithm with LRU replacement. Pages are loaded on access and evicted when memory is full.


Code Explanation:
The code is explained thoroughly in the source code commentation.


Paging Algorithm Flowchart:
           +----------------------+
           |    Page Request      |
           +----------+-----------+
                      |
                      |
               +------v------+
               | Is page in  |
               |   memory?   |
               +------+------+
                      | No
                      |
             +--------v---------+
             | Trigger Page     |
             | Fault Handler    |
             +--------+---------+
                      |
              +-------v-------+
              | Free Frame    |
              | Available?    |
              +-------+-------+
                      | No
                      |
                +-----v-----+
                | Evict Page |
                +-----+------+
                      |
            +---------v---------+
            | Load Page into    |
            | Free Frame        |
            +---------+---------+
                      |
                      |
              +-------v--------+
              | Update Page    |
              | Table Mapping  |
              +-------+--------+
                      |
                      |
             +--------v---------+
             | Resume Execution |
             +------------------+


Segmentation Fault Handeling:
           +-----------------------+
           |   Memory Access       |
           +----------+------------+
                      |
                      |
              +-------v---------+
              | Within Segment? |
              +-------+---------+
                      | No
                      |
           +----------v----------+
           | Trigger Segmentation|
           | Fault Handler       |
           +----------+----------+
                      |
           +----------v----------+
           | Terminate Process   |
           | or Handle Error     |
           +---------------------+


Page Fault Handeling:
           +-------------------+
           | Page Request |
           +---------+--------+
                     |
                     |
            +--------v---------+
            | Page in Memory?  |
            +--------+---------+
                     | No
                     |
            +--------v---------+
            | Trigger Page     |
            | Fault Handler    |
            +--------+---------+
                     |
            +--------v---------+
            | Free Frame       |
            | Available?         |
            +--------+---------+
                     | No
                     |
             +-------v---------+
             | Evict Least       |
             | Recently Used |
             | Page                |
             +-------+---------+
                     |
           +---------v---------+
           | Load New Page|
           | into Frame        |
           +---------+---------+
                     |
                     |
             +-------v---------+
             | Update Page  |
             | Table              |
             +-------+---------+
                     |
             +-------v---------+
             | Resume Process  |
             +-----------------+
Successful Code Exucution:
This is a C++ program 
Compile by downloading the source file and typing: 
g++ pager.cpp -o pager {Enter}
./pager {Enter}