#include <iostream>
#include <queue>
#include <thread>
#include <chrono>
#include <mutex>
#include <condition_variable>
#include <vector>
#include <atomic>
#include <fstream>          // Include for file handling
#include <sstream>          // Include for string stream handling

#define TIME_QUANTUM 3

using namespace std;

// Enum representing the different states a process can be in
enum ProcessState { READY, RUNNING, WAITING, TERMINATED };

// Struct to represent a Process
struct Process {
    int id;                     // Unique identifier for the process
    int priority;               // Priority of the process (not used in this simple implementation)
    atomic<ProcessState> state; // Current state of the process
    int executionTime;          // Total execution time required by the process
    int elapsedTime;            // Time already executed by the process

    // Constructor to initialize a process
    Process(int id, int priority, int executionTime) :
        id(id), priority(priority), executionTime(executionTime), elapsedTime(0) {
        state = READY;
    }
};

// Queue to manage the processes waiting for execution
queue<Process*> processQueue;
// Vector to keep track of all processes (for listing purposes)
vector<Process*> allProcesses;
// Mutex to protect shared resources
mutex queueMutex;
// Condition variable to synchronize scheduler and process addition
condition_variable cv;
// Atomic boolean to control the running state of the scheduler
atomic<bool> running(true);

// Function to output process state change
void outputStateChange(Process* process, ProcessState newState) {
    static const char* stateNames[] = {"READY", "RUNNING", "WAITING", "TERMINATED"};
    cout << "Process " << process->id << " switching to state: " << stateNames[newState] << endl;
    process->state = newState;
}

// Scheduler function that manages process execution
void scheduler() {
    while (running) {
        unique_lock<mutex> lock(queueMutex);
        // Wait if the process queue is empty
        if (processQueue.empty()) {
            cv.wait(lock);
        }

        // Break if the scheduler is no longer running
        if (!running) break;

        // Get the next process from the queue
        Process* currentProcess = processQueue.front();
        processQueue.pop();
        lock.unlock();

        // If the process is ready, run it
        if (currentProcess->state == READY) {
            outputStateChange(currentProcess, RUNNING);
            // Simulate the process running for the time quantum
            this_thread::sleep_for(chrono::seconds(TIME_QUANTUM));
            currentProcess->elapsedTime += TIME_QUANTUM;

            // Check if the process has completed its execution
            if (currentProcess->elapsedTime >= currentProcess->executionTime) {
                outputStateChange(currentProcess, TERMINATED);
                cout << "Process " << currentProcess->id << " has terminated." << endl;
            } else {
                // If not completed, set the state back to READY and requeue the process
                outputStateChange(currentProcess, READY);
                lock.lock();
                processQueue.push(currentProcess);
                lock.unlock();
                cv.notify_all();
            }
        }
    }
}

// Function to add a new process to the queue
void addProcess(int id, int priority, int executionTime) {
    Process* newProcess = new Process(id, priority, executionTime);
    {
        lock_guard<mutex> lock(queueMutex);
        processQueue.push(newProcess);
        allProcesses.push_back(newProcess);
    }
    // Notify the scheduler that a new process has been added
    cv.notify_all();
}

// Function to handle user input commands
void processInput() {
    while (true) {
        cout << "Enter command: ";
        string command;
        cin >> command;
        if (command == "add") {
            // Command to add a new process
            int id, priority, executionTime;
            cout << "Enter process id, priority, execution time: ";
            cin >> id >> priority >> executionTime;
            addProcess(id, priority, executionTime);
        } else if (command == "procs") {
            // Command to list all processes and their states
            lock_guard<mutex> lock(queueMutex);
            for (auto& process : allProcesses) {
                cout << "Process " << process->id << " - State: " << process->state << " - Elapsed: " << process->elapsedTime << "/" << process->executionTime << endl;
            }
        } else if (command == "batch") {
            // Command to read commands from a batch file
            string filename;
            cin >> filename;
            ifstream batchFile(filename);
            if (batchFile.is_open()) {
                string line;
                while (getline(batchFile, line)) {
                    istringstream iss(line);
                    string cmd;
                    iss >> cmd;
                    if (cmd == "add") {
                        int id, priority, executionTime;
                        iss >> id >> priority >> executionTime;
                        addProcess(id, priority, executionTime);
                    } else if (cmd == "procs") {
                        lock_guard<mutex> lock(queueMutex);
                        for (auto& process : allProcesses) {
                            cout << "Process " << process->id << " - State: " << process->state << " - Elapsed: " << process->elapsedTime << "/" << process->executionTime << endl;
                        }
                    }
                }
                batchFile.close();
            } else {
                cout << "Unable to open file: " << filename << endl;
            }
        } else if (command == "exit") {
            // Command to exit the program
            running = false;
            cv.notify_all();
            break;
        }
    }
}

int main() {
    // Start the scheduler thread
    thread schedulerThread(scheduler);
    // Handle user input in the main thread
    processInput();
    // Wait for the scheduler thread to finish
    schedulerThread.join();
    return 0;
}
