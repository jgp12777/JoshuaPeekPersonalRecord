#include <iostream>
#include <vector>
#include <unordered_map>

// Class to implement a simple Virtual Memory Manager
class VirtualMemoryManager {
    int frameSize;         // Total physical memory size (in bytes)
    int pageSize;          // Size of each page (in bytes)
    int totalFrames;       // Total number of frames in physical memory
    int pageFaults;        // Counter for page faults
    std::vector<int> frameTable;   // Vector to keep track of pages in frames
    std::unordered_map<int, int> pageTable;  // Map to keep track of page-to-frame mapping

public:
    // Constructor to initialize frame size, page size, and calculate the total number of frames
    VirtualMemoryManager(int frameSize, int pageSize) 
        : frameSize(frameSize), pageSize(pageSize), totalFrames(frameSize / pageSize), pageFaults(0) {
        // Initialize frameTable with -1 to indicate all frames are initially empty
        frameTable.resize(totalFrames, -1);
    }

    // Function to check if a page is currently loaded in memory
    bool isPageInMemory(int page) {
        // Returns true if page exists in the page table (page is in memory)
        return pageTable.find(page) != pageTable.end();
    }

    // Function to load a page into memory, simulating demand paging
    void loadPage(int page) {
        // If page is already in memory, no need to load again
        if (isPageInMemory(page)) {
            std::cout << "Page " << page << " already in memory." << std::endl;
        } else {
            // If physical memory is full, perform page eviction based on the defined policy
            if (frameTable.size() >= totalFrames) {
                evictPage();  // Evict a page if no free frames are available
            }

            // Calculate the frame index to load the new page into
            int frameIndex = pageTable.size() % totalFrames;
            pageTable[page] = frameIndex;      // Map the page to the frame in the page table
            frameTable[frameIndex] = page;     // Store the page in the frame table

            // Output a message indicating successful page load and increment page faults
            std::cout << "Loaded page " << page << " into frame " << frameIndex << "." << std::endl;
            pageFaults++;  // Increment the page fault counter since we loaded a new page
        }
    }

    // Function to evict a page from memory, simulating a page replacement policy
    void evictPage() {
        int evictedPage = frameTable[0];  // Select the page to evict (here, we use the first page as an example)
        frameTable.erase(frameTable.begin());  // Remove the page from the frame table
        pageTable.erase(evictedPage);  // Remove the mapping from the page table

        // Output a message indicating the evicted page
        std::cout << "Evicted page " << evictedPage << " from memory." << std::endl;
    }

    // Function to display the current status of memory frames
    void displayMemoryStatus() const {
        std::cout << "Current memory status:" << std::endl;
        // Loop through each frame to display its content (page number)
        for (int i = 0; i < frameTable.size(); ++i) {
            std::cout << "Frame " << i << ": Page " << frameTable[i] << std::endl;
        }
    }

    // Function to get the total number of page faults
    int getPageFaultCount() const {
        return pageFaults;  // Returns the count of page faults occurred during execution
    }
};

int main() {
    int frameSize = 8192;  // Set the frame size for physical memory (in bytes)
    int pageSize = 4096;   // Set the size of each page (in bytes)
    
    // Create an instance of VirtualMemoryManager with given frame and page size
    VirtualMemoryManager vmm(frameSize, pageSize);

    // Define a sequence of page requests to simulate memory accesses
    std::vector<int> pagesToLoad = {0, 1, 2, 3, 4, 1, 0, 3, 2};

    // Load each page from the sequence into the memory manager
    for (int page : pagesToLoad) {
        vmm.loadPage(page);           // Attempt to load the page into memory
        vmm.displayMemoryStatus();     // Display the current memory status after each load
    }

    // Display the total number of page faults encountered during the simulation
    std::cout << "Total page faults: " << vmm.getPageFaultCount() << std::endl;
    return 0;
}
