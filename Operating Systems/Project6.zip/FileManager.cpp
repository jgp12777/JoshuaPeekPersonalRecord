#include <iostream>
#include <string>
#include <vector>
#include <map>
#include <fstream>
#include <random>
#include <filesystem>
#include <thread>
#include <chrono>
#include <mutex>

namespace fs = std::filesystem;

std::mutex fileSystemMutex; // Mutex for thread safety

struct File {
    std::string name;
    std::string path;
    size_t size;
    std::string content;

    File(const std::string& name, const std::string& path, size_t size)
        : name(name), path(path), size(size) {
        content = generateRandomContent(size);
    }

    static std::string generateRandomContent(size_t size) {
        const char charset[] = "abcdefghijklmnopqrstuvwxyzABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
        std::default_random_engine rng(std::random_device{}());
        std::uniform_int_distribution<> dist(0, sizeof(charset) - 2);
        std::string result;
        for (size_t i = 0; i < size; ++i) {
            result += charset[dist(rng)];
        }
        return result;
    }

    File() : name(""), path(""), size(0), content("") {} // Default constructor
};

struct Directory {
    std::string name;
    std::string path;
    std::map<std::string, File> files;
    std::map<std::string, Directory> subdirectories;

    Directory(const std::string& name, const std::string& path)
        : name(name), path(path) {}

    Directory() : name(""), path("") {} // Default constructor
};

class FileSystem {
public:
    FileSystem() : root("root", "/") {
        currentDirectory = &root;
    }

    void run() {
        std::string command;
        while (true) {
            std::cout << "\nAvailable Commands:\n"
                      << "1. mkdir <directory_name>\n"
                      << "2. rename_dir <old_name> <new_name>\n"
                      << "3. rmdir <directory_name> [-f]\n"
                      << "4. touch <file_name> <size>\n"
                      << "5. rename_file <old_name> <new_name>\n"
                      << "6. rm <file_name>\n"
                      << "7. mv <file_name> <target_directory>\n"
                      << "8. duplicate_file <file_name>\n"
                      << "9. duplicate_dir <directory_name>\n"
                      << "10. search <file_name>\n"
                      << "11. ls\n"
                      << "12. fileinfo <file_name> [-d]\n"
                      << "13. dirinfo <directory_name> [-d]\n"
                      << "14. exit\n"
                      << "\nEnter command: ";
            std::cin >> command;

            if (command == "mkdir") {
                std::string name;
                std::cin >> name;
                createDirectory(name);
            } else if (command == "rename_dir") {
                std::string oldName, newName;
                std::cin >> oldName >> newName;
                renameDirectory(oldName, newName);
            } else if (command == "rmdir") {
                std::string name;
                std::string force;
                std::cin >> name;
                if (std::cin.peek() == ' ') {
                    std::cin >> force;
                }
                deleteDirectory(name, force == "-f");
            } else if (command == "touch") {
                std::string name;
                size_t size;
                std::cin >> name >> size;
                createFile(name, size);
            } else if (command == "rename_file") {
                std::string oldName, newName;
                std::cin >> oldName >> newName;
                renameFile(oldName, newName);
            } else if (command == "rm") {
                std::string name;
                std::cin >> name;
                deleteFile(name);
            } else if (command == "mv") {
                std::string fileName, targetDirName;
                std::cin >> fileName >> targetDirName;
                moveFile(fileName, targetDirName);
            } else if (command == "duplicate_file") {
                std::string fileName;
                std::cin >> fileName;
                duplicateFile(fileName);
            } else if (command == "duplicate_dir") {
                std::string dirName;
                std::cin >> dirName;
                duplicateDirectory(dirName);
            } else if (command == "search") {
                std::string fileName;
                std::cin >> fileName;
                searchFile(fileName, *currentDirectory);
            } else if (command == "ls") {
                displayCurrentDirectoryTree();
            } else if (command == "fileinfo") {
                std::string fileName;
                std::string detail;
                std::cin >> fileName;
                if (std::cin.peek() == ' ') {
                    std::cin >> detail;
                }
                if (detail == "-d") {
                    getFileDetailedInfo(fileName);
                } else {
                    getFileBasicInfo(fileName);
                }
            } else if (command == "dirinfo") {
                std::string dirName;
                std::string detail;
                std::cin >> dirName;
                if (std::cin.peek() == ' ') {
                    std::cin >> detail;
                }
                if (detail == "-d") {
                    getDirectoryDetailedInfo(dirName);
                } else {
                    getDirectoryBasicInfo(dirName);
                }
            } else if (command == "exit") {
                break;
            } else {
                std::cout << "Unknown command." << std::endl;
            }
        }
    }

    void createDirectory(const std::string& name) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        if (currentDirectory->subdirectories.find(name) == currentDirectory->subdirectories.end()) {
            std::string newPath = currentDirectory->path + name + "/";
            currentDirectory->subdirectories[name] = Directory(name, newPath);
            std::cout << "Directory created: " << newPath << std::endl;
        } else {
            std::cout << "Directory already exists." << std::endl;
        }
    }

    void renameDirectory(const std::string& oldName, const std::string& newName) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->subdirectories.find(oldName);
        if (it != currentDirectory->subdirectories.end()) {
            Directory dir = it->second;
            currentDirectory->subdirectories.erase(it);
            dir.name = newName;
            dir.path = currentDirectory->path + newName + "/";
            currentDirectory->subdirectories[newName] = dir;
            std::cout << "Directory renamed from " << oldName << " to " << newName << std::endl;
        } else {
            std::cout << "Directory not found." << std::endl;
        }
    }

    void deleteDirectory(const std::string& name, bool force = false) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->subdirectories.find(name);
        if (it != currentDirectory->subdirectories.end()) {
            if (force || it->second.subdirectories.empty() && it->second.files.empty()) {
                currentDirectory->subdirectories.erase(it);
                std::cout << "Directory deleted: " << name << std::endl;
            } else {
                std::cout << "Directory not empty. Use force flag to delete." << std::endl;
            }
        } else {
            std::cout << "Directory not found." << std::endl;
        }
    }

    void createFile(const std::string& name, size_t size) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        if (currentDirectory->files.find(name) == currentDirectory->files.end()) {
            std::string newPath = currentDirectory->path + name;
            currentDirectory->files[name] = File(name, newPath, size);
            std::cout << "File created: " << newPath << " (" << size << " bytes)" << std::endl;
        } else {
            std::cout << "File already exists." << std::endl;
        }
    }

    void renameFile(const std::string& oldName, const std::string& newName) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->files.find(oldName);
        if (it != currentDirectory->files.end()) {
            File file = it->second;
            currentDirectory->files.erase(it);
            file.name = newName;
            file.path = currentDirectory->path + newName;
            currentDirectory->files[newName] = file;
            std::cout << "File renamed from " << oldName << " to " << newName << std::endl;
        } else {
            std::cout << "File not found." << std::endl;
        }
    }

    void deleteFile(const std::string& name) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->files.find(name);
        if (it != currentDirectory->files.end()) {
            currentDirectory->files.erase(it);
            std::cout << "File deleted: " << name << std::endl;
        } else {
            std::cout << "File not found." << std::endl;
        }
    }

    void moveFile(const std::string& fileName, const std::string& targetDirName) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto fileIt = currentDirectory->files.find(fileName);
        auto dirIt = currentDirectory->subdirectories.find(targetDirName);
        if (fileIt != currentDirectory->files.end() && dirIt != currentDirectory->subdirectories.end()) {
            File file = fileIt->second;
            currentDirectory->files.erase(fileIt);
            file.path = dirIt->second.path + fileName;
            dirIt->second.files[fileName] = file;
            std::cout << "File moved to " << dirIt->second.path << std::endl;
        } else {
            std::cout << "File or target directory not found." << std::endl;
        }
    }

    void duplicateFile(const std::string& fileName) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->files.find(fileName);
        if (it != currentDirectory->files.end()) {
            File originalFile = it->second;
            std::string newFileName = fileName + "_copy";
            currentDirectory->files[newFileName] = File(newFileName, originalFile.path + "_copy", originalFile.size);
            currentDirectory->files[newFileName].content = originalFile.content;
            std::cout << "File duplicated: " << newFileName << std::endl;
        } else {
            std::cout << "File not found." << std::endl;
        }
    }

    void duplicateDirectory(const std::string& dirName) {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        auto it = currentDirectory->subdirectories.find(dirName);
        if (it != currentDirectory->subdirectories.end()) {
            Directory originalDir = it->second;
            std::string newDirName = dirName + "_copy";
            Directory newDir = originalDir;
            newDir.name = newDirName;
            newDir.path = currentDirectory->path + newDirName + "/";
            currentDirectory->subdirectories[newDirName] = newDir;
            std::cout << "Directory duplicated: " << newDirName << std::endl;
        } else {
            std::cout << "Directory not found." << std::endl;
        }
    }

    void searchFile(const std::string& fileName, const Directory& dir) const {
        for (const auto& file : dir.files) {
            if (file.first == fileName) {
                std::cout << "File found: " << dir.path + fileName << std::endl;
                return;
            }
        }
        for (const auto& subdir : dir.subdirectories) {
            searchFile(fileName, subdir.second);
        }
    }

    void getFileBasicInfo(const std::string& fileName) const {
        auto it = currentDirectory->files.find(fileName);
        if (it != currentDirectory->files.end()) {
            std::cout << "File: " << it->second.name << ", Size: " << it->second.size << " bytes" << std::endl;
        } else {
            std::cout << "File not found." << std::endl;
        }
    }

    void getFileDetailedInfo(const std::string& fileName) const {
        auto it = currentDirectory->files.find(fileName);
        if (it != currentDirectory->files.end()) {
            std::cout << "File: " << it->second.name << ", Size: " << it->second.size << " bytes, Path: " << it->second.path << ", Content: " << it->second.content << std::endl;
        } else {
            std::cout << "File not found." << std::endl;
        }
    }

    void getDirectoryBasicInfo(const std::string& dirName) const {
        auto it = currentDirectory->subdirectories.find(dirName);
        if (it != currentDirectory->subdirectories.end()) {
            std::cout << "Directory: " << it->second.name << ", Contains: " << it->second.files.size() << " files, " << it->second.subdirectories.size() << " subdirectories" << std::endl;
        } else {
            std::cout << "Directory not found." << std::endl;
        }
    }

    void getDirectoryDetailedInfo(const std::string& dirName) const {
        auto it = currentDirectory->subdirectories.find(dirName);
        if (it != currentDirectory->subdirectories.end()) {
            std::cout << "Directory: " << it->second.name << ", Path: " << it->second.path << ", Contains: " << it->second.files.size() << " files, " << it->second.subdirectories.size() << " subdirectories" << std::endl;
            for (const auto& file : it->second.files) {
                std::cout << "  File: " << file.second.name << ", Size: " << file.second.size << " bytes" << std::endl;
            }
        } else {
            std::cout << "Directory not found." << std::endl;
        }
    }

    void displayDirectoryTree(const Directory& dir, int depth = 0) const {
        for (int i = 0; i < depth; ++i) std::cout << "  ";
        std::cout << dir.name << "/" << std::endl;
        for (const auto& subdir : dir.subdirectories) {
            displayDirectoryTree(subdir.second, depth + 1);
        }
        for (const auto& file : dir.files) {
            for (int i = 0; i < depth + 1; ++i) std::cout << "  ";
            std::cout << file.second.name << " (" << file.second.size << " bytes)" << std::endl;
        }
    }

    void displayCurrentDirectoryTree() const {
        std::lock_guard<std::mutex> lock(fileSystemMutex);
        displayDirectoryTree(*currentDirectory);
    }

private:
    Directory root;
    Directory* currentDirectory;
};

int main() {
    FileSystem fs;
    fs.run();
    return 0;
}
