# CST-305 Project 4: Degradation of Data Integrity
# Joshua Peek - 21081733
# Packages Used: numpy (numerical computations), matplotlib (plotting)
# Approach: Analytically solved the ODE system using eigenvalues, then plotted the rates of degradation.

import numpy as np
import matplotlib.pyplot as plt

# Define time array (0 to 100 seconds for clear decay visualization)
t = np.linspace(0, 100, 1000)

# Compute rates of degradation
x1_prime = -np.exp(-0.05 * t)  # Negative rate for Processor A (MB/sec)
x2_prime = np.exp(-0.05 * t)    # Positive rate for Processor B (MB/sec)

# Plot both rates on the same graph
plt.figure(figsize=(10, 6))
plt.plot(t, x1_prime, label="Negative Rate (Processor A)", color='red')
plt.plot(t, x2_prime, label="Positive Rate (Processor B)", color='blue')
plt.axhline(0, color='black', linestyle='--', linewidth=0.5)
plt.title("Positive and Negative Rates of Data Degradation Over Time")
plt.xlabel("Time (seconds)")
plt.ylabel("Rate of Change (MB/sec)")
plt.legend()
plt.grid(True)
plt.savefig("degradation_rates.png")
plt.show()

# Display solution context
print("Data in Processor A: x1(t) = 80 + 20 * exp(-0.05 t) MB")
print("Data in Processor B: x2(t) = 120 - 20 * exp(-0.05 t) MB")
print("Negative Rate (A): x1'(t) = -exp(-0.05 t) MB/sec")
print("Positive Rate (B): x2'(t) = exp(-0.05 t) MB/sec")
print("Initial: x1(0) = 100 MB, x2(0) = 100 MB")
print("Steady State: x1(∞) = 80 MB, x2(∞) = 120 MB, rates = 0 MB/sec")