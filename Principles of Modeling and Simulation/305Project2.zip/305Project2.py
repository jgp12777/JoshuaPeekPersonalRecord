#Joshua Peek - 21081733
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import odeint
import time

# Define the ODE: dy/dx = -y + ln(x)
def f(y, x):
    return -y + np.log(x)

# 4th-order Runge-Kutta (RK4) implementation as specified
def rk4(x0, y0, h, steps_max, ode_y):
    x = [x0]
    y = [y0]
    steps = 0
    print(f"{'Step':<6} {'x':<10} {'y_RK4':<10} {'k1':<12} {'k2':<12} {'k3':<12} {'k4':<12} {'y_odeint':<10}")
    print("-" * 90)
    
    while steps < steps_max:
        # Compute k1, k2, k3, k4 as defined
        k1 = f(y[-1], x[-1])
        k2 = f(y[-1] + (h/2) * k1, x[-1] + h/2)
        k3 = f(y[-1] + (h/2) * k2, x[-1] + h/2)
        k4 = f(y[-1] + h * k3, x[-1] + h)
        
        # Print step details with odeint solution
        print(f"{steps:<6} {x[-1]:<10.4f} {y[-1]:<10.4f} {k1:<12.6e} {k2:<12.6e} {k3:<12.6e} {k4:<12.6e} {ode_y[steps]:<10.4f}")
        
        # Update y and x
        y.append(y[-1] + (h/6) * (k1 + 2*k2 + 2*k3 + k4))
        x.append(x[-1] + h)
        steps += 1
    
    return np.array(x), np.array(y), steps

# Wrapper for odeint
def solve_odeint(x0, y0, x_max, h):
    x = np.arange(x0, x_max + h, h)
    y = odeint(f, y0, x, tfirst=False)
    return x, y.flatten(), len(x) - 1

# Main function to solve ODE and plot results
def solve_and_plot(h=0.3, steps_max=2000):
    x0, y0 = 2, 1
    x_max = x0 + steps_max * h  # x = 602 after 2000 steps
    
    # Solve using odeint first to get 'true' solution
    start_time = time.time()
    ode_x, ode_y, ode_steps = solve_odeint(x0, y0, x_max, h)
    ode_time = time.time() - start_time
    
    # Solve using RK4, passing odeint solution for printing
    start_time = time.time()
    rk4_x, rk4_y, rk4_steps = rk4(x0, y0, h, steps_max, ode_y)
    rk4_time = time.time() - start_time
    
    # Print results
    print(f"\nResults for h={h}:")
    print(f"RK4: Steps={rk4_steps}, Time={rk4_time:.4f}s")
    print(f"odeint: Steps={ode_steps}, Time={ode_time:.4f}s")
    print(f"RK4 at x_2000: x={rk4_x[-1]:.4f}, y={rk4_y[-1]:.4f}")
    
    # Plotting
    plt.figure(figsize=(12, 4))
    
    # RK4 plot
    plt.subplot(1, 3, 1)
    plt.plot(rk4_x, rk4_y, 'b-', label='RK4')
    plt.title(f'RK4 Solution (h={h})')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True)
    plt.legend()
    
    # odeint plot
    plt.subplot(1, 3, 2)
    plt.plot(ode_x, ode_y, 'r-', label='odeint')
    plt.title(f'odeint Solution (h={h})')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True)
    plt.legend()
    
    # Combined plot
    plt.subplot(1, 3, 3)
    plt.plot(rk4_x, rk4_y, 'b-', label='RK4')
    plt.plot(ode_x, ode_y, 'r--', label='odeint')
    plt.title('Combined Solutions')
    plt.xlabel('x')
    plt.ylabel('y')
    plt.grid(True)
    plt.legend()
    
    plt.tight_layout()
    plt.show()

# Run for h=0.3, 2000 steps
solve_and_plot(h=0.3, steps_max=2000)