#Joshua Peek (Student ID: 21081733)
import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import solve_ivp

# Homogeneous: (x^2 + 4)y'' + y = 0 → y2' = -y1 / (x^2 + 4)
def ode_homogeneous(x, y):
    y1, y2 = y
    dy1dx = y2
    dy2dx = -y1 / (x**2 + 4)
    return [dy1dx, dy2dx]

# Initial conditions
A = 1  # y(0)
B = 0  # y'(0)
y0 = [A, B]

# Solve numerically on interval [0, 5]
x_span = (0, 5)
x_eval = np.linspace(0, 0.5, 300)
sol = solve_ivp(ode_homogeneous, x_span, y0, t_eval=x_eval)

# Plot
plt.plot(sol.t, sol.y[0], label='y(x)')
plt.title('Homogeneous Solution of (x² + 4)y\'\' + y = 0')
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.legend()
plt.show()
