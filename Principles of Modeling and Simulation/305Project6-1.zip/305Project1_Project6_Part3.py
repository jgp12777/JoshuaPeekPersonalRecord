# Joshua Peek 21081733

import numpy as np
from scipy.integrate import odeint
import matplotlib.pyplot as plt

# This ODE models CPU temperature under constant processing load:
# dT/dt = a(P - (T - Tambient))
# T(t) = CPU temperature, Tambient = ambient temperature, P = power input
# a = cooling efficiency (thermal conductivity constant)

a = 0.1            # cooling rate constant
P = 75             # power input in watts
T_ambient = 25     # ambient temperature in Celsius

# Define the model function
def cpu_temp_model(T, t):
    return a * (P - (T - T_ambient))

# Initial temperature of CPU
T0 = 25  # same as ambient

# Time range for the solution (seconds)
t = np.linspace(0, 200, 200)

# Solve the ODE
T = odeint(cpu_temp_model, T0, t)

# Plot the result
plt.plot(t, T)
plt.title("CPU Temperature Over Time")
plt.xlabel("Time (seconds)")
plt.ylabel("CPU Temperature (°C)")
plt.grid(True)
plt.show()
