#Joshua Peek (Student ID: 21081733)
import numpy as np
import matplotlib.pyplot as plt

# Define x range around x=3
x = np.linspace(2, 4, 100)
# Second order Taylor polynomial
y_taylor = 6 + 1 * (x - 3) - (11/2) * (x - 3)**2

# Plot
plt.plot(x, y_taylor, label='Taylor Polynomial (2nd order)')
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(3, color='black', linewidth=0.5, linestyle='--')
plt.title('Taylor Polynomial Approximation near x=3')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
plt.show()