# CST-305 Project: Modeling and Simulation

## Overview

This project involves solving various differential equations using numerical methods, including Taylor and power series expansions, and modeling a real-world system. The solutions are implemented in Python and visualized using plots. The project is divided into several parts, each addressing a specific mathematical problem:

1.  **Part 1(a) & 1(b):** Taylor Series Approximations
2.  **Part 2:** Power Series Solution
3.  **Part 3:** ODE Modeling of CPU Temperature

## Contributor

* **Author:** Joshua Peek
* **Student ID:** 21081733

---

## Prerequisites

Before you can run these programs, you'll need Python 3 installed on your system. Additionally, the scripts depend on a few external libraries for numerical computation and plotting.

**Required Libraries:**
* NumPy
* Matplotlib
* SciPy

## Installation

You can install all the required libraries using `pip`, the Python package manager. Open your terminal or command prompt and execute the following command:

```bash
pip install numpy matplotlib scipy
```

This command will download and install the necessary packages if you don't already have them.

---

## How to Run the Programs

To run any of the scripts, navigate to the project directory in your terminal and use the `python` command. Each script will run independently and open a new window to display the resulting plot.

### 1. Part 1(a): Taylor Polynomial Approximation (`305Project6_a.py`)

This script calculates and plots the Taylor polynomial approximation for the differential equation $y'' - 2xy' + x^2y = 0$ around the point $x=0$.

**To Run:**
```bash
python 305Project6_a.py
```
**Expected Output:** A plot titled "Taylor Polynomial Approximation" will be displayed.

### 2. Part 1(b): Second-Order Taylor Polynomial (`305Project6_b.py`)

This program computes and visualizes the second-order Taylor polynomial for the differential equation $y'' - (x-2)y' + 2y = 0$ centered at $x=3$.

**To Run:**
```bash
python 305Project6_b.py
```
**Expected Output:** A plot titled "Taylor Polynomial Approximation near x=3" will appear.

### 3. Part 2: Power Series Solution (`305Project6_c.py`)

This script generates and plots the power series solution for the differential equation $(x^2 + 4)y'' + y = x$.

**To Run:**
```bash
python 305Project6_c.py
```
**Expected Output:** A plot titled "Power Series Solution for (x^2 + 4)y'' + y = x" will be shown.

### 4. Part 3: CPU Temperature Model (`305Project1_Project6_Part3.py`)

This script models the thermal behavior of a CPU under a constant processing load by solving the ordinary differential equation (ODE) that governs its temperature change over time.

**To Run:**
```bash
python 305Project1_Project6_Part3.py
```
**Expected Output:** A plot titled "CPU Temperature Over Time" will be displayed, charting the CPU's temperature in degrees Celsius versus time in seconds.
