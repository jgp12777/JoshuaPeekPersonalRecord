#Joshua Peek (Student ID: 21081733)
import numpy as np
import matplotlib.pyplot as plt

# Define x range from 0 to 5
x = np.linspace(0, 5, 100)
# Taylor polynomial up to x^4
y_taylor = 1 - x - (1/3) * x**3 - (1/12) * x**4

# Plot
plt.plot(x, y_taylor, label='Taylor Polynomial (n≤4)')
plt.axhline(0, color='black', linewidth=0.5)
plt.axvline(0, color='black', linewidth=0.5)
plt.title('Taylor Polynomial Approximation at x=0')
plt.xlabel('x')
plt.ylabel('y')
plt.legend()
plt.grid(True)
# Set y-axis limits from 0 to -60
plt.ylim(-60, 20)
plt.show()