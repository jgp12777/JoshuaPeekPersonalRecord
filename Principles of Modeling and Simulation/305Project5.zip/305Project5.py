# 305Project5.py
# Programmer: Joshua Peek (Student ID: 21081733)
# Course: 305 Principles of Modeling and Simulation
# Instructor: Ricardo Citro
# Description: Models file system fragmentation using the Lorenz attractor. The system simulates chaotic behavior
#              due to file save/delete operations, with x(t) as fragmentation level, y(t) as file access time, and
#              z(t) as storage utilization. Initial conditions x(0), y(0), z(0) are set to real file sizes from
#              file-3.bin (8 KB), file-2.bin (5 KB), and file-1.bin (3 KB). The parameter r represents
#              the rate of file operations. A critical threshold on y(t) triggers a "system too slow" alert.
# Packages: numpy (numerical computations), matplotlib (visualization)
# Approach: Uses Euler method to solve Lorenz equations, visualizes 3D attractor and time series plots, prompts for
#           r values (3, 8, 28), and checks for critical threshold on y(t).

import numpy as np
import matplotlib.pyplot as plt

def lorenz(x, y, z, s=10, r=28, b=2.667):
    '''
    Given:
       x, y, z: a point in 3D space representing fragmentation level, file access time, and storage utilization
       s, r, b: parameters defining the Lorenz attractor (s=fragmentation spread, r=file operation rate, b=utilization decay)
    Returns:
       x_dot, y_dot, z_dot: partial derivatives at the point x, y, z
    '''
    x_dot = s * (y - x)
    y_dot = r * x - y - x * z
    z_dot = x * y - b * z
    return x_dot, y_dot, z_dot

# Parameters
dt = 0.01  # Step size for Euler method
num_steps = 10000  # Number of simulation steps
critical_threshold = 50  # Threshold for file access time (y) to trigger "system too slow"

# Suggested r values from project notes
r_values = [3, 8, 28]

while True:
    # Query for r
    try:
        r_input = input("Enter r (suggested: 3, 8, 28; enter <= 0 or non-numeric to exit): ")
        r = float(r_input)
        if r <= 0:
            print("Exiting simulation.")
            break
    except ValueError:
        print("Invalid input. Exiting simulation.")
        break

    # Initialize arrays
    xs = np.empty(num_steps + 1)
    ys = np.empty(num_steps + 1)
    zs = np.empty(num_steps + 1)

    # Set initial values based on real file sizes
    xs[0] = 8 / 10  # file-3.bin: 8 KB 
    ys[0] = 5 / 10  # file-2.bin: 5 KB  
    zs[0] = 3 / 10  # file-1.bin: 3 KB  

    # Track if critical threshold is reached
    threshold_exceeded = False

    # Simulate dynamics using Euler method
    for i in range(num_steps):
        x_dot, y_dot, z_dot = lorenz(xs[i], ys[i], zs[i], r=r)
        xs[i + 1] = xs[i] + (x_dot * dt)
        ys[i + 1] = ys[i] + (y_dot * dt)
        zs[i + 1] = zs[i] + (z_dot * dt)
        # Check critical threshold for y(t) (file access time)
        if ys[i + 1] > critical_threshold and not threshold_exceeded:
            print(f"Warning: System too slow! File access time (y={ys[i+1]:.2f}) exceeded threshold ({critical_threshold}) at t={i*dt:.2f}")
            threshold_exceeded = True

    # Create time array
    t = np.arange(0, (num_steps + 1) * dt, dt)

    # Close all existing figures to prevent blank Figure 1
    plt.close('all')

    # Create figure with subplots
    fig = plt.figure(figsize=(12, 10))

    # 3D plot of Lorenz attractor
    ax1 = fig.add_subplot(221, projection='3d')
    ax1.plot(xs, ys, zs, lw=1.0, color='blue')
    ax1.set_xlabel("Fragmentation Level (x)")
    ax1.set_ylabel("File Access Time (y)")
    ax1.set_zlabel("Storage Utilization (z)")
    ax1.set_title(f"Lorenz Attractor (r={r})")

    # x(t) plot (fragmentation level)
    ax2 = fig.add_subplot(222)
    ax2.plot(t, xs, lw=1.0, color='red')
    ax2.set_xlabel("Time (t)")
    ax2.set_ylabel("Fragmentation Level x(t)")
    ax2.set_title("Fragmentation Level over Time")
    ax2.grid(True)

    # y(t) plot (file access time) with critical threshold
    ax3 = fig.add_subplot(223)
    ax3.plot(t, ys, lw=1.0, color='green')
    ax3.axhline(y=critical_threshold, color='orange', linestyle='--', label=f'Threshold ({critical_threshold})')
    ax3.set_xlabel("Time (t)")
    ax3.set_ylabel("File Access Time y(t)")
    ax3.set_title("File Access Time over Time")
    ax3.legend()
    ax3.grid(True)

    # z(t) plot (storage utilization)
    ax4 = fig.add_subplot(224)
    ax4.plot(t, zs, lw=1.0, color='purple')
    ax4.set_xlabel("Time (t)")
    ax4.set_ylabel("Storage Utilization z(t)")
    ax4.set_title("Storage Utilization over Time")
    ax4.grid(True)

    # Adjust layout
    plt.tight_layout()
    plt.show()
