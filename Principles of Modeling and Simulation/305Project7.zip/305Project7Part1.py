# Header Comment
# Programmer: Joshua Peek
# Code Packages: numpy, scipy, matplotlib
# Approach:
# 1. Set the parameters (sigma, rho, beta) at the top of the script.
# 2. Define a function for the Lorenz system of ODEs.
# 3. Use scipy.integrate.solve_ivp to numerically solve the ODEs.
# 4. Use matplotlib to create and display a 3D plot of the solution.
#    To see different results, modify the parameter values and re-run the script.

import numpy as np
from scipy.integrate import solve_ivp
import matplotlib.pyplot as plt

# --- Parameters to Modify ---
# Classic chaotic parameters
sigma = 7.0
rho = 31.0
beta = 12.0 / 3.0
# --------------------------

# Define the Lorenz system of ODEs
def lorenz(t, xyz, sigma, rho, beta):
    x, y, z = xyz
    dxdt = sigma * (y - x)
    dydt = x * (rho - z) - y
    dzdt = x * y - beta * z
    return [dxdt, dydt, dzdt]

# Function to solve and plot the Lorenz system
def solve_and_plot(sigma_val, rho_val, beta_val):
    # Initial conditions and time span
    initial_conditions = [0., 1., 1.05]
    t_span = [0, 50]
    t_eval = np.linspace(t_span[0], t_span[1], 10000)

    # Solve the ODEs
    solution = solve_ivp(
        lorenz,
        t_span,
        initial_conditions,
        args=(sigma_val, rho_val, beta_val),
        dense_output=True,
        t_eval=t_eval
    )

    # Plot the result
    fig = plt.figure(figsize=(10, 8))
    ax = fig.add_subplot(111, projection='3d')
    ax.plot(solution.y[0], solution.y[1], solution.y[2], lw=0.5)
    ax.set_xlabel("X Axis")
    ax.set_ylabel("Y Axis")
    ax.set_zlabel("Z Axis")
    ax.set_title(f"Lorenz Attractor (σ={sigma_val:.2f}, ρ={rho_val:.2f}, β={beta_val:.2f})")
    
    # This command displays the plot in a new window
    plt.show()

# --- Main execution ---
if __name__ == "__main__":
    solve_and_plot(sigma, rho, beta)