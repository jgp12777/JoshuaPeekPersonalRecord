import pandas as pd
import matplotlib.pyplot as plt
import numpy as np
# Approach:
# 1. Define arrival times and service durations in a DataFrame.
# 2. Simulate a First-Come, First-Served (FCFS) queue by calculating:
#    - Service start times (max of arrival time and previous customer's exit)
#    - Exit times (service start + duration)
#    - Time spent in queue (service start - arrival time)
# 3. For each customer, compute the number of customers already in the system and in queue upon their arrival.
# 4. Visualize the results using 5 plots:
#    - Service start vs. arrival time
#    - Exit time vs. arrival time
#    - Time in queue vs. arrival time
#    - Number in system on arrival
#    - Number in queue on arrival
# --- Data and Initial Setup ---
data = {
    'Arrival Time': [1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15],
    'Service Duration': [2.22, 1.76, 2.13, 0.14, 0.76, 0.70, 0.47, 0.22, 0.18, 2.41, 0.41, 0.46, 1.37, 0.27, 0.27]
}
df = pd.DataFrame(data)
df['Customer #'] = df.index + 1

# --- Calculations ---
df['Service Start'] = 0.0
df['Exit Time'] = 0.0
df['Time in Queue'] = 0.0
df['Num in System on Arrival'] = 0
df['Num in Queue on Arrival'] = 0

exit_time_prev = 0
for i in df.index:
    arrival_time = df.loc[i, 'Arrival Time']
    service_duration = df.loc[i, 'Service Duration']
    
    service_start = max(arrival_time, exit_time_prev)
    df.loc[i, 'Service Start'] = service_start
    
    df.loc[i, 'Exit Time'] = service_start + service_duration
    df.loc[i, 'Time in Queue'] = service_start - arrival_time
    
    exit_time_prev = df.loc[i, 'Exit Time']

    in_system = df[(df['Arrival Time'] < arrival_time) & (df['Exit Time'] > arrival_time)]
    df.loc[i, 'Num in System on Arrival'] = len(in_system)
    
    in_queue = df[(df['Arrival Time'] < arrival_time) & (df['Service Start'] > arrival_time)]
    df.loc[i, 'Num in Queue on Arrival'] = len(in_queue)

# --- Generate Plots (With Improved Spacing) ---
plt.style.use('seaborn-v0_8-whitegrid')
fig, axs = plt.subplots(3, 2, figsize=(15, 18))
fig.suptitle('FCFS Single Server Queue Analysis', fontsize=16)

# Plot 1: Service Start Time vs. Arrival Time
axs[0, 0].plot(df['Arrival Time'], df['Service Start'], 'o-', label='Service Start Time')
axs[0, 0].plot(df['Arrival Time'], df['Arrival Time'], 'r--', label='Arrival Time (y=x)')
axs[0, 0].set_title('1. Service Start Time vs. Arrival Time')
axs[0, 0].set_xlabel('Customer Arrival Time (min)')
axs[0, 0].set_ylabel('Service Start Time (min)')
axs[0, 0].legend()

# Plot 2: Exit Time vs. Arrival Time
axs[0, 1].plot(df['Arrival Time'], df['Exit Time'], 'o-', color='green', label='Exit Time')
axs[0, 1].set_title('2. Exit Time vs. Arrival Time')
axs[0, 1].set_xlabel('Customer Arrival Time (min)')
axs[0, 1].set_ylabel('System Exit Time (min)')
axs[0, 1].legend()

# Plot 3: Time in Queue vs. Arrival Time
axs[1, 0].bar(df['Arrival Time'], df['Time in Queue'], color='purple', label='Time in Queue')
axs[1, 0].set_title('3. Time in Queue vs. Arrival Time')
axs[1, 0].set_xlabel('Customer Arrival Time (min)')
axs[1, 0].set_ylabel('Time in Queue (min)')
axs[1, 0].legend()

# Plot 4: Number of Customers in System (on Arrival)
axs[1, 1].step(df['Arrival Time'], df['Num in System on Arrival'], where='post', color='orange', label='Num in System')
axs[1, 1].set_title('4. Number in System (on Arrival)')
axs[1, 1].set_xlabel('Customer Arrival Time (min)')
axs[1, 1].set_ylabel('Number of Customers in System')
axs[1, 1].legend()
axs[1, 1].set_yticks(np.arange(0, df['Num in System on Arrival'].max() + 2, 1))

# Plot 5: Number of Customers in Queue (on Arrival)
axs[2, 0].step(df['Arrival Time'], df['Num in Queue on Arrival'], where='post', color='cyan', label='Num in Queue')
axs[2, 0].set_title('5. Number in Queue (on Arrival)')
axs[2, 0].set_xlabel('Customer Arrival Time (min)')
axs[2, 0].set_ylabel('Number of Customers in Queue')
axs[2, 0].legend()
axs[2, 0].set_yticks(np.arange(0, df['Num in Queue on Arrival'].max() + 2, 1))

# Hide the last empty subplot
axs[2, 1].set_visible(False)

# NEW: Adjust subplot parameters to give specified padding.
# hspace is the height space between plots, wspace is the width space.
fig.subplots_adjust(left=0.1, bottom=0.05, right=0.9, top=0.93, wspace=0.25, hspace=0.45)

# Show the final plot window
plt.show()