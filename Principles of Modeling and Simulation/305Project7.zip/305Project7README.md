

````markdown
# CST305 - Principles of Modeling and Simulation: Final Assignment

This final project models and analyzes both a chaotic dynamical system (Lorenz attractor) and several queuing theory scenarios including FCFS single-server simulation and performance under scaling factors.

**Author:** Joshua Peek (ID: 21081733)  
**Professor:** Ricardo Citro

---

## Project Overview

The code is divided into three main parts:

1. **Lorenz System Simulation (`305Project7Part1.py`)**  
   Simulates the Lorenz attractor using `solve_ivp` and produces a 3D plot. Users can change the σ (sigma), ρ (rho), and β (beta) parameters to observe different behaviors of the system.

2. **FCFS Queue Analysis (`305Project7Part2.py`)**  
   Implements a First-Come, First-Served single-server queue model with given arrival times and service durations. Visualizes queue metrics like wait time, service start time, and number of customers in queue/system.

3. **Queuing System Scaling (`305Project7Part2_2.py`)**  
   Analyzes the impact of scaling arrival and service rates using queuing formulas (M/M/1 style). Visualizes system metrics such as utilization (ρ), throughput (X), mean number in system (E[N]), and mean time in system (E[T]).

---

## How to Install and Run

### Prerequisites

Ensure Python 3 is installed, along with the following packages:

```bash
pip install numpy scipy matplotlib pandas
````

---

### Running the Scripts

You can run each part separately depending on the analysis you wish to view.

#### 1. **Lorenz System Plotting**

```bash
python 305Project7Part1.py
```

This opens an interactive 3D plot of the Lorenz attractor. Modify the parameters at the top of the file to explore different behaviors.

---

#### 2. **FCFS Queue Simulation**

```bash
python 305Project7Part2.py
```

Generates several plots based on provided customer arrival and service data. These include service times, queue sizes, and system exit times.

---

#### 3. **Queuing System Scaling Analysis**

```bash
python 305Project7Part2_2.py
```

Produces plots showing how system performance metrics change as the arrival and service rates scale together using a factor `k`.

```


```
