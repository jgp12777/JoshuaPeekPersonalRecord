import numpy as np
import matplotlib.pyplot as plt
# Approach:
# 1. Define initial arrival rate (λ) and service rate (μ).
# 2. Create a range of scaling factors (k) to simulate how the system performs when both λ and μ increase proportionally.
# 3. Calculate key queuing metrics for each scaled scenario:
#    - Utilization: ρ = λ / μ
#    - Throughput: X = λ
#    - Mean number in system: E[N] = ρ / (1 - ρ)
#    - Mean time in system: E[T] = 1 / (μ - λ)
# 4. Generate a 2x2 grid of plots showing how each metric behaves as the scaling factor increases.

# Initial parameters
lambda_initial = 10
mu_initial = 20

# Scaling factors
k = np.linspace(0.1, 5, 50)

# New rates
lambda_new = k * lambda_initial
mu_new = k * mu_initial

# Calculate metrics
rho_new = lambda_new / mu_new
X_new = lambda_new
E_N_new = rho_new / (1 - rho_new)
E_T_new = 1 / (mu_new - lambda_new)

# Plotting
fig, axs = plt.subplots(2, 2, figsize=(12, 10))
fig.suptitle('Effect of Scaling Arrival and Service Rates by Factor k', fontsize=16)

axs[0, 0].plot(k, rho_new, 'r')
axs[0, 0].set_title('a. Utilization (ρ)')
axs[0, 0].set_xlabel('Scaling Factor k')
axs[0, 0].set_ylabel('Utilization ρ\'')
axs[0, 0].axhline(y=lambda_initial/mu_initial, linestyle='--', color='gray')


axs[0, 1].plot(k, X_new, 'g')
axs[0, 1].set_title('b. Throughput (X)')
axs[0, 1].set_xlabel('Scaling Factor k')
axs[0, 1].set_ylabel('Throughput X\'')

axs[1, 0].plot(k, E_N_new, 'b')
axs[1, 0].set_title('c. Mean Number in System (E[N])')
axs[1, 0].set_xlabel('Scaling Factor k')
axs[1, 0].set_ylabel('E[N]\'')
axs[1, 0].axhline(y=(lambda_initial/mu_initial)/(1-(lambda_initial/mu_initial)), linestyle='--', color='gray')

axs[1, 1].plot(k, E_T_new, 'm')
axs[1, 1].set_title('d. Mean Time in System (E[T])')
axs[1, 1].set_xlabel('Scaling Factor k')
axs[1, 1].set_ylabel('E[T]\'')

plt.tight_layout(rect=[0, 0, 1, 0.96])
plt.show()