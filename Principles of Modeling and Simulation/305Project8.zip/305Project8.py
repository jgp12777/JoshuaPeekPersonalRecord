# CST-305 Project 8: Numerical Integration
# Programmer: Joshua Peek (21081733)
# Packages: numpy, matplotlib, scipy
# Approach: Implements Riemann sums (left, right, midpoint) for numerical integration,
# plots functions with rectangles, and simulates network data transfer.

import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad

# Numerical integration function using Riemann sums
def riemann_integral(f, a, b, n, method='midpoint'):
    """
    Compute Riemann sum for function f over [a, b] with n subintervals.
    method: 'left', 'right', or 'midpoint'
    Returns: Approximate integral value
    """
    dx = (b - a) / n
    if method == 'left':
        x_k = np.linspace(a, b - dx, n)
    elif method == 'right':
        x_k = np.linspace(a + dx, b, n)
    else:  # midpoint
        x_k = np.linspace(a + dx/2, b - dx/2, n)
    return np.sum(f(x_k) * dx)

# Part 1a: Plot f(x) = sin(x) + 1 over [-pi, pi] with Riemann sums (n=4)
def plot_riemann_sin():
    f = lambda x: np.sin(x) + 1
    a, b = -np.pi, np.pi
    n = 4
    dx = (b - a) / n
    
    # Generate fine mesh for plotting the function
    x = np.linspace(a, b, 1000)
    y = f(x)
    
    for method, title in [('left', 'Left Endpoint'), ('right', 'Right Endpoint'), ('midpoint', 'Midpoint')]:
        plt.figure(figsize=(8, 6))
        plt.plot(x, y, 'b-', label='f(x) = sin(x) + 1')
        
        # Compute points for Riemann sum
        if method == 'left':
            x_k = np.linspace(a, b - dx, n)
            align = 'edge'
            width = dx
        elif method == 'right':
            x_k = np.linspace(a + dx, b, n)
            align = 'edge'
            width = -dx  # Negative width to align right edge
        else:
            x_k = np.linspace(a + dx/2, b - dx/2, n)
            align = 'center'
            width = dx
        
        # Plot rectangles
        for xi in x_k:
            plt.bar(xi, f(xi), width=width, alpha=0.3, align=align, edgecolor='k')
        
        plt.title(f'Riemann Sum with {title} (n={n})')
        plt.xlabel('x')
        plt.ylabel('f(x)')
        plt.legend()
        plt.grid(True)
        plt.show()

# Part 1c.1: Numerical integration and plot for ln(x) over [1, e]
def plot_ln_integral():
    f = lambda x: np.log(x)
    a, b = 1, np.e
    n = 1000  # High granularity for numerical integration
    
    # Compute numerical integral
    integral = riemann_integral(f, a, b, n, method='midpoint')
    print(f"Integral of ln(x) from 1 to e (numerical): {integral:.6f}")
    
    # Analytical verification using SciPy
    analytical, _ = quad(f, a, b)
    print(f"Integral of ln(x) from 1 to e (analytical): {analytical:.6f}")
    
    # Plot
    x = np.linspace(a, b, 1000)
    y = f(x)
    plt.figure(figsize=(8, 6))
    plt.plot(x, y, 'b-', label='f(x) = ln(x)')
    plt.fill_between(x, y, alpha=0.2, color='blue')
    plt.title('Integral of ln(x) from 1 to e')
    plt.xlabel('x')
    plt.ylabel('f(x)')
    plt.legend()
    plt.grid(True)
    plt.show()

# Part 2: Network data transfer simulation
def network_data_transfer():
    # Simulated download rate: R(t) = -0.0025*(t**3) - 0.0116*(t**2) + 1.446*t + 9.5692 Mbps
    R = lambda t: -0.0025*(t**3) - 0.0116*(t**2) + 1.446*t + 9.5692
    a, b = 0, 30  # 30 minutes
    n = 1000  # High granularity
    
    # Compute total data in megabits (Mbps * minutes * 60 = Mb)
    total_mb = riemann_integral(R, a, b, n, method='midpoint') * 60
    # Convert to megabytes (1 Mb = 1/8 MB)
    total_mb = total_mb / 8
    print(f"Total data downloaded: {total_mb:.2f} MB")
    
    # Generate table of rates at 1-minute intervals
    times = np.arange(0, 31, 1)
    rates = R(times)
    print("\nTime (min) | Rate (Mbps)")
    print("-" * 25)
    for t, r in zip(times, rates):
        print(f"{t:10d} | {r:.6f}")
    
    # Plot rate function
    x = np.linspace(a, b, 1000)
    plt.figure(figsize=(8, 6))
    plt.plot(x, R(x), 'r-', label='R(t) = -0.0025*(t**3) - 0.0116*(t**2) + 1.446*t + 9.5692')
    plt.title('Download Rate Over Time')
    plt.xlabel('Time (minutes)')
    plt.ylabel('Rate (Mbps)')
    plt.legend()
    plt.grid(True)
    plt.show()

# Main execution
if __name__ == '__main__':
    print("CST-305 Project 8: Numerical Integration")
    print("\nPart 1a: Plotting sin(x) + 1 with Riemann sums")
    plot_riemann_sin()
    
    print("\nPart 1c.1: Integral of ln(x) from 1 to e")
    plot_ln_integral()
    
    print("\nPart 2: Network Data Transfer")
    network_data_transfer()
    
    # Analytical results for verification
    print("\nAnalytical Results (computed by hand):")
    print("Integral of 3x + 2x^2 from 0 to 1: 13/6 ≈ 2.1667")
    print("Integral of x^2 - x^3 from -1 to 0: 7/12 ≈ 0.5833")