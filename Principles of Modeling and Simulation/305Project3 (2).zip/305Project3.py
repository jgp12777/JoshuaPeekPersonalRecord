import numpy as np
import matplotlib.pyplot as plt
from scipy.integrate import quad

# Green's function for ODE 1: y'' + y = 4
def green_function_ode1(t, s):
    if t < s:
        return 0
    return np.sin(t - s)  # c1 = -sin s, c2 = cos s

# Green's function for ODE 2: y'' + 4y = t
def green_function_ode2(t, s):
    if t < s:
        return 0
    return 0.5 * np.sin(2 * (t - s))  # c1 = -0.5*sin(2s), c2 = 0.5*cos(2s)

# Green’s function solutions (numerical integration for verification)
def green_solution_ode1(t):
    def integrand(s):
        return green_function_ode1(t, s) * 4
    result, _ = quad(integrand, 0, t)
    return result

def green_solution_ode2(t):
    def integrand(s):
        return green_function_ode2(t, s) * s
    result, _ = quad(integrand, 0, t)
    return result

# Analytical solutions (used for both methods, as they are identical)
def analytical_solution_ode1(t):
    return 4 * (1 - np.cos(t))  # Green’s and Undetermined Coefficients

def analytical_solution_ode2(t):
    return (t / 4) - (1/8) * np.sin(2*t)  # Green’s and Undetermined Coefficients

# Time array
t = np.linspace(0, 10, 200)

# Plot 1: ODE 1 Green’s Function Solution
plt.figure(figsize=(6, 4))
plt.plot(t, analytical_solution_ode1(t), label='Green’s Function: y(t) = 4(1 - cos(t))', color='red')
plt.title("ODE 1: Green’s Function Solution")
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.grid(True)
plt.tight_layout()

# Plot 2: ODE 1 Undetermined Coefficients Solution
plt.figure(figsize=(6, 4))
plt.plot(t, analytical_solution_ode1(t), label='Undetermined Coefficients: y(t) = 4(1 - cos(t))', color='blue', linestyle='--')
plt.title("ODE 1: Undetermined Coefficients Solution")
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.grid(True)
plt.tight_layout()

# Plot 3: ODE 2 Green’s Function Solution
plt.figure(figsize=(6, 4))
plt.plot(t, analytical_solution_ode2(t), label='Green’s Function: y(t) = t/4 - (1/8)sin(2t)', color='red')
plt.title("ODE 2: Green’s Function Solution")
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.grid(True)
plt.tight_layout()

# Plot 4: ODE 2 Undetermined Coefficients Solution
plt.figure(figsize=(6, 4))
plt.plot(t, analytical_solution_ode2(t), label='Undetermined Coefficients: y(t) = t/4 - (1/8)sin(2t)', color='blue', linestyle='--')
plt.title("ODE 2: Undetermined Coefficients Solution")
plt.xlabel('t')
plt.ylabel('y(t)')
plt.legend()
plt.grid(True)
plt.tight_layout()

plt.show()