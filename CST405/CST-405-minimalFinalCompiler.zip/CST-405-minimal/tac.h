#ifndef TAC_H
#define TAC_H

#include "ast.h"

/* THREE-ADDRESS CODE (TAC)
 * Intermediate representation between AST and machine code
 * Each instruction has at most 3 operands (result = arg1 op arg2)
 * Makes optimization and code generation easier
 */

/* TAC INSTRUCTION TYPES */
typedef enum {
    TAC_ADD,     /* Addition: result = arg1 + arg2 */
    TAC_ASSIGN,  /* Assignment: result = arg1 */
    TAC_PRINT,   /* Print: print(arg1) */
    TAC_DECL,     /* Declaration: declare result */
    TAC_SUB,     /* Subtraction: result = arg1 - arg2 */
    TAC_ARRAY_DECL,   // Declare array: arg1 = name, arg2 = total size in bytes
    TAC_ARRAY_LOAD,   // Load array element: result = arg1[arg2]
    TAC_ARRAY_STORE,  // Store array element: arg1[arg2] = result
    TAC_MUL,          // Multiplication for array index calculations
    TAC_DIV,          // Division for array index calculations
    TAC_NOP,          // No operation (used in optimizations)

    /* function / call related TAC ops */
    TAC_LABEL,        /* label: arg1 holds label name */
    TAC_PARAM,        /* push parameter: arg1 holds param temp/const */
    TAC_CALL,         /* call function: arg1 = function name, result = dest temp */
    TAC_RET,          /* return: arg1 holds return temp/const (may be NULL for void) */
    TAC_FUNC_BEGIN,   /* function begin: arg1 = function name */
    TAC_FUNC_END,      /* function end: arg1 = function name */

    /* control flow */
    TAC_GOTO,       /* unconditional jump: arg1 = label */
    TAC_IFZ         /* if arg1 == 0 goto result (result holds label name) */
} TACOp;

/* TAC INSTRUCTION STRUCTURE */
typedef struct TACInstr {
    TACOp op;               /* Operation type */
    char* arg1;             /* First operand (if needed) */
    char* arg2;             /* Second operand (for binary ops) */
    char* result;           /* Result/destination */
    struct TACInstr* next;  /* Linked list pointer */
} TACInstr;

/* TAC LIST MANAGEMENT */
typedef struct {
    TACInstr* head;    /* First instruction */
    TACInstr* tail;    /* Last instruction (for efficient append) */
    int tempCount;     /* Counter for temporary variables (t0, t1, ...) */
} TACList;

/* TAC GENERATION FUNCTIONS */
void initTAC();                                                    /* Initialize TAC lists */
char* newTemp();                                                   /* Generate new temp variable */
TACInstr* createTAC(TACOp op, char* arg1, char* arg2, char* result); /* Create TAC instruction */
void appendTAC(TACInstr* instr);                                  /* Add instruction to list */
void generateTAC(ASTNode* node);                                  /* Convert AST to TAC */
char* generateTACExpr(ASTNode* node);                             /* Generate TAC for expression */

/* TAC OPTIMIZATION AND OUTPUT */
void printTAC();                                                   /* Display unoptimized TAC */
void optimizeTAC();                                                /* Apply optimizations */
void removeNOPs(void);                                             /* Remove NOPs (declared) */ 
void printOptimizedTAC();                                          /* Display optimized TAC */

#endif