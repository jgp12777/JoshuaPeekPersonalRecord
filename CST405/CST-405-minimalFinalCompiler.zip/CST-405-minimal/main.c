/* MINIMAL C COMPILER - EDUCATIONAL VERSION
 * Demonstrates all phases of compilation with a simple language
 * Supports: int variables, addition, assignment, print
 */
#include <stdio.h>
#include <stdlib.h>
#include "ast.h"
#include "codegen.h"
#include "tac.h"
#include "symtab.h"
#include "benchmark.h"

/* Ensure the global symbol table and AST stats accessors are visible */
extern SymbolTable symtab;
int get_ast_total_allocations(void);
int get_ast_pool_count(void);
size_t get_ast_total_memory(void);

extern int yyparse();
extern FILE* yyin;
extern ASTNode* root;

static void test_symbol_table_performance(void) {
    BenchmarkResult* bench = start_benchmark();

    char varname[64];
    for (int i = 0; i < 1000; ++i) {
        snprintf(varname, sizeof(varname), "var%d", i);
        addVar(varname);
    }

    for (int i = 0; i < 1000; ++i) {
        snprintf(varname, sizeof(varname), "var%d", i);
        getVarOffset(varname);
    }

    end_benchmark(bench, "Symbol Table");

    /* symtab is declared in symtab.h as 'extern SymbolTable symtab' */
    printf("Collisions: %d\n", symtab.collisions);
    printf("Lookups   : %d\n", symtab.lookups);

    /* use AST getters exposed in ast.h */
    printf("Total allocations: %d\n", get_ast_total_allocations());
    printf("Memory pools: %d\n", get_ast_pool_count());
    printf("Total memory: %zu bytes\n", get_ast_total_memory());

    free(bench);
}

int main(int argc, char* argv[]) {
    if (argc != 3) {
        printf("Usage: %s <input.c> <output.s>\n", argv[0]);
        printf("Example: ./minicompiler test.c output.s\n");
        return 1;
    }
    
    yyin = fopen(argv[1], "r");
    if (!yyin) {
        fprintf(stderr, "Error: Cannot open input file '%s'\n", argv[1]);
        return 1;
    }
    
    printf("\n");
    printf("╔════════════════════════════════════════════════════════════╗\n");
    printf("║          MINIMAL C COMPILER - EDUCATIONAL VERSION         ║\n");
    printf("╚════════════════════════════════════════════════════════════╝\n");
    printf("\n");
    
    /* PHASE 1: Lexical and Syntax Analysis */
    printf("┌──────────────────────────────────────────────────────────┐\n");
    printf("│ PHASE 1: LEXICAL & SYNTAX ANALYSIS                       │\n");
    printf("├──────────────────────────────────────────────────────────┤\n");
    printf("│ • Reading source file: %s\n", argv[1]);
    printf("│ • Tokenizing input (scanner.l)\n");
    printf("│ • Parsing grammar rules (parser.y)\n");
    printf("│ • Building Abstract Syntax Tree\n");
    printf("└──────────────────────────────────────────────────────────┘\n");
    
    initSymTab();        // initialize symbol table
    init_ast_memory();   // initialize AST memory pool

    if (yyparse() == 0) {
        printf("✓ Parse successful - program is syntactically correct!\n\n");
        
        /* PHASE 2: AST Display */
        printf("┌──────────────────────────────────────────────────────────┐\n");
        printf("│ PHASE 2: ABSTRACT SYNTAX TREE (AST)                      │\n");
        printf("├──────────────────────────────────────────────────────────┤\n");
        printf("│ Tree structure representing the program hierarchy:        │\n");
        printf("└──────────────────────────────────────────────────────────┘\n");
        printAST(root, 0);
        printf("\n");
        
        /* PHASE 3: Intermediate Code */
        printf("┌──────────────────────────────────────────────────────────┐\n");
        printf("│ PHASE 3: INTERMEDIATE CODE GENERATION                    │\n");
        printf("├──────────────────────────────────────────────────────────┤\n");
        printf("│ Three-Address Code (TAC) - simplified instructions:       │\n");
        printf("│ • Each instruction has at most 3 operands                │\n");
        printf("│ • Temporary variables (t0, t1, ...) for expressions      │\n");
        printf("└──────────────────────────────────────────────────────────┘\n");
        initTAC();
        generateTAC(root);
        printTAC();
        printf("\n");
        
        /* PHASE 4: Optimization */
        printf("┌──────────────────────────────────────────────────────────┐\n");
        printf("│ PHASE 4: CODE OPTIMIZATION                               │\n");
        printf("├──────────────────────────────────────────────────────────┤\n");
        printf("│ Applying optimizations:                                  │\n");
        printf("│ • Constant folding (evaluate compile-time expressions)   │\n");
        printf("│ • Copy propagation (replace variables with values)       │\n");
        printf("└──────────────────────────────────────────────────────────┘\n");
        optimizeTAC();
        printOptimizedTAC();
        printf("\n");
        
        /* PHASE 5: Code Generation */
        printf("┌──────────────────────────────────────────────────────────┐\n");
        printf("│ PHASE 5: MIPS CODE GENERATION                            │\n");
        printf("├──────────────────────────────────────────────────────────┤\n");
        printf("│ Translating to MIPS assembly:                            │\n");
        printf("│ • Variables stored on stack                              │\n");
        printf("│ • Using $t0-$t7 for temporary values                     │\n");
        printf("│ • System calls for print operations                      │\n");
        printf("└──────────────────────────────────────────────────────────┘\n");
        generateMIPS(root, argv[2]);
        printf("✓ MIPS assembly code generated to: %s\n", argv[2]);
        printf("\n");
        
        printf("╔════════════════════════════════════════════════════════════╗\n");
        printf("║                  COMPILATION SUCCESSFUL!                   ║\n");
        printf("║         Run the output file in a MIPS simulator           ║\n");
        printf("╚════════════════════════════════════════════════════════════╝\n");
    } else {
        printf("✗ Parse failed - check your syntax!\n");
        printf("Common errors:\n");
        printf("  • Missing semicolon after statements\n");
        printf("  • Undeclared variables\n");
        printf("  • Invalid syntax for print statements\n");
        return 1;
    }

    /* Optionally run the performance test after compilation */
    test_symbol_table_performance();

    fclose(yyin);
    return 0;
}