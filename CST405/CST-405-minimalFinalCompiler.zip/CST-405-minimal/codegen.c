#include <stdio.h>
#include <stdlib.h>
#include "codegen.h"
#include "symtab.h"
#include "parser.tab.h"    // EQ, NE, LE, GE, AND, OR, NOT



FILE* output;
int tempReg = 0;
int labelCount = 0;

/* -------- helpers (no renames of your existing funcs) -------- */

static int in_text_section = 0;  /* track current section to avoid noisy switches */

static void ensure_data_section(void) {
    if (in_text_section) {
        fprintf(output, ".data\n");
        in_text_section = 0;
    }
}

static void ensure_text_section(void) {
    if (!in_text_section) {
        fprintf(output, ".text\n");
        in_text_section = 1;
    }
}

int getNextTemp() {
    int reg = tempReg++;
    if (tempReg > 7) tempReg = 0;  // Reuse $t0-$t7
    return reg;
}

void genExpr(ASTNode* node) {
    if (!node) return;

    switch(node->type) {
        case NODE_NUM:
            fprintf(output, "    li $t%d, %d\n", getNextTemp(), node->data.num);
            break;

        case NODE_VAR: {
            SymbolEntry* e = lookupSymbol(node->data.name);
            if (!e) {
                fprintf(stderr, "Error: Variable %s not declared\n", node->data.name);
                exit(1);
            }
            int r = getNextTemp();
            if (e->isGlobal) {
                /* global scalar: load via label */
                ensure_text_section();
                fprintf(output, "    la $t%d, %s\n", r, e->name);
                fprintf(output, "    lw $t%d, 0($t%d)\n", r, r);
            } else {
                /* local scalar: -offset($fp) */
                ensure_text_section();
                fprintf(output, "    lw $t%d, -%d($fp)\n", r, e->offset);
            }
            break;
        }

        case NODE_BINOP: {
            genExpr(node->data.binop.left);
            int leftReg = tempReg - 1;
            genExpr(node->data.binop.right);
            int rightReg = tempReg - 1;
            int dest = leftReg;

            int op = node->data.binop.op;
            ensure_text_section();
            if (op == '+') {
                fprintf(output, "    add $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
            } else if (op == '-') {
                fprintf(output, "    sub $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
            } else if (op == '*') {
                fprintf(output, "    mul $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
            } else if (op == '/') {
                fprintf(output, "    div $t%d, $t%d\n", leftReg, rightReg);
                fprintf(output, "    mflo $t%d\n", leftReg);
            } else {
                /* relational / logical ops produce 0/1 in dest */
                switch(op) {
                    case EQ:  fprintf(output, "    seq $t%d, $t%d, $t%d\n", dest, leftReg, rightReg); break;
                    case NE:  fprintf(output, "    sne $t%d, $t%d, $t%d\n", dest, leftReg, rightReg); break;
                    case '<': fprintf(output, "    slt $t%d, $t%d, $t%d\n", dest, leftReg, rightReg); break;
                    case '>': fprintf(output, "    sgt $t%d, $t%d, $t%d\n", dest, leftReg, rightReg); break;
                    case LE:
                        fprintf(output, "    sgt $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
                        fprintf(output, "    xori $t%d, $t%d, 1\n", dest, dest);
                        break;
                    case GE:
                        fprintf(output, "    slt $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
                        fprintf(output, "    xori $t%d, $t%d, 1\n", dest, dest);
                        break;
                    case AND:
                        fprintf(output, "    sne $t%d, $t%d, $zero\n", leftReg, leftReg);
                        fprintf(output, "    sne $t%d, $t%d, $zero\n", rightReg, rightReg);
                        fprintf(output, "    and $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
                        break;
                    case OR:
                        fprintf(output, "    sne $t%d, $t%d, $zero\n", leftReg, leftReg);
                        fprintf(output, "    sne $t%d, $t%d, $zero\n", rightReg, rightReg);
                        fprintf(output, "    or $t%d, $t%d, $t%d\n", dest, leftReg, rightReg);
                        break;
                    default:
                        break;
                }
            }
            tempReg = dest + 1;
            break;
        }

        case NODE_UNARY: {
            genExpr(node->data.unary.expr);
            int src = tempReg - 1;
            ensure_text_section();
            if (node->data.unary.op == NOT) {
                /* result = (src == 0) ? 1 : 0 */
                fprintf(output, "    sltiu $t%d, $t%d, 1\n", src, src);
            } else if (node->data.unary.op == '-') {
                fprintf(output, "    sub $t%d, $zero, $t%d\n", src, src);
            }
            break;
        }

        case NODE_ARRAY_ACCESS: {
            SymbolEntry* e = lookupSymbol(node->data.array_access.name);
            if (!e) {
                fprintf(stderr, "Error: Array %s not declared\n", node->data.array_access.name);
                exit(1);
            }
            genExpr(node->data.array_access.index);
            int idx = tempReg - 1;

            ensure_text_section();
            fprintf(output, "    sll $t%d, $t%d, 2\n", idx, idx); /* idx *= 4 */

            if (e->isGlobal) {
                /* addr = &name + idx ; load *(addr) */
                int r = idx; /* reuse */
                fprintf(output, "    la $t%d, %s\n", r, e->name);
                fprintf(output, "    addu $t%d, $t%d, $t%d\n", r, r, idx);
                fprintf(output, "    lw $t%d, 0($t%d)\n", r, r);
                tempReg = r + 1;
            } else {
                /* local array base at -offset($fp) — your existing scheme */
                fprintf(output, "    subu $t%d, $fp, $t%d\n", idx, idx);           /* t(idx) = fp - (idx*4) */
                fprintf(output, "    lw $t%d, -%d($t%d)\n", idx, e->offset, idx);  /* load *(fp - idx*4 - offset) */
                tempReg = idx + 1;
            }
            break;
        }

        case NODE_CALL: {
            ensure_text_section();
            fprintf(output, "    subu $sp, $sp, 32\n");
            fprintf(output, "    sw $ra, 28($sp)\n");

            ASTNode* arg = node->data.call.args;
            int argCount = 0;
            while (arg && argCount < 4) {
                genExpr(arg->data.paramlist.param);
                fprintf(output, "    move $a%d, $t%d\n", argCount, tempReg-1);
                arg = arg->data.paramlist.next;
                argCount++;
            }

            fprintf(output, "    jal func_%s\n", node->data.call.name);
            fprintf(output, "    lw $ra, 28($sp)\n");
            fprintf(output, "    addu $sp, $sp, 32\n");
            fprintf(output, "    move $t%d, $v0\n", getNextTemp());
            break;
        }

        /* nodes that don't produce values here */
        case NODE_DECL:
        case NODE_ASSIGN:
        case NODE_PRINT:
        case NODE_STMT_LIST:
        case NODE_ARRAY_DECL:
        case NODE_ARRAY_ASSIGN:
        case NODE_FUNC_DECL:
        case NODE_PARAM:
        case NODE_PARAM_LIST:
        case NODE_RETURN:
        case NODE_BLOCK:
        case NODE_IF:
        case NODE_WHILE:
            break;

        default:
            break;
    }
}

void genStmt(ASTNode* node) {
    if (!node) return;

    switch(node->type) {
        case NODE_DECL: {
            int offset = addVar(node->data.name);
            if (offset == -1) {
                fprintf(stderr, "Error: Variable %s already declared\n", node->data.name);
                exit(1);
            }

            /* If in global scope, actually allocate storage in .data */
            if (currentScope && currentScope->scopeLevel == 0) {
                ensure_data_section();
                fprintf(output, "%s: .word 0\n", node->data.name);
                ensure_text_section();
            } else {
                ensure_text_section();
                fprintf(output, "    # Declared %s at offset %d\n", node->data.name, offset);
            }
            break;
        }

        case NODE_ARRAY_DECL: {
            int offset = addArrayVar(node->data.array_decl.name, node->data.array_decl.size);
            if (offset == -1) {
                fprintf(stderr, "Error: Array %s already declared\n", node->data.array_decl.name);
                exit(1);
            }

            if (currentScope && currentScope->scopeLevel == 0) {
                /* global array storage */
                ensure_data_section();
                fprintf(output, "%s: .space %d\n", node->data.array_decl.name, node->data.array_decl.size * 4);
                ensure_text_section();
            } else {
                ensure_text_section();
                fprintf(output, "    # Declared array %s[%d] at offset %d\n",
                        node->data.array_decl.name, node->data.array_decl.size, offset);
            }
            break;
        }

        case NODE_ASSIGN: {
            SymbolEntry* e = lookupSymbol(node->data.assign.var);
            if (!e) {
                fprintf(stderr, "Error: Variable %s not declared\n", node->data.assign.var);
                exit(1);
            }
            genExpr(node->data.assign.value);
            ensure_text_section();
            if (e->isGlobal) {
                int r = tempReg - 1;
                fprintf(output, "    la $t7, %s\n", e->name);
                fprintf(output, "    sw $t%d, 0($t7)\n", r);
            } else {
                fprintf(output, "    sw $t%d, -%d($fp)\n", tempReg-1, e->offset);
            }
            tempReg = 0;
            break;
        }
        case NODE_ARRAY_ASSIGN: {
            SymbolEntry* e = lookupSymbol(node->data.array_assign.name);
            if (!e) {
                fprintf(stderr, "Error: Array %s not declared\n", node->data.array_assign.name);
                exit(1);
            }

            genExpr(node->data.array_assign.index);
            int indexReg = tempReg - 1;
            genExpr(node->data.array_assign.value);
            int valueReg = tempReg - 1;

            ensure_text_section();
            fprintf(output, "    sll $t%d, $t%d, 2\n", indexReg, indexReg); /* idx *= 4 */

            if (e->isGlobal) {
                /* addr = &name + idx ; store value */
                fprintf(output, "    la $t6, %s\n", e->name);
                fprintf(output, "    addu $t6, $t6, $t%d\n", indexReg);
                fprintf(output, "    sw $t%d, 0($t6)\n", valueReg);
            } else {
                /* local array base at -offset($fp) */
                fprintf(output, "    subu $t%d, $fp, $t%d\n", indexReg, indexReg);
                fprintf(output, "    sw $t%d, -%d($t%d)\n", valueReg, e->offset, indexReg);
            }
            tempReg = 0;
            break;
        }
        case NODE_ARRAY_ACCESS: {
            SymbolEntry* e = lookupSymbol(node->data.array_access.name);
            if (!e) {
                fprintf(stderr, "Error: Array %s not declared\n", node->data.array_access.name);
                exit(1);
            }

            /* Generate code for index expression */
            genExpr(node->data.array_access.index);
            int indexReg = tempReg - 1;

            ensure_text_section();
            fprintf(output, "    sll $t%d, $t%d, 2\n", indexReg, indexReg); /* index *= 4 */

            if (e->isGlobal) {
                /* addr = &name + index ; load value into same register */
                int baseReg = getNextTemp();
                fprintf(output, "    la $t%d, %s\n", baseReg, e->name);
                fprintf(output, "    addu $t%d, $t%d, $t%d\n", baseReg, baseReg, indexReg);
                fprintf(output, "    lw $t%d, 0($t%d)\n", indexReg, baseReg);
                tempReg = indexReg + 1;
            } else {
                /* local array base at -offset($fp) — same addressing scheme as in array assign */
                fprintf(output, "    subu $t%d, $fp, $t%d\n", indexReg, indexReg);
                fprintf(output, "    lw $t%d, -%d($t%d)\n", indexReg, e->offset, indexReg);
                tempReg = indexReg + 1;
            }

            break;
        }

        case NODE_PRINT:
            genExpr(node->data.expr);
            ensure_text_section();
            fprintf(output, "    move $a0, $t%d\n", tempReg-1);
            fprintf(output, "    li $v0, 1\n");
            fprintf(output, "    syscall\n");
            fprintf(output, "    li $v0, 11\n");
            fprintf(output, "    li $a0, 10\n");
            fprintf(output, "    syscall\n");
            
            break;

        case NODE_FUNC_DECL: {
            ensure_text_section();
            fprintf(output, "\nfunc_%s:\n", node->data.func_decl.name);

            /* Prologue */
            fprintf(output, "    # Function prologue\n");
            fprintf(output, "    subu $sp, $sp, 32\n");
            fprintf(output, "    sw $ra, 28($sp)\n");
            fprintf(output, "    sw $fp, 24($sp)\n");
            fprintf(output, "    move $fp, $sp\n");
            fprintf(output, "    subu $sp, $sp, 400\n");    // locals

            pushScope();  // function scope

            /* Parameters in $a0..$a3 into local slots */
            ASTNode* param = node->data.func_decl.params;
            int paramCount = 0;
            while (param && paramCount < 4) {
                if (param->data.paramlist.param) {
                    int offset = addVar(param->data.paramlist.param->data.param.name);
                    fprintf(output, "    sw $a%d, -%d($fp)\n", paramCount, offset);
                    paramCount++;
                }
                param = param->data.paramlist.next;
            }

            /* Body */
            genStmt(node->data.func_decl.body);

            /* Epilogue */
            fprintf(output, "    move $sp, $fp\n");
            fprintf(output, "    lw $ra, 28($sp)\n");
            fprintf(output, "    lw $fp, 24($sp)\n");
            fprintf(output, "    addu $sp, $sp, 32\n");
            fprintf(output, "    jr $ra\n");

            popScope();
            break;
        }

        case NODE_RETURN:
            if (node->data.ret.expr) {
                genExpr(node->data.ret.expr);
                ensure_text_section();
                fprintf(output, "    move $v0, $t%d\n", tempReg-1);
            }
            break;

        case NODE_STMT_LIST:
            genStmt(node->data.stmtlist.stmt);
            genStmt(node->data.stmtlist.next);
            break;

        /* forward expression-kind nodes */
        case NODE_NUM:
        case NODE_VAR:
        case NODE_BINOP:
        case NODE_PARAM:
        case NODE_PARAM_LIST:
        case NODE_CALL:
        case NODE_UNARY:
            genExpr(node);
            break;

        case NODE_BLOCK:
            pushScope();
            genStmt(node->data.block.stmtlist);
            popScope();
            break;

        case NODE_IF: {
            int Lfalse = labelCount++;
            int Lend = labelCount++;
            genExpr(node->data.ifstmt.cond);
            ensure_text_section();
            fprintf(output, "    beq $t%d, $zero, L%d\n", tempReg-1, Lfalse);
            genStmt(node->data.ifstmt.then_branch);
            if (node->data.ifstmt.else_branch) {
                fprintf(output, "    j L%d\n", Lend);
                fprintf(output, "L%d:\n", Lfalse);
                genStmt(node->data.ifstmt.else_branch);
                fprintf(output, "L%d:\n", Lend);
            } else {
                fprintf(output, "L%d:\n", Lfalse);
            }
            tempReg = 0;
            break;
        }

        case NODE_WHILE: {
            int Lstart = labelCount++;
            int Lend = labelCount++;
            ensure_text_section();
            fprintf(output, "L%d:\n", Lstart);
            genExpr(node->data.whilestmt.cond);
            fprintf(output, "    beq $t%d, $zero, L%d\n", tempReg-1, Lend);
            genStmt(node->data.whilestmt.body);
            fprintf(output, "    j L%d\n", Lstart);
            fprintf(output, "L%d:\n", Lend);
            tempReg = 0;
            break;
        }

        default:
            break;
    }
}

void generateMIPS(ASTNode* root, const char* filename) {
    output = fopen(filename, "w");
    if (!output) {
        fprintf(stderr, "Cannot open output file %s\n", filename);
        exit(1);
    }

    initSymTab();  // Initialize symbol table
    

    /* Start in .data to allow early global decls; we’ll switch as needed */
    in_text_section = 0;
    fprintf(output, ".data\n");
    fprintf(output, "newline: .asciiz \"\\n\"\n");

    fprintf(output, "\n.text\n");
    in_text_section = 1;
    fprintf(output, ".globl main\n");

    /* Generate all functions and also see global decls; sections will switch as needed */
    genStmt(root);

    /* Program entry point that calls user main() */
    ensure_text_section();
    fprintf(output, "\nmain:\n");
    fprintf(output, "    # Setup main stack frame\n");
    fprintf(output, "    subu $sp, $sp, 32\n");
    fprintf(output, "    sw $ra, 28($sp)\n");
    fprintf(output, "    sw $fp, 24($sp)\n");
    fprintf(output, "    move $fp, $sp\n");
    fprintf(output, "    jal func_main\n");
    fprintf(output, "    # Program exit\n");
    fprintf(output, "    li $v0, 10\n");
    fprintf(output, "    syscall\n");

    popScope();    // Pop global scope
    fclose(output);
}
