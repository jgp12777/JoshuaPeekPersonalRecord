#ifndef BENCHMARK_H
#define BENCHMARK_H

#include <time.h>
#include <sys/time.h>
#include <sys/resource.h>

typedef struct {
    /* start state (internal) */
    clock_t start_cpu;
    double  start_wall;
    long    start_mem_kb;

    /* results (filled by end_benchmark) */
    double cpu_time;      /* seconds */
    double wall_time;     /* seconds */
    long   memory_usage_kb;  /* delta in KB */
    long   peak_memory_kb;   /* peak ru_maxrss in KB */
} BenchmarkResult;

/* Function declarations */
BenchmarkResult* start_benchmark(void);
void end_benchmark(BenchmarkResult* result, const char* phase);
void print_benchmark_stats(BenchmarkResult* result);

#endif