int x;
int y;
int z;
int count;
int sum;

void testLoops() {
    x = 0;
    while (x < 5) {
        print(100);
        x = x + 1;
    }

    x = 0;
    while (x < 3) {
        y = 0;
        while (y < 2) {
            print(200);
            y = y + 1;
        }
        x = x + 1;
    }

    count = 10;
    sum = 0;
    while (count > 0) {
        sum = sum + count;
        count = count - 1;
    }
    print(sum);

    x = 0;
    y = 5;
    while ((x < 3) && (y > 0)) {
        print(300);
        x = x + 1;
        y = y - 1;
    }

    x = 10;
    while (x < 5) {
        print(400);
    }
}

void testOrderOfOperations() {
    x = 2 + 3 * 4;
    print(x);

    y = (2 + 3) * 4;
    print(y);

    z = 10 - 2 * 3 + 4;
    print(z);

    x = (10 - 2) * (3 + 4);
    print(x);

    y = 20 / 4 * 2;
    print(y);

    z = 5 + 3 * 2 - 8 / 4;
    print(z);

    x = ((5 + 3) * 2) - (8 / 4);
    print(x);

    if (2 + 3 * 4 == 14)
        print(500);

    if (5 + 5 > 3 * 3)
        print(600);

    if (10 - 2 * 3 < 5)
        print(601);

    count = 0;
    while (count < (2 + 3)) {
        print(700);
        count = count + 1;
    }

}

int main() {
    testLoops();
    testOrderOfOperations();
    return 0;
}
//participation i'm having fun 12/10/25 JP :P