#ifndef AST_H
#define AST_H

/* ABSTRACT SYNTAX TREE (AST)
 * The AST is an intermediate representation of the program structure
 * It represents the hierarchical syntax of the source code
 * Each node represents a construct in the language
 */

/* NODE TYPES - Different kinds of AST nodes in our language */
typedef enum {
    NODE_NUM,       /* Numeric literal (e.g., 42) */
    NODE_VAR,       /* Variable reference (e.g., x) */
    NODE_BINOP,     /* Binary operation (e.g., x + y) */
    NODE_DECL,      /* Variable declaration (e.g., int x) */
    NODE_ASSIGN,    /* Assignment statement (e.g., x = 10) */
    NODE_PRINT,     /* Print statement (e.g., print(x)) */
    NODE_STMT_LIST, /* List of statements (program structure) */
    NODE_ARRAY_DECL,    /* Array declaration (int x[10]) */
    NODE_ARRAY_ACCESS,  /* Array access (x[i]) */
    NODE_ARRAY_ASSIGN,  /* Array assignment (x[i] = value) */

    /* New node kinds */
    NODE_FUNC_DECL,     /* Function declaration */
    NODE_PARAM,         /* Single parameter */
    NODE_PARAM_LIST,    /* Linked list of parameters/args */
    NODE_CALL,          /* Function call */
    NODE_RETURN,         /* Return statement */
    NODE_BLOCK,      /* compound statement { ... } with its own stmt list */
    NODE_IF,         /* if statement */
    NODE_WHILE,     /* while statement */

    NODE_UNARY,     /* unary operator node (e.g. !, unary -) */
} NodeType;

/* AST NODE STRUCTURE
 * Uses a union to efficiently store different node data
 * Only the relevant fields for each node type are used
 */
typedef struct ASTNode {
    NodeType type;  /* Identifies what kind of node this is */
    
    /* Union allows same memory to store different data types */
    union {
        /* Literal number value (NODE_NUM) */
        int num;

        /* Variable or declaration name (NODE_VAR, NODE_DECL) */
        char* name;

        /* Binary operation structure (NODE_BINOP) */
        struct {
            int op;                    /* Operator character ('+') */
            struct ASTNode* left;       /* Left operand */
            struct ASTNode* right;      /* Right operand */
        } binop;

        /* Assignment structure (NODE_ASSIGN) */
        struct {
            char* var;                  /* Variable being assigned to */
            struct ASTNode* value;      /* Expression being assigned */
        } assign;

        /* Print expression (NODE_PRINT) */
        struct ASTNode* expr;

        /* Statement list structure (NODE_STMT_LIST) */
        struct {
            struct ASTNode* stmt;       /* Current statement */
            struct ASTNode* next;       /* Rest of the list */
        } stmtlist;

        /* Array specific structures */
        struct {
            char* name;
            int size;
        } array_decl;

        struct {
            char* name;
            struct ASTNode* index;
        } array_access;

        struct {
            char* name;
            struct ASTNode* index;
            struct ASTNode* value;
        } array_assign;

        /* Function declaration */
        struct {
            char* name;
            int   retToken;     /* token for return type (INT/FLOAT/VOID) */
            struct ASTNode* params; /* NODE_PARAM_LIST */
            struct ASTNode* body;   /* NODE_STMT_LIST */
        } func_decl;

        /* Parameter (single) */
        struct {
            char* name;
            int   typeToken;    /* token for type (INT/FLOAT) */
        } param;

        /* Parameter / argument linked list */
        struct {
            struct ASTNode* param;  /* NODE_PARAM or expression for args */
            struct ASTNode* next;
        } paramlist;

        /* Function call */
        struct {
            char* name;
            struct ASTNode* args; /* NODE_PARAM_LIST where nodes are expressions */
        } call;

        /* Return statement */
        struct {
            struct ASTNode* expr; /* may be NULL for 'return;' */
        } ret;
        struct {
            struct ASTNode* stmtlist; /* for BLOCK */
        } block;

        struct {
            struct ASTNode* cond;
            struct ASTNode* then_branch;
            struct ASTNode* else_branch; /* may be NULL */
        } ifstmt;

        struct {
            struct ASTNode* cond;
            struct ASTNode* body;
        } whilestmt;

        struct {                    /* for unary operators */
            int op;                 /* operator token (e.g. NOT, '-') */
            struct ASTNode* expr;   /* operand */
        } unary;
    } data;
} ASTNode;

/* AST CONSTRUCTION FUNCTIONS
 * These functions are called by the parser to build the tree
 */
ASTNode* createNum(int value);                                   /* Create number node */
ASTNode* createVar(char* name);                                  /* Create variable node */
ASTNode* createBinOp(int op, ASTNode* left, ASTNode* right);   /* Create binary op node */
ASTNode* createDecl(char* name);                                 /* Create declaration node */
ASTNode* createAssign(char* var, ASTNode* value);               /* Create assignment node */
ASTNode* createPrint(ASTNode* expr);                            /* Create print node */
ASTNode* createStmtList(ASTNode* stmt1, ASTNode* stmt2);        /* Create statement list */
ASTNode* createArrayDecl(char* name, int size);
ASTNode* createArrayAccess(char* name, ASTNode* index);
ASTNode* createArrayAssign(char* name, ASTNode* index, ASTNode* value);

/* New constructors for functions, params, calls, return */
ASTNode* createFuncDecl(char* name, int retToken, ASTNode* params, ASTNode* body);
ASTNode* createParam(char* name, int typeToken);
ASTNode* createParamList(ASTNode* param, ASTNode* next); /* builds NODE_PARAM_LIST */
ASTNode* createCall(char* name, ASTNode* args);
ASTNode* createReturn(ASTNode* expr);

ASTNode* createIfStmt(ASTNode* cond, ASTNode* then_b, ASTNode* else_b);
ASTNode* createWhileStmt(ASTNode* cond, ASTNode* body);
ASTNode* createBlock(ASTNode* stmtlist);
ASTNode* createUnaryOp(int op, ASTNode* expr);

/* AST DISPLAY FUNCTION */
void printAST(ASTNode* node, int level);                        /* Pretty-print the AST */
/* memory pool API (Task 2) */
void init_ast_memory(void);

/* getters for memory pool statistics (exposed to other modules) */
int get_ast_total_allocations(void);
int get_ast_pool_count(void);
size_t get_ast_total_memory(void);

/* Semantic checker: traverse AST and report semantic errors */
int checkSemantics(ASTNode* root);

#endif