#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "symtab.h"

SymbolTable symtab;
Scope* currentScope = NULL;

/* djb2 hash */
unsigned int hash(const char* str) {
    unsigned long h = 5381;
    int c;
    while ((c = (unsigned char)*str++))
        h = ((h << 5) + h) + c;
    return (unsigned int)(h % HASH_SIZE);
}

/* Push new scope */
void pushScope(void) {
    Scope* s = (Scope*)calloc(1, sizeof(Scope));
    if (!s) {
        fprintf(stderr, "FATAL: pushScope allocation failed\n");
        exit(1);
    }
    s->outer = currentScope;
    s->scopeLevel = (currentScope ? currentScope->scopeLevel + 1 : 0);
    s->localOffset = 0;
    currentScope = s;
}

/* Pop scope */
void popScope(void) {
    if (!currentScope) return;
    for (int i = 0; i < HASH_SIZE; ++i) {
        SymbolEntry* e = currentScope->table[i];
        while (e) {
            SymbolEntry* nxt = e->next;
            free(e->name);
            free(e);
            e = nxt;
        }
    }
    Scope* outer = currentScope->outer;
    free(currentScope);
    currentScope = outer;
}

/* Initialize symbol table */
void initSymTab(void) {
    symtab.count = 0;
    symtab.nextOffset = 0;
    symtab.lookups = 0;
    symtab.collisions = 0;
    symtab.globalOffset = 0;
    currentScope = NULL;
    pushScope();  // global scope
}

/* Add symbol to current scope */
int addSymbol(const char* name, VarType type, int isArray, int arraySize) {
    SymbolEntry* outer = lookupSymbol(name);
    if (outer && outer->isGlobal && currentScope->scopeLevel > 0) {
        return outer->offset;
    }
    if (!currentScope) pushScope();

    /* 🔹 If symbol already exists in any visible scope, reuse it instead of shadowing */
    SymbolEntry* existing = lookupSymbol(name);
    if (existing != NULL) {
        return existing->offset;
    }

    unsigned int b = hash(name);

    SymbolEntry* e = currentScope->table[b];
    while (e) {
        if (strcmp(e->name, name) == 0 && e->scopeLevel == currentScope->scopeLevel) {
            return -1;
        }
        e = e->next;
        symtab.collisions++;
    }

    SymbolEntry* ne = (SymbolEntry*)malloc(sizeof(SymbolEntry));
    if (!ne) return -1;
    ne->name = strdup(name);
    ne->type = type;
    ne->isArray = isArray ? 1 : 0;
    ne->arraySize = (isArray ? arraySize : 1);
    ne->scopeLevel = currentScope->scopeLevel;
    ne->isGlobal = (currentScope->scopeLevel == 0);

    int sizeBytes = (isArray ? arraySize * 4 : 4);
    if (ne->isGlobal) {
        ne->offset = symtab.globalOffset;
        symtab.globalOffset += sizeBytes;
    } else {
        ne->offset = currentScope->localOffset + sizeBytes;
        currentScope->localOffset = ne->offset;
    }

    ne->next = currentScope->table[b];
    currentScope->table[b] = ne;
    symtab.count++;
    return ne->offset;  
}

/* Convenience wrappers */
int addVar(char* name) { return addSymbol(name, TYPE_INT, 0, 0); }
int addArrayVar(char* name, int arrayElems) {
    int offset = addSymbol(name, TYPE_INT, 1, arrayElems);
    SymbolEntry* e = lookupSymbol(name);
    if (e && currentScope->scopeLevel == 0) {
        e->isGlobal = 1;
    }
    return offset;
}
/* Lookup symbol in current -> outer -> global */
SymbolEntry* lookupSymbol(const char* name) {
    symtab.lookups++;
    Scope* s = currentScope;
    while (s) {
        unsigned int b = hash(name);
        SymbolEntry* e = s->table[b];
        while (e) {
            if (strcmp(e->name, name) == 0) return e;
            e = e->next;
            symtab.collisions++;
        }
        s = s->outer;
    }
    return NULL;
}

/* Get offset */
int getVarOffset(const char* name) {
    SymbolEntry* e = lookupSymbol(name);
    if (!e) return -1;
    return e->offset;
}

/* Is array? */
int isArray(const char* name) {
    SymbolEntry* e = lookupSymbol(name);
    if (!e) return 0;
    return e->isArray;
}

/* Array size */
int getArraySize(const char* name) {
    SymbolEntry* e = lookupSymbol(name);
    if (!e) return -1;
    return e->arraySize;
}
