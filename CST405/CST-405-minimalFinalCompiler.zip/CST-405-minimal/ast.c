#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"
#include "symtab.h"
#include "parser.tab.h"   /* add token definitions (INT/FLOAT/VOID) */

extern int yylineno; /* lexer line number */

/* Forward declarations for internal helpers */
static int semantic_check_node(ASTNode* node, int currentRetToken);
static int expr_type(ASTNode* expr, int* outType);

/* Public entry: perform semantic checks on the AST.
   Returns number of semantic errors found (0 == OK). */
int checkSemantics(ASTNode* root) {
    if (!root) return 0;
    int errors = 0;

    /* Ensure symbol table exists */
    initSymTab();

    /* Start in global scope (already pushed by initSymTab).
       Traverse top-level statements. */
    errors += semantic_check_node(root, -1);
    return errors;
}

/* Determine expression type:
   returns 0 on success and sets *outType to TYPE_INT/FLOAT/VOID,
   returns non-zero on error (and prints message). */
static int expr_type(ASTNode* expr, int* outType) {
    if (!expr) return 1;
    switch (expr->type) {
        case NODE_NUM:
            *outType = TYPE_INT;
            return 0;
        case NODE_VAR: {
            SymbolEntry* e = lookupSymbol(expr->data.name);
            if (!e) {
                fprintf(stderr, "Semantic Error (line %d): use of undeclared variable '%s'\n",
                        yylineno, expr->data.name);
                return 1;
            }
            *outType = e->type;
            return 0;
        }
        case NODE_ARRAY_ACCESS: {
            SymbolEntry* e = lookupSymbol(expr->data.array_access.name);
            if (!e) {
                fprintf(stderr, "Semantic Error (line %d): use of undeclared array '%s'\n",
                        yylineno, expr->data.array_access.name);
                return 1;
            }
            if (!e->isArray) {
                fprintf(stderr, "Semantic Error (line %d): '%s' is not an array\n",
                        yylineno, expr->data.array_access.name);
                return 1;
            }
            /* check index if constant */
            int idxType;
            if (expr_type(expr->data.array_access.index, &idxType) != 0) return 1;
            if (expr->data.array_access.index->type == NODE_NUM) {
                int idx = expr->data.array_access.index->data.num;
                if (idx < 0 || idx >= e->arraySize) {
                    fprintf(stderr, "Semantic Error (line %d): array index %d out of bounds for '%s' (size %d)\n",
                            yylineno, idx, expr->data.array_access.name, e->arraySize);
                    return 1;
                }
            }
            *outType = e->type;
            return 0;
        }
        case NODE_BINOP: {
            int lt, rt;
            if (expr_type(expr->data.binop.left, &lt) != 0) return 1;
            if (expr_type(expr->data.binop.right, &rt) != 0) return 1;
            if (lt != rt) {
                fprintf(stderr, "Semantic Warning (line %d): implicit type mismatch in binary op ('%c') between types %d and %d\n",
                        yylineno, expr->data.binop.op, lt, rt);
                /* allow but choose integer for now */
            }
            *outType = lt; /* simplistic */
            return 0;
        }
        case NODE_CALL:
            /* Function signatures are not stored in symbol table in current design.
               Conservatively accept calls (could be extended to track functions). */
            *outType = TYPE_INT;
            return 0;
        default:
            /* For other nodes, conservatively return error */
            return 1;
    }
}

/* Recursively check a node. currentRetToken is the token value for the enclosing function's return type
   (INT/FLOAT/VOID), or -1 when not inside a function. Returns number of errors found under this node. */
static int semantic_check_node(ASTNode* node, int currentRetToken) {
    if (!node) return 0;
    int errors = 0;

    switch (node->type) {
        case NODE_STMT_LIST:
            errors += semantic_check_node(node->data.stmtlist.stmt, currentRetToken);
            errors += semantic_check_node(node->data.stmtlist.next, currentRetToken);
            break;

        case NODE_DECL: {
            int off = addVar(node->data.name);
            if (off == -1) {
                fprintf(stderr, "Semantic Error (line %d): duplicate declaration of '%s'\n",
                        yylineno, node->data.name);
                errors++;
            }
            break;
        }

        case NODE_ARRAY_DECL: {
            int size = node->data.array_decl.size;
            if (size <= 0) {
                fprintf(stderr, "Semantic Error (line %d): invalid array size %d for '%s'\n",
                        yylineno, size, node->data.array_decl.name);
                errors++;
            } else {
                int off = addArrayVar(node->data.array_decl.name, size);
                if (off == -1) {
                    fprintf(stderr, "Semantic Error (line %d): duplicate array declaration '%s'\n",
                            yylineno, node->data.array_decl.name);
                    errors++;
                }
            }
            break;
        }

        case NODE_ASSIGN: {
            /* check LHS declared */
            SymbolEntry* e = lookupSymbol(node->data.assign.var);
            if (!e) {
                fprintf(stderr, "Semantic Error (line %d): assignment to undeclared variable '%s'\n",
                        yylineno, node->data.assign.var);
                errors++;
            }
            /* check RHS expression */
            int t;
            if (expr_type(node->data.assign.value, &t) != 0) errors++;
            break;
        }

        case NODE_ARRAY_ASSIGN: {
            SymbolEntry* e = lookupSymbol(node->data.array_assign.name);
            if (!e) {
                fprintf(stderr, "Semantic Error (line %d): assignment to undeclared array '%s'\n",
                        yylineno, node->data.array_assign.name);
                errors++;
                break;
            }
            if (!e->isArray) {
                fprintf(stderr, "Semantic Error (line %d): '%s' used as array but not declared as array\n",
                        yylineno, node->data.array_assign.name);
                errors++;
            }
            /* check index */
            int it;
            if (expr_type(node->data.array_assign.index, &it) != 0) errors++;
            if (node->data.array_assign.index->type == NODE_NUM) {
                int idx = node->data.array_assign.index->data.num;
                if (idx < 0 || idx >= e->arraySize) {
                    fprintf(stderr, "Semantic Error (line %d): array index %d out of bounds for '%s' (size %d)\n",
                            yylineno, idx, node->data.array_assign.name, e->arraySize);
                    errors++;
                }
            }
            /* check value */
            if (expr_type(node->data.array_assign.value, &it) != 0) errors++;
            break;
        }

        case NODE_PRINT:
            if (expr_type(node->data.expr, &(int){0}) != 0) errors++;
            break;

        case NODE_FUNC_DECL: {
            /* Register function name (optional): we do not have function symbol model here, skip global registry */
            /* Enter new scope for function body */
            pushScope();
            /* add parameters as variables in new scope */
            ASTNode* p = node->data.func_decl.params;
            while (p) {
                ASTNode* single = p->data.paramlist.param;
                if (single && single->type == NODE_PARAM) {
                    int typeToken = single->data.param.typeToken;
                    (void)typeToken; /* silence unused-variable warning */
                    /* treat params as ints for now */
                    int off = addVar(single->data.param.name);
                    if (off == -1) {
                        fprintf(stderr, "Semantic Error (line %d): duplicate parameter name '%s' in function '%s'\n",
                                yylineno, single->data.param.name, node->data.func_decl.name);
                        errors++;
                    }
                }
                p = p->data.paramlist.next;
            }
            /* check body; pass the function's return token */
            errors += semantic_check_node(node->data.func_decl.body, node->data.func_decl.retToken);
            popScope();
            break;
        }

        case NODE_RETURN: {
            if (currentRetToken == -1) {
                fprintf(stderr, "Semantic Error (line %d): 'return' used outside of function\n", yylineno);
                errors++;
            } else {
                if (node->data.ret.expr == NULL) {
                    if (currentRetToken != VOID) {
                        fprintf(stderr, "Semantic Error (line %d): missing return value for non-void function\n", yylineno);
                        errors++;
                    }
                } else {
                    int rtype;
                    if (expr_type(node->data.ret.expr, &rtype) != 0) errors++;
                    else {
                        /* coarse check: token vs TYPE_INT */
                        if (currentRetToken == INT && rtype != TYPE_INT) {
                            fprintf(stderr, "Semantic Warning (line %d): return type mismatch (expected int)\n", yylineno);
                        }
                        if (currentRetToken == VOID) {
                            fprintf(stderr, "Semantic Error (line %d): returning a value from void function\n", yylineno);
                            errors++;
                        }
                    }
                }
            }
            break;
        }

        case NODE_CALL:
            /* basic check: nothing known about signature currently */
            /* check argument expressions */
            {
                ASTNode* a = node->data.call.args;
                while (a) {
                    errors += (expr_type(a->data.paramlist.param, &(int){0}) != 0);
                    a = a->data.paramlist.next;
                }
            }
            break;

        case NODE_BINOP:
            errors += (expr_type(node->data.binop.left, &(int){0}) != 0);
            errors += (expr_type(node->data.binop.right, &(int){0}) != 0);
            break;

        case NODE_BLOCK:
            pushScope();
            errors += semantic_check_node(node->data.block.stmtlist, currentRetToken);
            popScope();
            break;

        case NODE_IF: {
            int t;
            if (expr_type(node->data.ifstmt.cond, &t) != 0) errors++;
            errors += semantic_check_node(node->data.ifstmt.then_branch, currentRetToken);
            if (node->data.ifstmt.else_branch)
                errors += semantic_check_node(node->data.ifstmt.else_branch, currentRetToken);
            break;
        }

        case NODE_WHILE: {
            int t;
            if (expr_type(node->data.whilestmt.cond, &t) != 0) errors++;
            /* body has its own block scope if it's a BLOCK; else preserve current scope semantics */
            errors += semantic_check_node(node->data.whilestmt.body, currentRetToken);
            break;
        }

        default:
            /* other nodes handled by expr_type or not relevant */
            break;
    }

    return errors;
}

static ASTNode* newNode(NodeType type) {
    ASTNode* n = (ASTNode*)malloc(sizeof(ASTNode));
    if (!n) {
        fprintf(stderr, "Out of memory while creating AST node\n");
        exit(1);
    }
    memset(n, 0, sizeof(ASTNode));
    n->type = type;
    return n;
}

ASTNode* createNum(int value) {
    ASTNode* n = newNode(NODE_NUM);
    n->data.num = value;
    return n;
}

ASTNode* createVar(char* name) {
    ASTNode* n = newNode(NODE_VAR);
    n->data.name = strdup(name);
    return n;
}

ASTNode* createBinOp(int op, ASTNode* left, ASTNode* right) {
    ASTNode* n = newNode(NODE_BINOP);
    n->data.binop.op = op;
    n->data.binop.left = left;
    n->data.binop.right = right;
    return n;
}

ASTNode* createDecl(char* name) {
    ASTNode* n = newNode(NODE_DECL);
    n->data.name = strdup(name);
    return n;
}

ASTNode* createAssign(char* var, ASTNode* value) {
    ASTNode* n = newNode(NODE_ASSIGN);
    n->data.assign.var = strdup(var);
    n->data.assign.value = value;
    return n;
}

ASTNode* createPrint(ASTNode* expr) {
    ASTNode* n = newNode(NODE_PRINT);
    n->data.expr = expr;
    return n;
}

ASTNode* createStmtList(ASTNode* stmt1, ASTNode* stmt2) {
    ASTNode* n = newNode(NODE_STMT_LIST);
    n->data.stmtlist.stmt = stmt1;
    n->data.stmtlist.next = stmt2;
    return n;
}

ASTNode* createArrayDecl(char* name, int size) {
    ASTNode* n = newNode(NODE_ARRAY_DECL);
    n->data.array_decl.name = strdup(name);
    n->data.array_decl.size = size;
    return n;
}

ASTNode* createArrayAccess(char* name, ASTNode* index) {
    ASTNode* n = newNode(NODE_ARRAY_ACCESS);
    n->data.array_access.name = strdup(name);
    n->data.array_access.index = index;
    return n;
}

ASTNode* createArrayAssign(char* name, ASTNode* index, ASTNode* value) {
    ASTNode* n = newNode(NODE_ARRAY_ASSIGN);
    n->data.array_assign.name = strdup(name);
    n->data.array_assign.index = index;
    n->data.array_assign.value = value;
    return n;
}

ASTNode* createFuncDecl(char* name, int retToken, ASTNode* params, ASTNode* body) {
    ASTNode* n = newNode(NODE_FUNC_DECL);
    n->data.func_decl.name = strdup(name);
    n->data.func_decl.retToken = retToken;
    n->data.func_decl.params = params;
    n->data.func_decl.body = body;
    return n;
}

ASTNode* createParam(char* name, int typeToken) {
    ASTNode* n = newNode(NODE_PARAM);
    n->data.param.name = strdup(name);
    n->data.param.typeToken = typeToken;
    return n;
}

ASTNode* createParamList(ASTNode* param, ASTNode* next) {
    ASTNode* n = newNode(NODE_PARAM_LIST);
    n->data.paramlist.param = param;
    n->data.paramlist.next = next;
    return n;
}

ASTNode* createCall(char* name, ASTNode* args) {
    ASTNode* n = newNode(NODE_CALL);
    n->data.call.name = strdup(name);
    n->data.call.args = args;
    return n;
}

ASTNode* createReturn(ASTNode* expr) {
    ASTNode* n = newNode(NODE_RETURN);
    n->data.ret.expr = expr;
    return n;
}

ASTNode* createBlock(ASTNode* stmtlist) {
    ASTNode* n = newNode(NODE_BLOCK);
    n->data.block.stmtlist = stmtlist;
    return n;
}

ASTNode* createIfStmt(ASTNode* cond, ASTNode* then_b, ASTNode* else_b) {
    ASTNode* n = newNode(NODE_IF);
    n->data.ifstmt.cond = cond;
    n->data.ifstmt.then_branch = then_b;
    n->data.ifstmt.else_branch = else_b;
    return n;
}

ASTNode* createWhileStmt(ASTNode* cond, ASTNode* body) {
    ASTNode* n = newNode(NODE_WHILE);
    n->data.whilestmt.cond = cond;
    n->data.whilestmt.body = body;
    return n;
}

/* create a unary operator node */
ASTNode* createUnaryOp(int op, ASTNode* expr) {
    ASTNode* n = newNode(NODE_UNARY);
    n->data.unary.op = op;
    n->data.unary.expr = expr;
    return n;
}

int get_ast_total_allocations(void) { return 0; }

int get_ast_pool_count(void) { return 1; }

size_t get_ast_total_memory(void) { return 0; }

void init_ast_memory(void) {
    /* Initialize memory pool if needed. */
}

void printAST(ASTNode* node, int level) {
    if (!node) return;

    for (int i = 0; i < level; i++)
        printf("  ");  // indentation

    switch (node->type) {
        case NODE_NUM:
            printf("NUM: %d\n", node->data.num);
            break;

        case NODE_VAR:
            printf("VAR: %s\n", node->data.name);
            break;

        case NODE_DECL:
            printf("DECL: %s\n", node->data.name);
            break;

        case NODE_ASSIGN:
            printf("ASSIGN: %s =\n", node->data.assign.var);
            printAST(node->data.assign.value, level + 1);
            break;

        case NODE_BINOP:
            printf("BINOP: %c\n", node->data.binop.op);
            printAST(node->data.binop.left, level + 1);
            printAST(node->data.binop.right, level + 1);
            break;

        case NODE_PRINT:
            printf("PRINT\n");
            printAST(node->data.expr, level + 1);
            break;

        case NODE_STMT_LIST:
            printf("STMT_LIST\n");
            printAST(node->data.stmtlist.stmt, level + 1);
            printAST(node->data.stmtlist.next, level + 1);
            break;

        case NODE_FUNC_DECL:
            printf("FUNC_DECL: %s\n", node->data.func_decl.name);
            printAST(node->data.func_decl.params, level + 1);
            printAST(node->data.func_decl.body, level + 1);
            break;

        case NODE_RETURN:
            printf("RETURN\n");
            if (node->data.ret.expr)
                printAST(node->data.ret.expr, level + 1);
            break;

        case NODE_BLOCK:
            printf("BLOCK\n");
            printAST(node->data.block.stmtlist, level + 1);
            break;

        case NODE_IF:
            printf("IF\n");
            printAST(node->data.ifstmt.cond, level + 1);
            printAST(node->data.ifstmt.then_branch, level + 1);
            if (node->data.ifstmt.else_branch) {
                printf("ELSE\n");
                printAST(node->data.ifstmt.else_branch, level + 1);
            }
            break;

        case NODE_WHILE:
            printf("WHILE\n");
            printAST(node->data.whilestmt.cond, level + 1);
            printAST(node->data.whilestmt.body, level + 1);
            break;

        default:
            printf("NODE TYPE %d\n", node->type);
            break;
    }
}