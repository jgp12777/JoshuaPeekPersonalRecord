#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <ctype.h>
#include "tac.h"

TACList tacList;
TACList optimizedList;
typedef struct {
    int eliminated_temps;
    int constant_folded;
    int dead_code_removed;
} OptimizationStats;

OptimizationStats opt_stats = {0};

/* Add near top of file */
int OPT_VERBOSE = 1;
static int labelCounter = 0;
char* newLabel() {
    char buf[16];
    sprintf(buf, "L%d", labelCounter++);
    return strdup(buf);
}
// Helper function to check if a string is a constant
static int isConstant(const char* str) {
    if (!str) return 0;
    return isdigit(str[0]) || (str[0] == '-' && isdigit(str[1]));
}
void initTAC() {
    tacList.head = NULL;
    tacList.tail = NULL;
    tacList.tempCount = 0;
    optimizedList.head = NULL;
    optimizedList.tail = NULL;
}

char* newTemp() {
    char* temp = malloc(10);
    sprintf(temp, "t%d", tacList.tempCount++);
    return temp;
}
char* toString(int value) {
    char* str = malloc(20);
    sprintf(str, "%d", value);
    return str;
}

TACInstr* createTAC(TACOp op, char* arg1, char* arg2, char* result) {
    TACInstr* instr = malloc(sizeof(TACInstr));
    instr->op = op;
    instr->arg1 = arg1 ? strdup(arg1) : NULL;
    instr->arg2 = arg2 ? strdup(arg2) : NULL;
    instr->result = result ? strdup(result) : NULL;
    instr->next = NULL;
    return instr;
}

void appendTAC(TACInstr* instr) {
    if (!tacList.head) {
        tacList.head = tacList.tail = instr;
    } else {
        tacList.tail->next = instr;
        tacList.tail = instr;
    }
}

void appendOptimizedTAC(TACInstr* instr) {
    if (!optimizedList.head) {
        optimizedList.head = optimizedList.tail = instr;
    } else {
        optimizedList.tail->next = instr;
        optimizedList.tail = instr;
    }
}

char* generateTACExpr(ASTNode* node) {
    if (!node) return NULL;
    
    switch(node->type) {
        case NODE_NUM: {
            char* temp = malloc(20);
            sprintf(temp, "%d", node->data.num);
            return temp;
        }
        
        case NODE_VAR:
            return strdup(node->data.name);
        
        case NODE_BINOP: {
            char* left = generateTACExpr(node->data.binop.left);
            char* right = generateTACExpr(node->data.binop.right);
            char* temp = newTemp();
            
            if (node->data.binop.op == '+') {
                appendTAC(createTAC(TAC_ADD, left, right, temp));
            } else if (node->data.binop.op == '-') {
                appendTAC(createTAC(TAC_SUB, left, right, temp));
            } else if (node->data.binop.op == '*') {
                appendTAC(createTAC(TAC_MUL, left, right, temp));
            } else if (node->data.binop.op == '/') {
                /* use DIV as sequence in codegen; represent as SUB/MUL etc or add TAC_DIV */
                /* For now emit MUL by inverse - or extend TAC enum later */
                appendTAC(createTAC(TAC_MUL, left, right, temp)); /* placeholder */
            }
            
            return temp;
        }
        case NODE_ARRAY_ACCESS: {
            char* index = generateTACExpr(node->data.array_access.index);
            char* temp = newTemp();
            char* offset = newTemp();
            appendTAC(createTAC(TAC_MUL, index, "4", offset));  // 4 bytes per int
            appendTAC(createTAC(TAC_ARRAY_LOAD, node->data.array_access.name, offset, temp));
            return temp;
        }

        case NODE_CALL: {
            /* Evaluate args left-to-right and emit PARAM per arg (args are expressions) */
            ASTNode* a = node->data.call.args;
            while (a) {
                char* aexpr = generateTACExpr(a->data.paramlist.param);
                appendTAC(createTAC(TAC_PARAM, aexpr, NULL, NULL));
                a = a->data.paramlist.next;
            }
            /* allocate result temp for call (may be NULL for void functions) */
            char* dest = newTemp();
            appendTAC(createTAC(TAC_CALL, node->data.call.name, NULL, dest));
            return dest;
        }
        
        default:
            return NULL;
    }
}

void generateTAC(ASTNode* node) {
    if (!node) return;
    
    switch(node->type) {
        case NODE_DECL:
            appendTAC(createTAC(TAC_DECL, NULL, NULL, node->data.name));
            break;
            
        case NODE_ASSIGN: {
            char* expr = generateTACExpr(node->data.assign.value);
            appendTAC(createTAC(TAC_ASSIGN, expr, NULL, node->data.assign.var));
            break;
        }
        
        case NODE_PRINT: {
            char* expr = generateTACExpr(node->data.expr);
            appendTAC(createTAC(TAC_PRINT, expr, NULL, NULL));
            break;
        }
        
        case NODE_STMT_LIST:
            generateTAC(node->data.stmtlist.stmt);
            generateTAC(node->data.stmtlist.next);
            break;

        case NODE_ARRAY_DECL: {
            appendTAC(createTAC(TAC_ARRAY_DECL, node->data.array_decl.name, 
                               toString(node->data.array_decl.size * 4), NULL));
            break;
        }
        case NODE_ARRAY_ASSIGN: {
            char* value = generateTACExpr(node->data.array_assign.value);
            char* index = generateTACExpr(node->data.array_assign.index);
            char* offset = newTemp();
            appendTAC(createTAC(TAC_MUL, index, "4", offset));
            appendTAC(createTAC(TAC_ARRAY_STORE, value, offset, 
                               node->data.array_assign.name));
            break;
        }

        case NODE_RETURN: {
            if (node->data.ret.expr) {
                char* r = generateTACExpr(node->data.ret.expr);
                appendTAC(createTAC(TAC_RET, r, NULL, NULL));
            } else {
                appendTAC(createTAC(TAC_RET, NULL, NULL, NULL));
            }
            break;
        }

        case NODE_FUNC_DECL: {
            /* Emit function begin, body (as TAC), and end */
            appendTAC(createTAC(TAC_FUNC_BEGIN, node->data.func_decl.name, NULL, NULL));
            /* push scope / register params handled elsewhere (codegen) */
            generateTAC(node->data.func_decl.body);
            appendTAC(createTAC(TAC_FUNC_END, node->data.func_decl.name, NULL, NULL));
            break;
        }
        
        case NODE_BLOCK:
            generateTAC(node->data.block.stmtlist);
            break;

        case NODE_IF: {
            /* cond -> temp */
            char* cond = generateTACExpr(node->data.ifstmt.cond);
            char* Lend = newLabel();
            char* Lfalse = node->data.ifstmt.else_branch ? newLabel() : Lend;

            /* if cond == 0 goto Lfalse */
            appendTAC(createTAC(TAC_IFZ, cond, NULL, Lfalse));
            /* then */
            generateTAC(node->data.ifstmt.then_branch);
            /* after then, jump to end if else exists */
            if (node->data.ifstmt.else_branch) appendTAC(createTAC(TAC_GOTO, Lend, NULL, NULL));
            /* false label */
            appendTAC(createTAC(TAC_LABEL, Lfalse, NULL, NULL));
            if (node->data.ifstmt.else_branch) generateTAC(node->data.ifstmt.else_branch);
            /* end */
            if (node->data.ifstmt.else_branch) appendTAC(createTAC(TAC_LABEL, Lend, NULL, NULL));
            break;
        }

        case NODE_WHILE: {
            char* Lstart = newLabel();
            char* Lend = newLabel();
            appendTAC(createTAC(TAC_LABEL, Lstart, NULL, NULL));
            char* cond = generateTACExpr(node->data.whilestmt.cond);
            appendTAC(createTAC(TAC_IFZ, cond, NULL, Lend));
            /* body */
            generateTAC(node->data.whilestmt.body);
            appendTAC(createTAC(TAC_GOTO, Lstart, NULL, NULL));
            appendTAC(createTAC(TAC_LABEL, Lend, NULL, NULL));
            break;
        }
        
        default:
            break;
    }
}

void printTAC() {
    printf("Unoptimized TAC Instructions:\n");
    printf("─────────────────────────────\n");
    TACInstr* curr = tacList.head;
    int lineNum = 1;
    while (curr) {
        printf("%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                printf("DECL %s", curr->result);
                printf("          // Declare variable '%s'\n", curr->result);
                break;
            case TAC_ADD:
                printf("%s = %s + %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Add: store result in %s\n", curr->result);
                break;
            case TAC_SUB:
                printf("%s = %s - %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Subtract: store result in %s\n", curr->result);
                break;
            case TAC_ASSIGN:
                printf("%s = %s", curr->result, curr->arg1);
                printf("           // Assign value to %s\n", curr->result);
                break;
            case TAC_PRINT:
                printf("PRINT %s", curr->arg1);
                printf("          // Output value of %s\n", curr->arg1);
                break;

            /* Array ops */
            case TAC_ARRAY_DECL:
                printf("ARRAY_DECL %s, %s\n", curr->arg1, curr->arg2);
                break;
            case TAC_ARRAY_LOAD:
                printf("%s = LOAD %s[%s]\n", curr->result, curr->arg1, curr->arg2);
                break;
            case TAC_ARRAY_STORE:
                printf("STORE %s -> %s[%s]\n", curr->arg1, curr->result, curr->arg2);
                break;
            case TAC_MUL:
                printf("%s = %s * %s\n", curr->result, curr->arg1, curr->arg2);
                break;

            /* Function / call related printing */
            case TAC_FUNC_BEGIN:
                printf("FUNC_BEGIN %s\n", curr->arg1);
                break;
            case TAC_FUNC_END:
                printf("FUNC_END %s\n", curr->arg1);
                break;
            case TAC_LABEL:
                printf("LABEL %s\n", curr->arg1);
                break;
            case TAC_PARAM:
                printf("PARAM %s\n", curr->arg1);
                break;
            case TAC_CALL:
                if (curr->result)
                    printf("%s = CALL %s\n", curr->result, curr->arg1);
                else
                    printf("CALL %s\n", curr->arg1);
                break;
            case TAC_RET:
                if (curr->arg1)
                    printf("RET %s\n", curr->arg1);
                else
                    printf("RET\n");
                break;

            default:
                printf("/* unknown op %d */\n", curr->op);
                break;
        }
        curr = curr->next;
    }
}

// Simple optimization: constant folding and copy propagation
void optimizeTAC() {
    TACInstr* current = tacList.head;

    while (current && current->next) {
        // Pattern 1: Constant folding
        if (current->op == TAC_ASSIGN &&
            current->next->op == TAC_ASSIGN &&
            isConstant(current->arg1) &&
            isConstant(current->next->arg1)) {

            TACInstr* third = current->next->next;
            if (third && third->op == TAC_ADD &&
                strcmp(third->arg1, current->result) == 0 &&
                strcmp(third->arg2, current->next->result) == 0) {

                int val1 = atoi(current->arg1);
                int val2 = atoi(current->next->arg1);
                char buffer[20];
                sprintf(buffer, "%d", val1 + val2);

                // Replace with single assignment
                third->op = TAC_ASSIGN;
                third->arg1 = strdup(buffer);
                third->arg2 = NULL;

                // Remove redundant instructions
                current->op = TAC_NOP;
                current->next->op = TAC_NOP;

                opt_stats.constant_folded++;

                if (OPT_VERBOSE) {
                    printf("[opt] constant-fold: replaced %s + %s with %s\n",
                           current->arg1, current->next->arg1, third->arg1);
                }
            }
        }

        // Pattern 2: Copy propagation
        if (current->op == TAC_ASSIGN &&
            current->next->op == TAC_ASSIGN &&
            strcmp(current->next->arg1, current->result) == 0) {

            current->next->arg1 = strdup(current->arg1);
            current->op = TAC_NOP;
            opt_stats.eliminated_temps++;
        }

        current = current->next;
    }

    /* call removeNOPs (prototype above prevents implicit-declaration error) */
    removeNOPs();

    // Print optimization statistics
    printf("\nOptimization Statistics:\n");
    printf("Eliminated temporaries: %d\n", opt_stats.eliminated_temps);
    printf("Constants folded: %d\n", opt_stats.constant_folded);
    printf("Dead code removed: %d\n", opt_stats.dead_code_removed);
}
void removeNOPs() {
    TACInstr* current = tacList.head;
    TACInstr* prev = NULL;

    while (current) {
        if (current->op == TAC_NOP) {
            TACInstr* toDelete = current;
            if (prev) {
                prev->next = current->next;
                current = current->next;
            } else {
                tacList.head = current->next;
                current = current->next;
            }
            opt_stats.dead_code_removed++;
            free(toDelete);
        } else {
            prev = current;
            current = current->next;
        }
    }
}      

void printOptimizedTAC() {
    printf("Optimized TAC Instructions:\n");
    printf("─────────────────────────────\n");
    TACInstr* curr = optimizedList.head;
    int lineNum = 1;
    while (curr) {
        printf("%2d: ", lineNum++);
        switch(curr->op) {
            case TAC_DECL:
                printf("DECL %s\n", curr->result);
                break;
            case TAC_ADD:
                printf("%s = %s + %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Runtime addition needed\n");
                break;
            case TAC_SUB:
                printf("%s = %s - %s", curr->result, curr->arg1, curr->arg2);
                printf("     // Runtime subtraction needed\n");
                break;
            case TAC_ASSIGN:
                printf("%s = %s", curr->result, curr->arg1);
                // Check if it's a constant
                if (curr->arg1[0] >= '0' && curr->arg1[0] <= '9') {
                    printf("           // Constant value: %s\n", curr->arg1);
                } else {
                    printf("           // Copy value\n");
                }
                break;
            case TAC_PRINT:
                printf("PRINT %s", curr->arg1);
                // Check if it's a constant
                if (curr->arg1[0] >= '0' && curr->arg1[0] <= '9') {
                    printf("          // Print constant: %s\n", curr->arg1);
                } else {
                    printf("          // Print variable\n");
                }
                break;
            default:
                break;
        }
        curr = curr->next;
    }
}