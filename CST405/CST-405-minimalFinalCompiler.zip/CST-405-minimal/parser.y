%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "ast.h"

extern int yylex();
extern int yyparse();
extern FILE* yyin;

void yyerror(const char* s);
ASTNode* root = NULL;
%}

/* SEMANTIC VALUE UNION */
%union {
    int num;
    char* str;
    ASTNode* node;
}

/* TOKENS */
%token <num> NUM
%token <str> ID
%token INT FLOAT VOID RETURN PRINT
%token LBRACKET RBRACKET COMMA
%token IF ELSE WHILE
%token EQ NE LE GE AND OR NOT
%token END 0 "end of file"

/* NONTERMINAL TYPES */
%type <node> program external_list global_decl func_def decl_base block_stmt_list block_stmt local_decl assign expr print_stmt param_list param_list_opt param top_stmt_list stmt_top return_stmt arg_list arg_list_opt if_stmt while_stmt
%type <num> type_spec
%left OR
%left AND


%left '+' '-'
%left '*' '/'

/* add these precedence declarations (place after other %left lines) */
%nonassoc LOWER_THAN_ELSE
%nonassoc ELSE 
%nonassoc EQ NE
%nonassoc '<' '>' LE GE
%right NOT
%%

/* ============================================================
   PROGRAM STRUCTURE
============================================================ */
program:
      external_list END {
          printf("[DEBUG] Reduced: program -> external_list (EOF)\n");
          root = $1;
      }
    | external_list top_stmt_list END {
          printf("[DEBUG] Reduced: program -> external_list top_stmt_list (EOF)\n");
          root = createStmtList($1, $2);
      }
    ;

/* ============================================================
   GLOBAL DECLARATIONS & FUNCTION DEFINITIONS
============================================================ */
external_list:
      global_decl {
          printf("[DEBUG] Reduced: external_list -> global_decl\n");
          $$ = $1;
      }
    | external_list global_decl {
          printf("[DEBUG] Reduced: external_list -> external_list global_decl\n");
          $$ = createStmtList($1, $2);
      }
    | func_def {
          printf("[DEBUG] Reduced: external_list -> func_def\n");
          $$ = $1;
      }
    | external_list func_def {
          printf("[DEBUG] Reduced: external_list -> external_list func_def\n");
          $$ = createStmtList($1, $2);
      }
    ;

global_decl:
      decl_base ';' {
          printf("[DEBUG] Reduced: global_decl -> decl_base ;\n");
          $$ = $1;
      }
    ;

/* ============================================================
   DECLARATIONS
============================================================ */
decl_base:
      type_spec ID {
          printf("[DEBUG] Parsed decl_base var: %s\n", $2);
          $$ = createDecl($2);
      }
    | type_spec ID LBRACKET NUM RBRACKET {
          printf("[DEBUG] Parsed decl_base array: %s[%d]\n", $2, $4);
          $$ = createArrayDecl($2, $4);
      }
    ;

type_spec:
      INT   { printf("[DEBUG] Reduced: type_spec -> INT\n"); $$ = INT; }
    | FLOAT { printf("[DEBUG] Reduced: type_spec -> FLOAT\n"); $$ = FLOAT; }
    | VOID  { printf("[DEBUG] Reduced: type_spec -> VOID\n"); $$ = VOID; }
    ;

/* ============================================================
   FUNCTION DEFINITIONS
============================================================ */
func_def:
      type_spec ID '(' param_list_opt ')' '{' block_stmt_list '}' {
          printf("[DEBUG] Parsed function definition: %s\n", $2);
          $$ = createFuncDecl($2, $1, $4, $7);
      }
    ;

param_list_opt:
      /* empty */ { $$ = NULL; }
    | param_list  { $$ = $1; }
    ;

param_list:
      param { $$ = createParamList($1, NULL); }
    | param_list ',' param { $$ = createParamList($3, $1); }
    ;

param:
      INT ID   { printf("[DEBUG] Parameter: %s\n", $2); $$ = createParam($2, INT); }
    | FLOAT ID { printf("[DEBUG] Parameter: %s\n", $2); $$ = createParam($2, FLOAT); }
    ;

/* ============================================================
   BLOCKS AND STATEMENTS
============================================================ */
block_stmt_list:
      block_stmt {
          $$ = $1;
      }
    | block_stmt_list block_stmt {
          $$ = createStmtList($1, $2);
      }
    ;

block_stmt:
      local_decl ';' {
          printf("[DEBUG] Reduced: block_stmt -> local_decl ;\n");
          $$ = $1;
      }
    | assign { $$ = $1; }
    | return_stmt { $$ = $1; }
    | print_stmt { $$ = $1; }
    | expr ';' {
          printf("[DEBUG] Reduced: block_stmt -> expr ;\n");
          $$ = $1;
      }
    | '{' block_stmt_list '}' {
          $$ = createBlock($2);
      }
    | if_stmt { $$ = $1; }
    | while_stmt { $$ = $1; }
    ;

if_stmt:
      IF '(' expr ')' block_stmt %prec LOWER_THAN_ELSE {
          $$ = createIfStmt($3, $5, NULL);
      }
    | IF '(' expr ')' block_stmt ELSE block_stmt {
          $$ = createIfStmt($3, $5, $7);
      }
    ;

while_stmt:
      WHILE '(' expr ')' block_stmt {
          $$ = createWhileStmt($3, $5);
      }
    ;

/* ============================================================
   LOCAL DECLARATIONS
============================================================ */
local_decl:
      decl_base {
          printf("[DEBUG] Reduced: local_decl -> decl_base\n");
          $$ = $1;
      }
    ;

/* ============================================================
   ASSIGNMENTS
============================================================ */
assign:
      ID '=' expr ';' {
          printf("[DEBUG] Reduced: assign -> ID = expr ; (%s)\n", $1);
          $$ = createAssign($1, $3);
          free($1);
      }
    | ID LBRACKET expr RBRACKET '=' expr ';' {
          printf("[DEBUG] Reduced: assign -> ID [ expr ] = expr ; (%s)\n", $1);
          $$ = createArrayAssign($1, $3, $6);
          free($1);
      }
    ;

/* ============================================================
   RETURN STATEMENTS
============================================================ */
return_stmt:
      RETURN expr ';' {
          printf("[DEBUG] Reduced: return_stmt -> RETURN expr ;\n");
          $$ = createReturn($2);
      }
    ;

/* ============================================================
   EXPRESSIONS
============================================================ */
expr:
      NUM {
          $$ = createNum($1);
      }
    | ID {
          $$ = createVar($1);
          free($1);
      }
    | ID '(' arg_list_opt ')' {
          $$ = createCall($1, $3);
          free($1);
      }
    | ID LBRACKET expr RBRACKET {
          $$ = createArrayAccess($1, $3);
          free($1);
      }
    | expr '+' expr { $$ = createBinOp('+', $1, $3); }
    | expr '-' expr { $$ = createBinOp('-', $1, $3); }
    | expr '*' expr { $$ = createBinOp('*', $1, $3); }
    | expr '/' expr { $$ = createBinOp('/', $1, $3); }

    /* relational and equality */
    | expr EQ expr                 { $$ = createBinOp(EQ, $1, $3); }
    | expr NE expr                 { $$ = createBinOp(NE, $1, $3); }
    | expr '<' expr                { $$ = createBinOp('<', $1, $3); }
    | expr '>' expr                { $$ = createBinOp('>', $1, $3); }
    | expr LE expr                 { $$ = createBinOp(LE, $1, $3); }
    | expr GE expr                 { $$ = createBinOp(GE, $1, $3); }

    /* logical */
    | expr AND expr                { $$ = createBinOp(AND, $1, $3); }
    | expr OR expr                 { $$ = createBinOp(OR, $1, $3); }
    | NOT expr                     { $$ = createUnaryOp(NOT, $2); }

    | '(' expr ')'                 { $$ = $2; }
    ;

/* ============================================================
   FUNCTION CALL ARGUMENTS
============================================================ */
arg_list_opt:
      /* empty */ { $$ = NULL; }
    | arg_list { $$ = $1; }
    ;

arg_list:
      expr { $$ = createParamList($1, NULL); }
    | arg_list ',' expr { $$ = createParamList($3, $1); }
    ;

/* ============================================================
   PRINT STATEMENTS
============================================================ */
print_stmt:
      PRINT '(' expr ')' ';' {
          printf("[DEBUG] Reduced: print_stmt -> PRINT ( expr ) ;\n");
          $$ = createPrint($3);
      }
    ;

/* ============================================================
   TOP-LEVEL STATEMENTS (if any)
============================================================ */
top_stmt_list:
      stmt_top { $$ = $1; }
    | top_stmt_list stmt_top { $$ = createStmtList($1, $2); }
    ;

stmt_top:
      assign { $$ = $1; }
    | print_stmt { $$ = $1; }
    ;

%%

void yyerror(const char* s) {
    fprintf(stderr, "Syntax Error: %s\n", s);
}
