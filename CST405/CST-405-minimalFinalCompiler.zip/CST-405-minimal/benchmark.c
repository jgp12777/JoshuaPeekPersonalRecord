#include "benchmark.h"
#include <stdio.h>
#include <stdlib.h>

#ifdef _WIN32
#include <windows.h>
#include <psapi.h>
#else
#include <sys/time.h>
#include <sys/resource.h>
#endif

static long get_current_rss_kb(void) {
#ifdef _WIN32
    PROCESS_MEMORY_COUNTERS pmc;
    if (GetProcessMemoryInfo(GetCurrentProcess(), &pmc, sizeof(pmc))) {
        /* Convert bytes to KB */
        return (long)(pmc.WorkingSetSize / 1024);
    }
    return 0;
#else
    struct rusage ru;
    if (getrusage(RUSAGE_SELF, &ru) == 0) {
        /* ru_maxrss is in KB on Linux */
        return (long)ru.ru_maxrss;
    }
    return 0;
#endif
}

BenchmarkResult* start_benchmark(void) {
    BenchmarkResult* b = (BenchmarkResult*)malloc(sizeof(BenchmarkResult));
    if (!b) return NULL;

    b->start_cpu = clock();

#ifdef _WIN32
    /* wall time using QueryPerformanceCounter on Windows */
    LARGE_INTEGER freq, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    b->start_wall = (double)now.QuadPart / (double)freq.QuadPart;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    b->start_wall = tv.tv_sec + tv.tv_usec / 1000000.0;
#endif

    b->start_mem_kb = get_current_rss_kb();

    b->cpu_time = 0.0;
    b->wall_time = 0.0;
    b->memory_usage_kb = 0;
    b->peak_memory_kb = b->start_mem_kb;
    return b;
}

void end_benchmark(BenchmarkResult* b, const char* phase) {
    if (!b) return;

    clock_t end_cpu = clock();
    b->cpu_time = ((double)(end_cpu - b->start_cpu)) / (double)CLOCKS_PER_SEC;

#ifdef _WIN32
    LARGE_INTEGER freq, now;
    QueryPerformanceFrequency(&freq);
    QueryPerformanceCounter(&now);
    double end_wall = (double)now.QuadPart / (double)freq.QuadPart;
    b->wall_time = end_wall - b->start_wall;
#else
    struct timeval tv;
    gettimeofday(&tv, NULL);
    double end_wall = tv.tv_sec + tv.tv_usec / 1000000.0;
    b->wall_time = end_wall - b->start_wall;
#endif

    long end_mem_kb = get_current_rss_kb();
    b->memory_usage_kb = end_mem_kb - b->start_mem_kb;
    if (end_mem_kb > b->peak_memory_kb) b->peak_memory_kb = end_mem_kb;

    printf("\n=== %s Performance ===\n", phase ? phase : "Benchmark");
    printf("CPU Time : %.6f s\n", b->cpu_time);
    printf("Wall Time: %.6f s\n", b->wall_time);
    printf("Memory Δ : %ld KB\n", b->memory_usage_kb);
    printf("Peak RSS : %ld KB\n", b->peak_memory_kb);
}