#ifndef SYMTAB_H
#define SYMTAB_H

#include <stddef.h>

#define HASH_SIZE 211
#define MAX_VARS 1000

typedef enum { TYPE_INT = 0, TYPE_FLOAT = 1, TYPE_VOID = 2 } VarType;

/* Symbol entry */
typedef struct SymbolEntry {
    char* name;
    VarType type;
    int offset;               /* offset in bytes */
    int isArray;
    int arraySize;
    int scopeLevel;
    int isGlobal;             /* 1 = global scope, 0 = local */
    struct SymbolEntry* next;
} SymbolEntry;

/* Scope (hash table + link to outer scope) */
typedef struct Scope {
    SymbolEntry* table[HASH_SIZE];
    struct Scope* outer;
    int scopeLevel;
    int localOffset;          /* next offset in bytes for locals */
} Scope;

/* Global symbol table stats */
typedef struct {
    int count;
    int nextOffset;           /* total bytes allocated */
    int lookups;
    int collisions;
    int globalOffset;         /* next global memory offset */
} SymbolTable;

/* Global instances */
extern SymbolTable symtab;
extern Scope* currentScope;

/* Scope management */
void initSymTab(void);
void pushScope(void);
void popScope(void);

/* Symbol operations */
int addSymbol(const char* name, VarType type, int isArray, int arraySize);
int addVar(char* name);
int addArrayVar(char* name, int arrayElems);
SymbolEntry* lookupSymbol(const char* name);
int getVarOffset(const char* name);
int isArray(const char* name);
int getArraySize(const char* name);

/* Utility */
unsigned int hash(const char* str);

#endif
