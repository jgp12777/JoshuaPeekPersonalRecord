# Minimal C Compiler - Educational Version

A fully functional compiler demonstrating all phases of compilation with extensive educational features. Perfect for teaching compiler design concepts with real, working code.

## 🎯 Purpose

This compiler strips away complexity to show the **essential components** of compilation:
- **Minimal Language**: Just enough features to demonstrate key concepts
- **Clear Phases**: Each compilation phase is visible and well-documented
- **Real Output**: Generates actual MIPS assembly that runs on simulators
- **Educational Focus**: Extensive comments and explanatory output

## 📚 Language Features

Our minimal C-like language supports:
- **Integer variable declarations**: `int x;`
- **Assignment statements**: `x = 10;`
- **Arithmetic operators**: `+`, `-`, `*`, `/`
- **Comparison operators**: `<`, `>`, `<=`, `>=`, `==`, `!=`
- **Logical operators**: `&&`, `||`, `!`
- **Control flow**: `if`, `else`, `while`
- **Functions**: Function declarations, calls, and returns
- **Arrays**: Integer arrays with indexing
- **Print statement**: `print(x);`

## 🚀 Getting Started

### Prerequisites

Before you begin, ensure you have the following installed:
- `flex` (lexical analyzer generator)
- `bison` (parser generator)
- `gcc` (C compiler)
- `make` (build automation)
- MIPS simulator (MARS, SPIM, or QtSPIM) for running output

#### Installing Prerequisites on Ubuntu/Debian:
```bash
sudo apt-get update
sudo apt-get install flex bison gcc make
```

#### Installing Prerequisites on macOS:
```bash
brew install flex bison gcc make
```

#### Installing Prerequisites on Windows:
Use WSL (Windows Subsystem for Linux) or install via Cygwin/MinGW.

### Step-by-Step Setup

#### Step 1: Extract the Compiler

If you received a compressed file:
```bash
# For .zip files
unzip minicompiler.zip
cd minicompiler/

# For .tar.gz files
tar -xzvf minicompiler.tar.gz
cd minicompiler/

# For .tar files
tar -xvf minicompiler.tar
cd minicompiler/
```

#### Step 2: Build the Compiler

```bash
make
```

This will:
1. Generate the lexer from `scanner.l`
2. Generate the parser from `parser.y`
3. Compile all C source files
4. Link everything into the `minicompiler` executable

Expected output:
```
flex scanner.l
bison -d parser.y
gcc -c -g -o scanner.o lex.yy.c
gcc -c -g -o parser.o parser.tab.c
gcc -c -g -o ast.o ast.c
gcc -c -g -o symtab.o symtab.c
gcc -c -g -o tac.o tac.c
gcc -c -g -o codegen.o codegen.c
gcc -c -g -o main.o main.c
gcc -o minicompiler scanner.o parser.o ast.o symtab.o tac.o codegen.o main.o -lfl
```

#### Step 3: Run the Compiler

Basic usage:
```bash
./minicompiler <input.c> <output.s>
```

Example:
```bash
./minicompiler test.c output.s
```

This will:
- Read `test.c` (your source program)
- Compile it through all phases
- Generate `output.s` (MIPS assembly)
- Display detailed information about each compilation phase

## 📝 Complete Usage Example

### Creating Your First Program

Create a file named `hello.c`:
```c
int x;
int y;
int z;

int main() {
    x = 5;
    y = 10;
    z = x + y;
    print(z);
    return 0;
}
```

### Compiling the Program

```bash
./minicompiler hello.c hello.s
```

### Expected Output

```
╔════════════════════════════════════════════════════════════╗
║          MINIMAL C COMPILER - EDUCATIONAL VERSION         ║
╚════════════════════════════════════════════════════════════╝

┌──────────────────────────────────────────────────────────┐
│ PHASE 1: LEXICAL & SYNTAX ANALYSIS                       │
├──────────────────────────────────────────────────────────┤
│ • Reading source file: hello.c
│ • Tokenizing input (scanner.l)
│ • Parsing grammar rules (parser.y)
│ • Building Abstract Syntax Tree
└──────────────────────────────────────────────────────────┘
✓ Parse successful - program is syntactically correct!

┌──────────────────────────────────────────────────────────┐
│ PHASE 2: ABSTRACT SYNTAX TREE (AST)                      │
├──────────────────────────────────────────────────────────┤
│ Tree structure representing the program hierarchy:        │
└──────────────────────────────────────────────────────────┘
STMT_LIST
  DECL: x
  STMT_LIST
    DECL: y
    STMT_LIST
      DECL: z
      FUNC_DECL: main
        ...

┌──────────────────────────────────────────────────────────┐
│ PHASE 3: INTERMEDIATE CODE GENERATION                    │
├──────────────────────────────────────────────────────────┤
│ Three-Address Code (TAC) - simplified instructions:       │
│ • Each instruction has at most 3 operands                │
│ • Temporary variables (t0, t1, ...) for expressions      │
└──────────────────────────────────────────────────────────┘
Unoptimized TAC Instructions:
─────────────────────────────
 1: DECL x
 2: DECL y
 3: DECL z
 ...

┌──────────────────────────────────────────────────────────┐
│ PHASE 4: CODE OPTIMIZATION                               │
├──────────────────────────────────────────────────────────┤
│ Applying optimizations:                                  │
│ • Constant folding (evaluate compile-time expressions)   │
│ • Copy propagation (replace variables with values)       │
└──────────────────────────────────────────────────────────┘
Optimized TAC Instructions:
─────────────────────────────
...

┌──────────────────────────────────────────────────────────┐
│ PHASE 5: MIPS CODE GENERATION                            │
├──────────────────────────────────────────────────────────┤
│ Translating to MIPS assembly:                            │
│ • Variables stored on stack                              │
│ • Using $t0-$t7 for temporary values                     │
│ • System calls for print operations                      │
└──────────────────────────────────────────────────────────┘
✓ MIPS assembly code generated to: hello.s

╔════════════════════════════════════════════════════════════╗
║                  COMPILATION SUCCESSFUL!                   ║
║         Run the output file in a MIPS simulator           ║
╚════════════════════════════════════════════════════════════╝
```

### Running the Generated Code

#### Using MARS (MIPS Assembler and Runtime Simulator)

1. Download MARS from: http://courses.missouristate.edu/KenVollmar/mars/
2. Run MARS: `java -jar Mars.jar`
3. Open `hello.s`
4. Click "Assemble" (or F3)
5. Click "Run" (or F5)
6. Check the "Run I/O" tab for output

#### Using SPIM (Command Line)

```bash
spim -file hello.s
```

#### Using QtSPIM (GUI Version)

1. Launch QtSPIM
2. File → Load → Select `hello.s`
3. Click "Run" or press F5
4. View output in the console

Expected program output:
```
15
```

## 🔧 Compiler Architecture

### Complete Compilation Pipeline

```
Source Code (.c)
      ↓
┌─────────────────┐
│ LEXICAL ANALYSIS│ → Tokens (INT, ID, NUM, +, =, etc.)
│   (scanner.l)   │
└─────────────────┘
      ↓
┌─────────────────┐
│ SYNTAX ANALYSIS │ → Abstract Syntax Tree (AST)
│   (parser.y)    │
└─────────────────┘
      ↓
┌─────────────────┐
│  AST BUILDING   │ → Hierarchical program structure
│    (ast.c)      │
└─────────────────┘
      ↓
┌─────────────────┐
│ SEMANTIC CHECK  │ → Symbol table, type checking
│   (symtab.c)    │
└─────────────────┘
      ↓
┌─────────────────┐
│ INTERMEDIATE    │ → Three-Address Code (TAC)
│ CODE (tac.c)    │
└─────────────────┘
      ↓
┌─────────────────┐
│  OPTIMIZATION   │ → Constant folding, propagation
│   (tac.c)       │
└─────────────────┘
      ↓
┌─────────────────┐
│ CODE GENERATION │ → MIPS Assembly (.s)
│  (codegen.c)    │
└─────────────────┘
      ↓
MIPS Assembly (.s)
```

## 💾 Understanding the Stack

### What is the Stack?

The stack is a **real region of memory** that every program uses for storing local variables. It's not just an educational concept - it's how actual computers work!

### Stack Memory Layout

```
High Memory Address (0xFFFFFFFF)
         ↑
    ┌──────────┐
    │          │
    │  UNUSED  │
    │          │
    ├──────────┤
    │          │
    │  STACK   │ ← Your variables live here!
    │    ↓     │   (grows downward)
    │          │
$sp →├──────────┤ ← Stack Pointer points to top
    │          │
    │   FREE   │
    │  SPACE   │
    │          │
    ├──────────┤
    │    ↑     │
    │   HEAP   │ ← Dynamic memory (malloc)
    │          │   (grows upward)
    ├──────────┤
    │  GLOBALS │ ← Global variables
    ├──────────┤
    │   CODE   │ ← Your program
    └──────────┘
         ↓
Low Memory Address (0x00000000)
```

### How Our Compiler Uses the Stack

For this program:
```c
int x;
int y; 
int z;
x = 10;
y = 20;
z = x + y;
```

The stack layout becomes:

```
        Stack Memory
    ┌─────────────────┐
    │      ...        │
    ├─────────────────┤ ← Old $sp (before allocation)
    │   z (offset 8)  │ → Will store 30
    ├─────────────────┤
    │   y (offset 4)  │ → Stores 20
    ├─────────────────┤
    │   x (offset 0)  │ → Stores 10
    └─────────────────┘ ← $sp after "addi $sp, $sp, -400"
```

### MIPS Instructions for Stack Operations

```mips
# Allocate space (at program start)
addi $sp, $sp, -400    # Move stack pointer down 400 bytes

# Store value 10 in variable x (offset 0)
li $t0, 10            # Load immediate 10 into register $t0
sw $t0, 0($sp)        # Store Word: memory[$sp + 0] = $t0

# Load variable x into register
lw $t1, 0($sp)        # Load Word: $t1 = memory[$sp + 0]

# Deallocate space (at program end)
addi $sp, $sp, 400    # Restore stack pointer
```

## 📝 Example Programs

### Example 1: Simple Arithmetic
```c
int a;
int b;
int sum;

int main() {
    a = 5;
    b = 7;
    sum = a + b;
    print(sum);
    return 0;
}
```

**Output**: `12`

### Example 2: Order of Operations
```c
int result;

int main() {
    result = 2 + 3 * 4;
    print(result);
    return 0;
}
```

**Output**: `14` (not 20 - multiplication happens first!)

### Example 3: If Statement
```c
int x;
int y;

int main() {
    x = 10;
    y = 20;
    
    if (x < y) {
        print(100);
    } else {
        print(200);
    }
    
    return 0;
}
```

**Output**: `100`

### Example 4: While Loop
```c
int i;

int main() {
    i = 0;
    while (i < 5) {
        print(i);
        i = i + 1;
    }
    return 0;
}
```

**Output**: `0 1 2 3 4`

### Example 5: Functions
```c
int x;
int y;

int add(int a, int b) {
    return a + b;
}

int main() {
    x = 5;
    y = 10;
    print(add(x, y));
    return 0;
}
```

**Output**: `15`

### Example 6: Arrays
```c
int arr[5];
int i;

int main() {
    arr[0] = 10;
    arr[1] = 20;
    arr[2] = 30;
    
    i = 0;
    while (i < 3) {
        print(arr[i]);
        i = i + 1;
    }
    
    return 0;
}
```

**Output**: `10 20 30`

## 🔨 Build Commands

### Build Everything
```bash
make
```

### Clean Build Files
```bash
make clean
```

### Rebuild from Scratch
```bash
make clean
make
```

### What Gets Built
- `minicompiler` - The main compiler executable
- `lex.yy.c` - Generated lexer (from scanner.l)
- `parser.tab.c` and `parser.tab.h` - Generated parser (from parser.y)
- `*.o` - Object files for each module

## 🎓 Educational Features

### 1. **Extensive Comments**
Every source file contains detailed explanations of:
- What each component does
- Why design decisions were made
- How pieces fit together

### 2. **Visual Output**
The compiler shows:
- Beautiful ASCII boxes for each phase
- Line-by-line TAC with explanations
- Optimization steps clearly marked
- Success/error messages with helpful tips

### 3. **Phase Separation**
Each compilation phase is clearly separated:
- Lexical Analysis → Tokens
- Syntax Analysis → AST
- Intermediate Code → TAC
- Optimization → Improved TAC
- Code Generation → MIPS

### 4. **Real-World Concepts**
Students learn:
- How variables are stored in memory
- What three-address code looks like
- How optimizations work (constant folding)
- How high-level code becomes assembly

## 📁 File Structure

```
minicompiler/
├── scanner.l      # Lexical analyzer (tokenizer)
├── parser.y       # Grammar rules and parser
├── ast.h          # AST data structures
├── ast.c          # AST implementation
├── symtab.h       # Symbol table interface
├── symtab.c       # Symbol table implementation
├── tac.h          # TAC interface
├── tac.c          # TAC generation and optimization
├── codegen.h      # Code generator interface
├── codegen.c      # MIPS code generator
├── benchmark.h    # Performance measurement
├── benchmark.c    # Performance implementation
├── main.c         # Driver program
├── Makefile       # Build configuration
├── test.c         # Example test program
├── simple_test.c  # Additional test cases
└── README.md      # This file
```

## 🔍 Understanding the Output

### Three-Address Code (TAC)
```
1: DECL x          // Declare variable 'x'
2: x = 10          // Assign value to x
3: t0 = x + y      // Add: store result in t0
4: z = t0          // Assign temp result to z
5: PRINT z         // Output value of z
```

### Optimized TAC
```
1: DECL x
2: x = 10          // Constant value: 10
3: t0 = 30         // Folded: 10 + 20 = 30
4: z = 30          // Propagated constant
5: PRINT 30        // Direct constant print
```

### Generated MIPS Assembly
```mips
.data
newline: .asciiz "\n"

.text
.globl main

func_main:
    # Function prologue
    subu $sp, $sp, 32
    sw $ra, 28($sp)
    sw $fp, 24($sp)
    move $fp, $sp
    subu $sp, $sp, 400
    
    # x = 10
    li $t0, 10
    sw $t0, -4($fp)
    
    # y = 20
    li $t0, 20
    sw $t0, -8($fp)
    
    # z = x + y
    lw $t0, -4($fp)
    lw $t1, -8($fp)
    add $t0, $t0, $t1
    sw $t0, -12($fp)
    
    # print(z)
    lw $t0, -12($fp)
    move $a0, $t0
    li $v0, 1
    syscall
    
    # Function epilogue
    move $sp, $fp
    lw $ra, 28($sp)
    lw $fp, 24($sp)
    addu $sp, $sp, 32
    jr $ra

main:
    # Setup main stack frame
    subu $sp, $sp, 32
    sw $ra, 28($sp)
    sw $fp, 24($sp)
    move $fp, $sp
    jal func_main
    # Program exit
    li $v0, 10
    syscall
```

## 🐛 Troubleshooting

### Build Errors

**Error**: `flex: command not found`
```bash
sudo apt-get install flex
```

**Error**: `bison: command not found`
```bash
sudo apt-get install bison
```

**Error**: `undefined reference to 'yywrap'`
- Solution: Already handled with `-lfl` flag in Makefile

### Runtime Errors

**Error**: `Cannot open input file`
- Ensure the input file exists
- Check file path is correct
- Verify file permissions

**Error**: `Syntax Error`
- Check your source code syntax
- Ensure all statements end with semicolons
- Make sure variables are declared before use

### MIPS Simulator Issues

**Error**: `Address out of range`
- Try increasing stack size in simulator settings
- Reduce array sizes in your program

**Error**: `Invalid instruction`
- Verify MIPS simulator is configured for R2000/R3000
- Check that assembly file generated correctly

## 🎯 Learning Objectives

Students will understand:
1. **Lexical Analysis**: How text becomes tokens
2. **Parsing**: How tokens become syntax trees
3. **Semantic Analysis**: How meaning is verified
4. **Intermediate Representations**: Platform-independent code
5. **Optimization**: Improving code efficiency
6. **Code Generation**: Creating real machine code
7. **Memory Management**: How variables are stored
8. **Compilation Pipeline**: How phases connect

## 📚 Additional Resources

### MIPS Simulators
- **MARS**: http://courses.missouristate.edu/KenVollmar/mars/
- **SPIM**: http://spimsimulator.sourceforge.net/
- **QtSPIM**: GUI version of SPIM

### Learning Resources
- MIPS Reference Card: Green card (quick reference)
- Compiler Design textbooks: Aho, Lam, Sethi, Ullman "Compilers: Principles, Techniques, and Tools"

## 🤝 Contributing

This is an educational project. Suggestions for making concepts clearer are welcome!

## 📜 License

Educational use - free to use and modify for teaching purposes.

---

**Quick Start**: `make && ./minicompiler test.c output.s && spim -file output.s`