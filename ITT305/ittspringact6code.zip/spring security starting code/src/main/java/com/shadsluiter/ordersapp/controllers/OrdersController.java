package com.shadsluiter.ordersapp.controllers;

import com.shadsluiter.ordersapp.models.OrderModel;
import com.shadsluiter.ordersapp.models.OrderSearch;
import com.shadsluiter.ordersapp.models.UserModel;
import com.shadsluiter.ordersapp.service.OrderService;
import com.shadsluiter.ordersapp.service.UserService;

import jakarta.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

/*
 * OrdersController handles all order-related requests.
 * All endpoints require JWT authentication except those marked as public.
 * The authenticated user's ID is used as the customer ID for orders.
 */
@Controller
@RequestMapping("/orders")
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class OrdersController {

    private final OrderService orderService;
    private final UserService userService;

    @Autowired
    public OrdersController(OrderService orderService, UserService userService) {
        this.orderService = orderService;
        this.userService = userService;
    }

    /*
     * Get the ID of the currently authenticated user
     * This is used to link orders to the user who created them
     */
    private String getAuthenticatedUserId() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        if (authentication != null && authentication.isAuthenticated()) {
            String username = authentication.getName();
            UserModel user = userService.findByLoginName(username);
            if (user != null) {
                return user.getId();
            }
        }
        return null;
    }

    // ============================
    //       MVC ENDPOINTS
    // ============================

    /*
     * Display form to create a new order
     */
    @GetMapping("/create")
    public String showCreateOrderForm(Model model) {
        model.addAttribute("order", new OrderModel());
        model.addAttribute("pageTitle", "Create Order");

        List<UserModel> users = userService.findAll();
        model.addAttribute("users", users);

        return "create-order";
    }

    /*
     * Handle order creation form submission
     */
    @PostMapping("/create")
    public String createOrder(@ModelAttribute @Valid OrderModel order,
                              BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("pageTitle", "Create Order");
            List<UserModel> users = userService.findAll();
            model.addAttribute("users", users);
            return "create-order";
        }

        orderService.save(order);
        return "redirect:/orders";
    }

    /*
     * Display form to edit an existing order
     */
    @GetMapping("/edit/{id}")
    public String showEditOrderForm(@PathVariable String id, Model model) {
        OrderModel order = orderService.findById(id);
        model.addAttribute("order", order);

        List<UserModel> users = userService.findAll();
        model.addAttribute("users", users);

        return "edit-order";
    }

    /*
     * Handle order update form submission
     */
    @PostMapping("/edit/{id}")
    public String updateOrder(@PathVariable String id,
                              @ModelAttribute OrderModel order,
                              BindingResult result, Model model) {
        if (result.hasErrors()) {
            model.addAttribute("order", order);
            List<UserModel> users = userService.findAll();
            model.addAttribute("users", users);
            return "edit-order";
        }

        orderService.updateOrder(id, order);
        return "redirect:/orders";
    }

    /*
     * Display all orders
     */
    @GetMapping
    public String getAllOrders(Model model) {
        List<OrderModel> orders = orderService.findAll();
        model.addAttribute("orders", orders);
        model.addAttribute("message", "Showing all orders");
        model.addAttribute("pageTitle", "Orders");
        return "orders";
    }

    /*
     * Display search form for orders
     */
    @GetMapping("/search")
    public String searchForm(Model model) {
        model.addAttribute("orderSearch", new OrderSearch());
        return "searchForm";
    }

    /*
     * Handle order search by notes
     */
    @PostMapping("/search")
    public String search(@ModelAttribute @Valid OrderSearch orderSearch,
                         BindingResult result, Model model) {
        if (result.hasErrors()) {
            return "searchForm";
        }

        List<OrderModel> orders = orderService.findByNotes(orderSearch.getSearchString());
        model.addAttribute("message", "Search results for: " + orderSearch.getSearchString());
        model.addAttribute("orders", orders);
        return "orders";
    }

    /*
     * Get orders by customer ID
     */
    @GetMapping("/customer/{customerid}")
    public String getOrdersByCustomerId(@PathVariable String customerid, Model model) {
        List<OrderModel> orders = orderService.findByCustomerid(customerid);
        model.addAttribute("orders", orders);
        return "orders";
    }

    /*
     * Delete an order by ID
     */
    @GetMapping("/delete/{id}")
    public String deleteOrder(@PathVariable String id) {
        orderService.delete(id);
        return "redirect:/orders";
    }

    // ============================
    //    REST API ENDPOINTS
    // ============================

    /*
     * Get all orders via REST API
     * GET /api/orders
     * Requires JWT authentication
     */
    @GetMapping("/api/orders")
    @ResponseBody
    public ResponseEntity<?> getAllOrdersApi() {
        List<OrderModel> orders = orderService.findAll();
        return ResponseEntity.ok(orders);
    }

    /*
     * Create a new order via REST API
     * POST /api/orders
     * Requires JWT authentication
     * The authenticated user's ID is used as the customer ID
     *
     * Request body:
     * {
     *   "date": "2024-01-01T00:00:00.000Z",
     *   "notes": "Order notes"
     * }
     */
    @PostMapping("/api/orders")
    @ResponseBody
    public ResponseEntity<?> createOrderApi(@RequestBody OrderModel order) {
        try {
            String userId = getAuthenticatedUserId();
            if (userId == null) {
                return ResponseEntity.status(401).body(Map.of("error", "User not authenticated"));
            }

            // Set the customer ID to the authenticated user's ID
            order.setCustomerid(userId);
            OrderModel createdOrder = orderService.save(order);
            return ResponseEntity.ok(createdOrder);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

    /*
     * Get orders by customer ID via REST API
     * GET /api/orders/customer/{customerid}
     * Requires JWT authentication
     */
    @GetMapping("/api/orders/customer/{customerid}")
    @ResponseBody
    public ResponseEntity<?> getOrdersByCustomerIdApi(@PathVariable String customerid) {
        List<OrderModel> orders = orderService.findByCustomerid(customerid);
        return ResponseEntity.ok(orders);
    }

    /*
     * Get a specific order by ID via REST API
     * GET /api/orders/{id}
     * Requires JWT authentication
     */
    @GetMapping("/api/orders/{id}")
    @ResponseBody
    public ResponseEntity<?> getOrderByIdApi(@PathVariable String id) {
        OrderModel order = orderService.findById(id);
        if (order == null) {
            return ResponseEntity.status(404).body(Map.of("error", "Order not found"));
        }
        return ResponseEntity.ok(order);
    }

    /*
     * Update an order via REST API
     * PUT /api/orders/{id}
     * Requires JWT authentication
     *
     * Request body:
     * {
     *   "date": "2024-01-02T00:00:00.000Z",
     *   "customerid": "1",
     *   "notes": "Updated notes"
     * }
     */
    @PutMapping("/api/orders/{id}")
    @ResponseBody
    public ResponseEntity<?> updateOrderApi(@PathVariable String id,
                                            @RequestBody OrderModel order) {
        try {
            // Handle null values
            if (order == null) {
                return ResponseEntity.status(400).body(Map.of("error", "Order data is required"));
            }

            OrderModel updatedOrder = orderService.updateOrder(id, order);
            return ResponseEntity.ok(updatedOrder);
        } catch (Exception e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

    /*
     * Delete an order via REST API
     * DELETE /api/orders/{id}
     * Requires JWT authentication
     */
    @DeleteMapping("/api/orders/{id}")
    @ResponseBody
    public ResponseEntity<?> deleteOrderApi(@PathVariable String id) {
        try {
            orderService.delete(id);
            return ResponseEntity.ok(Map.of("message", "Order deleted successfully"));
        } catch (Exception e) {
            return ResponseEntity.status(400).body(Map.of("error", e.getMessage()));
        }
    }

    /*
     * Search orders by notes via REST API
     * GET /api/orders/search?query=searchterm
     * Requires JWT authentication
     */
    @GetMapping("/api/orders/search")
    @ResponseBody
    public ResponseEntity<?> searchOrdersApi(@RequestParam String query) {
        List<OrderModel> orders = orderService.findByNotes(query);
        return ResponseEntity.ok(orders);
    }
}