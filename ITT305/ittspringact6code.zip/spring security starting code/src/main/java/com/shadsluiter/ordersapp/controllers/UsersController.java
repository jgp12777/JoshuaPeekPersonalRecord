package com.shadsluiter.ordersapp.controllers;

import com.shadsluiter.ordersapp.models.UserModel;
import com.shadsluiter.ordersapp.security.JwtTokenProvider;
import com.shadsluiter.ordersapp.service.UserService;
import jakarta.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.authentication.UsernamePasswordAuthenticationToken;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.ui.Model;

import java.util.HashMap;
import java.util.Map;

/*
 * UsersController handles both MVC login/register pages and JWT API authentication
 * - MVC endpoints: /users/register, /users/loginForm, /users/logout
 * - JWT API endpoints: /api/users/register, /api/users/login
 */
@Controller
@CrossOrigin(origins = "http://127.0.0.1:5500")
public class UsersController {

    private final UserService userService;
    private final AuthenticationManager authenticationManager;
    private final JwtTokenProvider tokenProvider;

    private static final Logger logger = LoggerFactory.getLogger(UsersController.class);

    // Constructor injection of required beans
    public UsersController(
            UserService userService,
            AuthenticationManager authenticationManager,
            JwtTokenProvider tokenProvider
    ) {
        this.userService = userService;
        this.authenticationManager = authenticationManager;
        this.tokenProvider = tokenProvider;
    }

    // ============================
    //       MVC ENDPOINTS
    // ============================

    // Show registration form
    @GetMapping("/users/register")
    public String showRegistrationForm(Model model) {
        model.addAttribute("user", new UserModel());
        return "register";
    }

    // Handle registration form submission
    @PostMapping("/users/register")
    public String registerUser(@ModelAttribute UserModel user, Model model) {
        UserModel existing = userService.findByLoginName(user.getUserName());
        if (existing != null) {
            model.addAttribute("error", "User already exists!");
            model.addAttribute("user", user);
            return "register";
        }

        setDefaultValues(user);
        userService.save(user);

        logger.info("User registered: {}", user.getUserName());
        return "redirect:/users/loginForm";
    }

    // Show login form
    @GetMapping("/users/loginForm")
    public String showLoginForm(Model model) {
        model.addAttribute("user", new UserModel());
        model.addAttribute("pageTitle", "Login");
        return "login";
    }

    // Set default values for new users
    private void setDefaultValues(UserModel user) {
        user.setEnabled(true);
        user.setAccountNonExpired(true);
        user.setCredentialsNonExpired(true);
        user.setAccountNonLocked(true);
    }

    // ============================
    //    JWT API ENDPOINTS
    // ============================

    /*
     * Register a new user via REST API
     * POST /api/users/register
     * No authentication required
     */
    @PostMapping("/api/users/register")
    @ResponseBody
    public ResponseEntity<?> registerApi(@RequestBody UserModel user) {
        if (userService.findByLoginName(user.getUserName()) != null) {
            return ResponseEntity.badRequest().body(Map.of("error", "User already exists!"));
        }

        setDefaultValues(user);
        UserModel savedUser = userService.save(user);

        logger.info("New user registered via API: {}", user.getUserName());
        return ResponseEntity.ok(Map.of("message", "User created", "user", savedUser));
    }

    /*
     * Authenticate user and generate JWT token (API)
     * POST /api/users/login
     * No authentication required
     *
     * Request body:
     * {
     *   "userName": "username",
     *   "password": "password"
     * }
     *
     * Response:
     * {
     *   "token": "eyJhbGciOiJIUzUxMiJ9...",
     *   "message": "Login successful"
     * }
     */
    @PostMapping("/api/users/login")
    @ResponseBody
    public ResponseEntity<?> authenticateUser(@RequestBody UserModel loginRequest) {
        try {
            // Authenticate user credentials
            Authentication authentication = authenticationManager.authenticate(
                    new UsernamePasswordAuthenticationToken(
                            loginRequest.getUserName(),
                            loginRequest.getPassword()
                    )
            );

            // Set authentication in Spring Security context
            SecurityContextHolder.getContext().setAuthentication(authentication);

            // Generate JWT token
            String jwt = tokenProvider.generateToken(authentication);

            logger.info("User logged in successfully: {}", loginRequest.getUserName());

            // Return token to client
            Map<String, String> response = new HashMap<>();
            response.put("token", jwt);
            response.put("message", "Login successful");

            return ResponseEntity.ok(response);
        } catch (Exception e) {
            logger.error("Authentication failed: {}", e.getMessage());
            return ResponseEntity.badRequest().body(Map.of("error", "Invalid credentials"));
        }
    }
}