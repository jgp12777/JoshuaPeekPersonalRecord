package com.shadsluiter.ordersapp.models;

/*
 * OrderSearch is a model class that represents the search string used to search for orders.
 * Used in the search screen to pass the search string to the controller.
 */
public class OrderSearch {
    private String searchString;

    public OrderSearch() {
        searchString = "";
    }

    public OrderSearch(String searchString) {
        this.searchString = searchString;
    }

    public String getSearchString() {
        return searchString;
    }

    public void setSearchString(String searchString) {
        this.searchString = searchString;
    }  
    
}
