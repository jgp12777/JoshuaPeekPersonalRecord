package com.shadsluiter.ordersapp.service;

import com.shadsluiter.ordersapp.data.UserRepository;
import com.shadsluiter.ordersapp.models.UserEntity;
import com.shadsluiter.ordersapp.models.UserModel;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.security.core.userdetails.User;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;

@Service
public class UserService implements UserDetailsService {

    private final UserRepository userRepository;
    private final PasswordEncoder passwordEncoder;

    // Constructor injection of UserRepository and PasswordEncoder
    @Autowired
    public UserService(UserRepository userRepository, PasswordEncoder passwordEncoder) {
        this.userRepository = userRepository;
        this.passwordEncoder = passwordEncoder;
    }

    // Save user with hashed password
    public UserModel save(UserModel userModel) {
        userModel.setPassword(passwordEncoder.encode(userModel.getPassword()));
        UserEntity userEntity = convertToEntity(userModel);
        UserEntity savedUser = userRepository.save(userEntity);
        return convertToModel(savedUser);
    }

    // Load user by username for authentication
    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        UserEntity userEntity = userRepository.findByLoginName(username);
        if (userEntity == null) {
            throw new UsernameNotFoundException("User not found");
        }

        // Convert roles to GrantedAuthority objects
        List<GrantedAuthority> authorities = new ArrayList<>();
        if (userEntity.getRoles() != null) {
            for (String role : userEntity.getRoles()) {
                authorities.add(new SimpleGrantedAuthority(role));
            }
        }

        return new User(userEntity.getUserName(), userEntity.getPassword(), authorities);
    }

    // Find user by login name
    public UserModel findByLoginName(String loginName) {
        UserEntity userEntity = userRepository.findByLoginName(loginName);
        if (userEntity == null) {
            return null;
        }
        return convertToModel(userEntity);
    }

    // Verify password using BCrypt
    public boolean verifyPassword(UserModel user) {
        UserEntity userEntity = userRepository.findByLoginName(user.getUserName());
        if (userEntity == null) {
            return false;
        }
        return passwordEncoder.matches(user.getPassword(), userEntity.getPassword());
    }

    // Find user by id
    public UserModel findById(String id) {
        UserEntity userEntity = userRepository.findById(Long.parseLong(id));
        return convertToModel(userEntity);
    }

    // Delete user by id
    public void delete(String id) {
        userRepository.deleteById(Long.parseLong(id));
    }

    // Find all users
    public List<UserModel> findAll() {
        List<UserEntity> userEntities = userRepository.findAll();
        List<UserModel> userModels = convertToModels(userEntities);
        return userModels;
    }

    // Convert list of UserEntities to UserModels
    private List<UserModel> convertToModels(List<UserEntity> userEntities) {
        List<UserModel> userModels = new ArrayList<>();
        for (UserEntity userEntity : userEntities) {
            userModels.add(convertToModel(userEntity));
        }
        return userModels;
    }

    // Convert single UserEntity to UserModel
    private UserModel convertToModel(UserEntity userEntity) {
        if (userEntity == null) {
            return null;
        }
        UserModel userModel = new UserModel();
        userModel.setId(userEntity.getId().toString());
        userModel.setUserName(userEntity.getUserName());
        userModel.setPassword(userEntity.getPassword());
        userModel.setEnabled(userEntity.isEnabled());
        userModel.setAccountNonExpired(userEntity.isAccountNonExpired());
        userModel.setCredentialsNonExpired(userEntity.isCredentialsNonExpired());
        userModel.setAccountNonLocked(userEntity.isAccountNonLocked());
        userModel.setRoles(userEntity.getRoles());
        return userModel;
    }

    // Convert single UserModel to UserEntity
    private UserEntity convertToEntity(UserModel userModel) {
        UserEntity userEntity = new UserEntity();
        if (userModel.getId() != null) {
            userEntity.setId(Long.parseLong(userModel.getId()));
        }
        userEntity.setUserName(userModel.getUserName());
        userEntity.setPassword(userModel.getPassword());
        userEntity.setEnabled(userModel.isEnabled());
        userEntity.setAccountNonExpired(userModel.isAccountNonExpired());
        userEntity.setCredentialsNonExpired(userModel.isCredentialsNonExpired());
        userEntity.setAccountNonLocked(userModel.isAccountNonLocked());
        userEntity.setRoles(userModel.getRoles());
        return userEntity;
    }
}