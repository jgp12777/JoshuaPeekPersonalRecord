package com.shadsluiter.ordersapp.data;

import com.shadsluiter.ordersapp.models.OrderEntity;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.stereotype.Repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.SimpleDateFormat;
import java.util.List;

/*
 * OrderRepository is used to interact with the database and order table.
 * It is used to retrieve, save, and delete orders.
 * It is used to convert OrderEntities to OrderModels.
 * It is used to convert OrderModels to OrderEntities.
 * 
 */
@Repository
public class OrderRepository implements OrderRepositoryInterface {

    /*
     * JdbcTemplate is used to interact with the database.
     * It is used to execute SQL queries and update statements.
     * It is used to map the results of a query to a Java object.
     */
    private final JdbcTemplate jdbcTemplate;

    /*
     * Constructor to inject the JdbcTemplate.
     * @param jdbcTemplate the JdbcTemplate to inject
     * Injected by Spring
     * Used to interact with the database
     */
    @Autowired
    public OrderRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    /*
     * findByCustomerid retrieves all orders from the database with a specific customerid.
     * @param customerid the customerid to search for
     * @return a list of OrderEntities
     */
    @Override
    public List<OrderEntity> findByCustomerid(Long customerid) {
        String sql = "SELECT * FROM orders WHERE customerid = " + customerid;
         List<OrderEntity> result =  jdbcTemplate.query(sql, new OrderModelRowMapper());
            return result;
    }

    /*
     * findAll retrieves all orders from the database.
     * @return a list of OrderEntities
     */
    @Override
    public List<OrderEntity> findAll() {
        String sql = "SELECT * FROM orders";
        return jdbcTemplate.query(sql, new OrderModelRowMapper());
    }

    /*
     * deleteById deletes an order from the database by id.
     * @param id the id of the order to delete
     */
    @Override
    public void deleteById(Long id) {
        String sql = "DELETE FROM orders WHERE id = " + id;
        jdbcTemplate.update(sql);
    }

  /*
     * save converts an OrderEntity to an OrderModel and saves it to the database.
     * @param order the OrderEntity to save
     * @return the saved OrderEntity
     */
    @Override
public OrderEntity save(OrderEntity order) {
    // Format the date to the correct SQL 'datetime' format
    SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
    String formattedDate = dateFormat.format(order.getDate());

    if (order.getId() == null) {
        // Insert new order
        String sql = "INSERT INTO orders (date, customerid, notes) VALUES (?, ?, ?)";
        jdbcTemplate.update(sql, formattedDate, order.getCustomerid(), order.getNotes());
        Long id = jdbcTemplate.queryForObject("SELECT LAST_INSERT_ID()", Long.class);
        order.setId(id);
    } else {
        // Update existing order
        String sql = "UPDATE orders SET date = ?, customerid = ?, notes = ? WHERE id = ?";
        jdbcTemplate.update(sql, formattedDate, order.getCustomerid(), order.getNotes(), order.getId());
    }
    return order;
}
/*
     * findById retrieves an order from the database by id.
     * @param id the id of the order to retrieve
     * @return the OrderEntity
     */
    @Override
    public OrderEntity findById(Long id) {
        String sql = "SELECT * FROM orders WHERE id = " + id;
        return jdbcTemplate.queryForObject(sql, new OrderModelRowMapper());
    }

    /*
     * existsById checks if an order exists in the database by id.
     * @param id the id of the order to check
     * @return true if the order exists, false otherwise
     */
    @Override
    public boolean existsById(Long id) {
        String sql = "SELECT COUNT(*) FROM orders WHERE id = " + id;
        Integer count = jdbcTemplate.queryForObject(sql, Integer.class);
        return count != null && count > 0;
    }

    /*
     * deleteAllById deletes all orders from the database by id.
     * @param ids the ids of the orders to delete
     */
    @Override
    public long count() {
        String sql = "SELECT COUNT(*) FROM orders";
        Long result = jdbcTemplate.queryForObject(sql, Long.class);
        if (result == null) {
            return 0;
        }
        return result;
    }

    /*
     * deleteAllById deletes all orders from the database by id.
     * @param ids the ids of the orders to delete
     */
    @Override
    public void delete(OrderEntity order) {
        deleteById(order.getId());
    }

    /*
     * deleteAll deletes all orders from the database.
     */
    @Override
    public void deleteAll() {
        String sql = "DELETE FROM orders";
        jdbcTemplate.update(sql);
    }

    /*
     * deleteAll deletes all orders from the database.
     */
    @Override
    public void deleteAll(Iterable<? extends OrderEntity> orders) {
        for (OrderEntity order : orders) {
            delete(order);
        }
    }
 
/*
     * saveAll saves a list of OrderEntities to the database.
     * @param orders the list of OrderEntities to save
     * @return a list of the saved OrderEntities
     */
    @Override
    public List<OrderEntity> saveAll(Iterable<OrderEntity> orders) {
        for (OrderEntity order : orders) {
            save(order);
        }
        return (List<OrderEntity>) orders;
    }

    /*
     * OrderModelRowMapper is used to map a row in the database to an OrderEntity.
     */
    private static class OrderModelRowMapper implements RowMapper<OrderEntity> {
        @Override
        public OrderEntity mapRow(ResultSet rs, int rowNum) throws SQLException {
            OrderEntity order = new OrderEntity();
            order.setId(rs.getLong("id"));
            order.setDate(rs.getDate("date"));
            order.setCustomerid(rs.getString("customerid"));
            order.setNotes(rs.getString("notes"));
            return order;
        }
    }

    /*
     * findByNote retrieves all orders from the database with a specific note.
     * @param name the note to search for
     * @return a list of OrderEntities
     */
    @Override
    public List<OrderEntity> findByNote(String name) {
        String sql = "SELECT * FROM orders WHERE notes LIKE '%" + name + "%'";
        return jdbcTemplate.query(sql, new OrderModelRowMapper());
    }
}
