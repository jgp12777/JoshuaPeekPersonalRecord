package com.shadsluiter.ordersapp.models;

/*
 * This class contains static methods to convert between UserEntity and UserModel objects.
 * This is necessary because the UserEntity class is used to interact with the database,
 * while the UserModel class is used to interact with the front-end.
 * The converters allow us to convert between the two representations of a user.
 * 
 */
public class Converters {
    
    /*
     * Convert a UserModel object to a UserEntity object.
     * @param userModel The UserModel object to convert.
     * @return The UserEntity object.
     */
    public static UserEntity userModelToUserEntity(UserModel userModel) {
        UserEntity userEntity = new UserEntity();
        userEntity.setId(Long.parseLong(userModel.getId()));
        userEntity.setUserName(userModel.getUserName());
        userEntity.setPassword(userModel.getPassword());
        return userEntity;
    }

    /*
     * Convert a UserEntity object to a UserModel object.
     * @param userEntity The UserEntity object to convert.
     * @return The UserModel object.
     * 
     */
    public static UserModel userEntityToUserModel(UserEntity userEntity) {
        UserModel userModel = new UserModel();
        userModel.setId(String.valueOf(userEntity.getId()));
        userModel.setUserName(userEntity.getUserName());
        userModel.setPassword(userEntity.getPassword());
        return userModel;
    }

    
}
