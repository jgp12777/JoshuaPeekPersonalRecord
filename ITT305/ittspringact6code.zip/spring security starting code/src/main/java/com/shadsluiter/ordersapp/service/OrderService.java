package com.shadsluiter.ordersapp.service;

import com.shadsluiter.ordersapp.data.OrderRepository;
import com.shadsluiter.ordersapp.data.OrderRepositoryInterface;
import com.shadsluiter.ordersapp.models.OrderEntity;
import com.shadsluiter.ordersapp.models.OrderModel;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

/*
 * OrderService is used in the controller to interact with the database and order table.
 */
@Service
public class OrderService {

    private final OrderRepositoryInterface orderRepository;

    @Autowired
    public OrderService(OrderRepository orderRepository) {
        this.orderRepository = orderRepository;
    }

    /*
     * findAll retrieves all orders from the database and converts them to OrderModels.
     * @return a list of OrderModels
     */
    public List<OrderModel> findAll() {
        List<OrderEntity> orderEntities = orderRepository.findAll();
        return convertToModels(orderEntities);

    }

    /*
     * findByCustomerid retrieves all orders from the database with a specific customerid and converts them to OrderModels.
     * @param customerid the customerid to search for
     * @return a list of OrderModels
     */
    public List<OrderModel> findByCustomerid(String customerid) {
        List<OrderEntity> orderEntities = orderRepository.findByCustomerid(Long.valueOf(customerid));
        return convertToModels(orderEntities);
    }

    /*
     * findByNotes retrieves all orders from the database with a specific note and converts them to OrderModels.
     * @param searchString the note to search for
     * @return a list of OrderModels
     */
    public List<OrderModel> findByNotes(String searchString) {
        List<OrderEntity> orderEntities = orderRepository.findByNote(searchString);
        return convertToModels(orderEntities);
    }

    /*
     * save converts an OrderModel to an OrderEntity and saves it to the database.
     * @param order the OrderModel to save
     * @return the saved OrderModel
     */
    public OrderModel save(OrderModel order) {
        OrderEntity orderEntity = convertToEntity(order);
        OrderEntity savedOrder = orderRepository.save(orderEntity);
        return convertToModel(savedOrder);
    }

    /*
     * delete removes an order from the database by id.
     * @param id the id of the order to delete
     * @return void
     */
    public void delete(String id) {
        orderRepository.deleteById(Long.valueOf(id));
    }

    /*
     * updateOrder updates an order in the database.
     * @param id the id of the order to update
     * @param order the updated order
     * @return the updated OrderModel
     */
    public OrderModel updateOrder(String id, OrderModel order) {
        order.setId(id);
        return save(order);
    }

    /*
     * findById retrieves an order from the database by id.
     * @param id the id of the order to retrieve
     * @return the OrderModel with the specified id. REturns null if not found.
     */
    public OrderModel findById(String id) {
        OrderEntity orderEntity = orderRepository.findById(Long.valueOf(id));
        return convertToModel(orderEntity);
    }

    /*
     * convertToModels converts a list of OrderEntities to a list of OrderModels.
     * @param orderEntities the list of OrderEntities to convert
     * @return a list of OrderModels
     * 
     */
    private List<OrderModel> convertToModels(List<OrderEntity> orderEntities) {
        List<OrderModel> orderModels = new ArrayList<>();
        for (OrderEntity orderEntity : orderEntities) {
            orderModels.add(convertToModel(orderEntity));
        }
        return orderModels;
    }

    /*
     * convertToModel converts an OrderEntity to an OrderModel.
     * @param orderEntity the OrderEntity to convert
     * @return the converted OrderModel
     * 
     */
    private OrderModel convertToModel(OrderEntity orderEntity) {
        return new OrderModel(
                orderEntity.getId().toString(),
                orderEntity.getDate(),
                orderEntity.getCustomerid().toString(),
                orderEntity.getNotes()
        );
    }

    /*
     * convertToEntities converts a list of OrderModels to a list of OrderEntities.
     * @param orderModels the list of OrderModels to convert
     * @return a list of OrderEntities
     * 
     */
    private List<OrderEntity> convertToEntities(List<OrderModel> orderModels) {
        List<OrderEntity> orderEntities = new ArrayList<>();
        for (OrderModel orderModel : orderModels) {
            orderEntities.add(convertToEntity(orderModel));
        }
        return orderEntities;
    }

    /*
     * convertToEntity converts an OrderModel to an OrderEntity.
     * @param orderModel the OrderModel to convert
     * @return the converted OrderEntity
     * 
     */
    private OrderEntity convertToEntity(OrderModel orderModel) {
        OrderEntity orderEntity = new OrderEntity();
        if (orderModel.getId() != null) {
            orderEntity.setId(Long.parseLong(orderModel.getId()));
        }
        orderEntity.setDate(orderModel.getDate());
        orderEntity.setCustomerid(orderModel.getCustomerid());
        orderEntity.setNotes(orderModel.getNotes());
        return orderEntity;
    }


}
