package app;
import java.util.Scanner;
import java.util.Random;
public class gameing {

	public static void main(String[] args) {
		int guess = 1; 
		int low = 1;
		int high = 10000;
		Random rand = new Random();
		Scanner scnr = new Scanner(System.in);
		int answer = rand.nextInt(high);
		System.out.println("This program is a \"guessing game\" program. "
				+ "The program will generate a random integer between 1 and 10000, inclusive.");
		System.out.println("For each guess, the program will output "
				+ "HIGHER if the users guess is lower than the target, ");
		System.out.println( "LOWER if the user guess is higher than the target, ");
		System.out.println( "or WINNER if the user guesses the target.");
		System.out.println("Type your guess :) ");
		System.out.println(answer);
		do {
			
			guess = scnr.nextInt();
		if (guess != answer) {
			if (guess >= low && guess < answer){
				low = guess;
				System.out.println("Your answer is too low! Guess again! Your new range is: " + low + " to " + high + ".");
			}
			if (guess <= high && guess > answer) {
				high = guess;
				System.out.println("Your answer is too high! Guess again! Your new range is: " + low + " to " + high + ".");
			}
		}
		
		}while (guess != answer);
		System.out.println("WINNER!!!");
	}

}
