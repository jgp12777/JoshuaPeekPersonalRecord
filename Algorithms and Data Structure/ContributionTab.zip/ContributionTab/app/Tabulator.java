package app;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.util.Scanner;
import java.io.PrintWriter;
import java.io.IOException;

public class Tabulator {
    public static void main(String[] args) throws IOException {
    	/*  Something that stumped me was I encountered error messages about reading from a file the doesn't
    	 * exist and the way I solved it was asking Chat GPT why I was receiving the message, it explained why 
    	 * you needed to use IOException to avoid crashing/giving your code an alternate route.
    	 */
    	
    	
    	double totalContributions = 0.0;
        double avgContribution = 0.0;
        double inputDataFromFile = 0.0;
    	double maxContribution = 0.0;
        double minContribution = 10000000.0;
        int numberOfContributions = 0;
        

        // File and Scanner to READ from input.in
        FileInputStream inputFile = new FileInputStream("input.in");
        Scanner scanner = new Scanner(inputFile);

        // File and PrintWriter to WRITE to results.out
        FileOutputStream outputFile = new FileOutputStream("results.out");
        PrintWriter outWriter = new PrintWriter(outputFile);

        // get input and make calculations
        while (totalContributions < 10000000) {
            if (scanner.hasNext()) {
                inputDataFromFile = scanner.nextInt();

              
                numberOfContributions++;

              
                if (maxContribution < inputDataFromFile) {
                    maxContribution = inputDataFromFile;
                }

       
                if (minContribution > inputDataFromFile) {
                    minContribution = inputDataFromFile;
                }

                // Total
                totalContributions += inputDataFromFile;
            } else {
                break; // this will exit loop when there's no more input 
            }
        }

        // Find average contribution
        avgContribution = totalContributions / numberOfContributions;

        // Output data
        outWriter.printf("It took %.0f contributions to reach the goal.%n", (double) numberOfContributions);
        outWriter.printf("The largest contribution is $%.2f.%n", maxContribution);
        outWriter.printf("The smallest contribution is $%.2f.%n", minContribution);
        outWriter.printf("The average contribution is $%.2f.%n", avgContribution);
        outWriter.printf("The total contributions collected is $%.2f.%n", totalContributions);
        scanner.close(); //also to avoid bugs and crashing
        outWriter.close();
    }
}