def logical_operations(p, q):
    # Compute logical results for AND, OR, implication, and biconditional operations
    result_and = p and q
    result_or = p or q
    result_implication = not p or q
    result_biconditional = (p and q) or (not p and not q)
    # Return the computed results
    return result_and, result_or, result_implication, result_biconditional

def display_truth_table():
     # Define formatting for the truth table
    header = "+--------------------------+"
    table_format = "|{:^3}|{:^3}|{:^3}|{:^3}|{:^3}|{:^3}|"
    separator = "+---+---+---+---+----+-----+"
    # Print the header and table format
    print(header)
    print(table_format.format("p", "q", "p^q", "pVq", "p->q", "p<->q"))
    print(separator)

    truth_values = [True, False]
    # Iterate over truth values for p and q
    for p in truth_values:
        for q in truth_values:
            # Compute logical results and convert them to 'T' or 'F'
            results = logical_operations(p, q)
            results_str = map(lambda x: 'T' if x else 'F', results) 
            #lambda takes a multiple variable expression such as p or q and assigns it a single character value such as T or F
            #https://www.geeksforgeeks.org/python-lambda-anonymous-functions-filter-map-reduce/
            # Print the row of the truth table
            row = "|{:^3}|{:^3}|{:^3}|{:^3}|{:^4}|{:^5}|".format(str(p)[0], str(q)[0], *results_str)
            print(row)
    
    print(header)

# Display the truth table
display_truth_table()