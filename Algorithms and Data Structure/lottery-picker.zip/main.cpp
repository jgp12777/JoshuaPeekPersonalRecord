//Joshua Peek Lottery Picker CST 210 - 2024

#include <iostream>
#include <algorithm>
#include <vector>
#include <cstdlib>
using namespace std;
void
showNumbers (vector < int >numbers)
{
  cout << " ";
  for (int i = 0; i < 5; i++)
    {
      cout << numbers[i] << " ";
    }
  cout << " PB " << numbers[5];	// Print the last value of the vector
  cout << endl;
}

void
setPowerball (vector < int >&numbers)
{
  int last;
  do
    {
      last = rand () % 26 + 1;
    }
  while (find (numbers.begin (), numbers.end (), last) != numbers.end ());

  numbers.push_back (last);	// Append the last to the vector
}

vector < int >
getNumbers ()
{
  vector < int >numbers;

  for (int i = 0; i < 5; i++)
    {
      int num;
      do
	{
	  num = rand () % 69 + 1;
	}
      while (find (numbers.begin (), numbers.end (), num) != numbers.end ());

      numbers.push_back (num);	// Append the num to the vector
    }

  // Sort the vector in ascending order
  sort (numbers.begin (), numbers.end ());

  return numbers;
}

int
main ()
{
  int times;
  string ans;
  do
    {

      cout << "How many numbers would you like to generate?" << endl;
      cin >> times;
      for (int i = 0; i < times; i++)
	{
	  vector < int >numbers = getNumbers ();	//vector
	  setPowerball (numbers);
	  showNumbers (numbers);


	}
      cout << "Would you like to generate more numbers? Y or N" << endl;
      cin >> ans;
    }
  while (ans != "N");

}


