import random

# Function to calculate the greatest common divisor (GCD) using Euclidean Algorithm
def gcd(a, b):
    while b != 0:
        a, b = b, a % b
    return a

# Function to check if two numbers are relatively prime (GCD = 1)
def is_relatively_prime(a, b):
    return gcd(a, b) == 1

# Function to find solutions to the equation ax + by = 1
def find_solution(a, b):
    if is_relatively_prime(a, b):  # Check if a and b are relatively prime
        # Extended Euclidean Algorithm to find x and y
        x, y, prev_x, prev_y = 0, 1, 1, 0
        while b != 0:
            quotient = a // b
            a, b = b, a % b
            x, prev_x = prev_x - quotient * x, x
            y, prev_y = prev_y - quotient * y, y
        # Print the solution in the form ax + by = 1
        print(f"{a}({prev_x}) + {b}({prev_y}) = 1")
    else:
        # Print the numbers and their GCD if they are not relatively prime
        print(f"{a} and {b} are not relatively prime. GCD({a},{b}) = {gcd(a, b)}")

# Function to generate pairs of positive random integers and call find_solution for each pair
def generate_pairs(num_pairs):
    for _ in range(num_pairs):
        # Generate random integers for the pair
        a, b = random.randint(1, 9999), random.randint(1, 9999)
        print(f"Pair: ({a}, {b})")
        # Call find_solution to print the result for the pair
        find_solution(a, b)
        print()

# Generate 20 pairs of positive random integers and print their solutions
generate_pairs(20)
