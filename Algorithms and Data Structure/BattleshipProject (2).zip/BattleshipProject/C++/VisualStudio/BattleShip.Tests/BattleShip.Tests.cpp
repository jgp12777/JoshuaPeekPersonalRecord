#include "pch.h"
#include "CppUnitTest.h"

#include "BattleShipGame.cpp"

using namespace Microsoft::VisualStudio::CppUnitTestFramework;

namespace BattleShipTests
{
	TEST_CLASS(BattleShipTests)
	{
	public:
		
		TEST_METHOD(TestInit)
		{
			auto game = new BattleshipGame(false);
			auto ships = game->PlayerShips;
			Assert::AreEqual((string)"USS Destroyer", ships[0]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Destroyer, (int)ships[0]->Type);
			Assert::AreEqual('D', ships[0]->Symbol);
			Assert::AreEqual((string)"USS Submarine", ships[1]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Submarine, (int)ships[1]->Type);
			Assert::AreEqual('S', ships[1]->Symbol);
			Assert::AreEqual((string)"USS Cruiser", ships[2]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Cruiser, (int)ships[2]->Type);
			Assert::AreEqual('C', ships[2]->Symbol);

			ships = game->ComputerShips;
			Assert::AreEqual((string)"NCC Destroyer", ships[0]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Destroyer, (int)ships[0]->Type);
			Assert::AreEqual('D', ships[0]->Symbol);
			Assert::AreEqual((string)"NCC Submarine", ships[1]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Submarine, (int)ships[1]->Type);
			Assert::AreEqual('S', ships[1]->Symbol);
			Assert::AreEqual((string)"NCC Cruiser", ships[2]->Name);
			Assert::AreEqual((int)Ship::ShipTypes::Cruiser, (int)ships[2]->Type);
			Assert::AreEqual('C', ships[2]->Symbol);

			auto playerBoard = game->PlayerBoard;
			auto computerBoard = game->ComputerBoard;
			for (auto row = 0; row < BattleshipGame::BoardSize; row++)
			{
				for (auto column = 0; column < BattleshipGame::BoardSize; column++)
				{
					Assert::AreEqual((char)BattleshipGame::OpenCellChar, playerBoard[row][column]);
					Assert::AreEqual((char)BattleshipGame::OpenCellChar, computerBoard[row][column]);
				}
			}
		}

		TEST_METHOD(TestCruiserPlacement)
		{
			auto game = new BattleshipGame(false);
			auto ships = game->PlayerShips;
			auto cruiser = dynamic_cast<Cruiser *>(ships[2]);
			auto placed = game->PlaceCruiser(game->PlayerBoard, 3, 3, cruiser);

			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[3][3]);
			Assert::AreEqual('O', game->PlayerBoard[3][4]);
			Assert::AreEqual('O', game->PlayerBoard[3][5]);

			cruiser->Left = true;
			placed = game->PlaceCruiser(game->PlayerBoard, 4, 3, cruiser);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[4][3]);
			Assert::AreEqual('O', game->PlayerBoard[4][2]);
			Assert::AreEqual('O', game->PlayerBoard[4][1]);

			cruiser->Left = false;
			cruiser->Vertical = true;
			placed = game->PlaceCruiser(game->PlayerBoard, 7, 3, cruiser);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[7][3]);
			Assert::AreEqual('O', game->PlayerBoard[8][3]);
			Assert::AreEqual('O', game->PlayerBoard[9][3]);

			cruiser->Upwards = true;
			placed = game->PlaceCruiser(game->PlayerBoard, 7, 4, cruiser);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[7][4]);
			Assert::AreEqual('O', game->PlayerBoard[6][4]);
			Assert::AreEqual('O', game->PlayerBoard[5][4]);

			//
			//  Bad Placements
			//

			cruiser->Upwards = false;
			cruiser->Vertical = false;
			cruiser->Left = false;
			placed = game->PlaceCruiser(game->PlayerBoard, 9, 9, cruiser);
			Assert::IsFalse(placed);

			cruiser->Left = true;
			placed = game->PlaceCruiser(game->PlayerBoard, 1, 1, cruiser);
			Assert::IsFalse(placed);

			cruiser->Vertical = true;
			cruiser->Left = false;
			placed = game->PlaceCruiser(game->PlayerBoard, 9, 3, cruiser);
			Assert::IsFalse(placed);

			cruiser->Upwards = false;
			placed = game->PlaceCruiser(game->PlayerBoard, 9, 1, cruiser);
			Assert::IsFalse(placed);
		}

		TEST_METHOD(TestDestroyerPlacement)
		{
			auto game = new BattleshipGame(false);
			auto ships = game->PlayerShips;
			auto destroyer = dynamic_cast<Destroyer *>(ships[0]);
			auto placed = game->PlaceDestroyer(game->PlayerBoard, 3, 3, destroyer);

			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[3][3]);
			Assert::AreEqual('O', game->PlayerBoard[3][4]);
			Assert::AreEqual('O', game->PlayerBoard[4][3]);
			Assert::AreEqual('O', game->PlayerBoard[4][4]);

			destroyer->Left = true;
			placed = game->PlaceDestroyer(game->PlayerBoard, 2, 7, destroyer);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[2][7]);
			Assert::AreEqual('O', game->PlayerBoard[2][6]);
			Assert::AreEqual('O', game->PlayerBoard[3][7]);
			Assert::AreEqual('O', game->PlayerBoard[3][6]);

			destroyer->Left = false;
			destroyer->Upwards = true;
			placed = game->PlaceDestroyer(game->PlayerBoard, 7, 3, destroyer);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[6][3]);
			Assert::AreEqual('O', game->PlayerBoard[6][4]);
			Assert::AreEqual('O', game->PlayerBoard[7][3]);
			Assert::AreEqual('O', game->PlayerBoard[7][4]);

			destroyer->Left = true;
			placed = game->PlaceDestroyer(game->PlayerBoard, 7, 6, destroyer);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[7][5]);
			Assert::AreEqual('O', game->PlayerBoard[7][6]);
			Assert::AreEqual('O', game->PlayerBoard[6][5]);
			Assert::AreEqual('O', game->PlayerBoard[6][6]);

			//
			//  Bad Placements
			//

			destroyer->Upwards = false;
			destroyer->Left = false;
			placed = game->PlaceDestroyer(game->PlayerBoard, 10, 10, destroyer);
			Assert::IsFalse(placed);

			destroyer->Left = true;
			placed = game->PlaceDestroyer(game->PlayerBoard, 10, 1, destroyer);
			Assert::IsFalse(placed);

			destroyer->Upwards = false;
			destroyer->Left = false;
			placed = game->PlaceDestroyer(game->PlayerBoard, 1, 10, destroyer);
			Assert::IsFalse(placed);

			destroyer->Left = true;
			placed = game->PlaceDestroyer(game->PlayerBoard, 0, 0, destroyer);
			Assert::IsFalse(placed);
		}

		TEST_METHOD(TestSubmarinePlacement)
		{
			auto game = new BattleshipGame(false);
			auto ships = game->PlayerShips;
			auto submarine = dynamic_cast<Submarine *>(ships[1]);
			auto placed = game->PlaceSubmarine(game->PlayerBoard, 4, 4, submarine);

			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[4][4]);
			Assert::AreEqual('O', game->PlayerBoard[5][5]);
			Assert::AreEqual('O', game->PlayerBoard[6][6]);

			submarine->Left = true;
			placed = game->PlaceSubmarine(game->PlayerBoard, 4, 3, submarine);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[4][3]);
			Assert::AreEqual('O', game->PlayerBoard[5][2]);
			Assert::AreEqual('O', game->PlayerBoard[6][1]);

			submarine->Left = false;
			submarine->Upwards = true;
			placed = game->PlaceSubmarine(game->PlayerBoard, 3, 4, submarine);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[3][4]);
			Assert::AreEqual('O', game->PlayerBoard[2][5]);
			Assert::AreEqual('O', game->PlayerBoard[1][6]);

			submarine->Left = true;
			placed = game->PlaceSubmarine(game->PlayerBoard, 3, 3, submarine);
			Assert::IsTrue(placed);
			Assert::AreEqual('O', game->PlayerBoard[3][3]);
			Assert::AreEqual('O', game->PlayerBoard[2][2]);
			Assert::AreEqual('O', game->PlayerBoard[1][1]);

			//
			//  Bad Placements
			//

			submarine->Upwards = false;
			submarine->Left = false;
			placed = game->PlaceSubmarine(game->PlayerBoard, 10, 10, submarine);
			Assert::IsFalse(placed);

			submarine->Left = true;
			placed = game->PlaceSubmarine(game->PlayerBoard, 10, 1, submarine);
			Assert::IsFalse(placed);

			submarine->Upwards = true;
			submarine->Left = false;
			placed = game->PlaceSubmarine(game->PlayerBoard, 1, 10, submarine);
			Assert::IsFalse(placed);

			submarine->Left = false;
			placed = game->PlaceSubmarine(game->PlayerBoard, 0, 0, submarine);
			Assert::IsFalse(placed);
		}

		TEST_METHOD(TestEndGame)
		{
			auto game = new BattleshipGame(false);
			auto playerEndGame = game->CheckGameOver(true);
			auto computerEndGame = game->CheckGameOver(false);
			Assert::IsTrue(playerEndGame);
			Assert::IsTrue(computerEndGame);

			game = new BattleshipGame(true);
			game->PlaceCruiser(game->PlayerBoard, 5, 5, new Cruiser("Cruiser 1", 'C'));
			playerEndGame = game->CheckGameOver(true);
			computerEndGame = game->CheckGameOver(false);
			Assert::IsFalse(playerEndGame);
			Assert::IsFalse(computerEndGame);
		}
	};
}
