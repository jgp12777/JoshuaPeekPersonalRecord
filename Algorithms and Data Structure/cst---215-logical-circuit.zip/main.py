#Joshua Peek CST 215 Feb 24
# Define XOR (Exclusive OR) function
def XOR(a, b):
    return int(a != b)

# Define AND (Logical AND) function
def AND(a, b):
    return int(a and b)

# Define OR (Logical OR) function
def OR(a, b):
    return int(a or b)

# Define HALF_ADDER function
def HALF_ADDER(A, B):
    # Calculate sum and carry using XOR and AND gates
    Sum = XOR(A, B)
    Carry = AND(A, B)
    return (Sum, Carry)  # Return a tuple (sum, carry)

# Define FULL_ADDER function
def FULL_ADDER(A, B, Cin):
    # Calculate sum and carry_out using XOR, AND, and OR gates
    Sum = XOR(XOR(A, B), Cin)
    Carry_out = OR(AND(A, B), AND(XOR(A, B), Cin))
    return (Sum, Carry_out)  # Return a tuple (sum, carry_out) https://www.w3schools.com/python/python_tuples.asp

# Define PARALLEL_ADDER function
def PARALLEL_ADDER(ABC, DEF):
    result = []  # Initialize an empty list to store the result
    Cin = 0  # Initialize carry-in to 0
    for i in range(3):
        # Iterate through each digit, calculate sum and carry using FULL_ADDER
        Sum, Cin = FULL_ADDER(ABC[i], DEF[i], Cin)
        result.append(Sum)  # Append the sum to the result list
    result.append(Cin)  # Append the final carry-out to the result list
    return tuple(result)  # Return the result as a tuple

# Sample Run
print("Half-adder:")
for i in range(2):
    for j in range(2):
        # Call HALF_ADDER function for all possible inputs
        Sum, Carry = HALF_ADDER(i, j)
        print(f"i = {i} j = {j} | Carry = {Carry} Sum = {Sum}")  # Print the result

print("\nFull-adder:")
for i in range(2):
    for j in range(2):
        for k in range(2):
            # Call FULL_ADDER function for all possible inputs
            Sum, Carry_out = FULL_ADDER(i, j, k)
            print(f"i = {i} j = {j} k = {k} | Carry_out = {Carry_out} Sum = {Sum}")  # Print the result

ABC = (1, 0, 1)
DEF = (0, 1, 1)
print("\nParallel-adder:")
# Call PARALLEL_ADDER function with two 3-digit binary numbers
result = PARALLEL_ADDER(ABC, DEF)
print(f"{ABC[2]}{ABC[1]}{ABC[0]} + {DEF[2]}{DEF[1]}{DEF[0]} = {result[2]}{result[1]}{result[0]}{result[3]}")



