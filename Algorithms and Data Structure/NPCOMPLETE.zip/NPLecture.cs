﻿//Joshua Peek 21081733

using System;

class LectureScheduling
{
    // Method to parse the adjacency matrix representing the lecture conflicts
    private static int[,] ParseMatrix()
    {
        // The adjacency matrix represents conflicts between lectures (1 means conflict, 0 means no conflict)
        return new int[,]
        {
            {0, 1, 1, 1, 0, 1, 0, 0},
            {1, 0, 1, 1, 0, 1, 0, 1},
            {1, 1, 0, 1, 1, 0, 0, 1},
            {1, 1, 1, 0, 0, 0, 1, 1},
            {0, 0, 1, 0, 0, 1, 1, 0},
            {1, 1, 0, 0, 1, 0, 1, 0},
            {0, 0, 0, 1, 1, 1, 0, 0},
            {0, 1, 1, 1, 0, 0, 0, 0}
        };
    }

    // Method to calculate the minimum timeslots needed using a greedy algorithm
    private static int MinimumT(int[,] graph)
    {
        int numVertices = graph.GetLength(0);
        int[] colors = new int[numVertices]; // Array to store the color assigned to each vertex
        Array.Fill(colors, -1); // Initialize all vertices with no color (-1)

        // Iterate through each vertex to assign a color
        for (int vertex = 0; vertex < numVertices; vertex++)
        {
            // Determine the colors of adjacent vertices
            bool[] adjacentColors = new bool[numVertices]; // Track used colors by adjacent vertices
            for (int neighbor = 0; neighbor < numVertices; neighbor++)
            {
                if (graph[vertex, neighbor] == 1 && colors[neighbor] != -1)
                {
                    adjacentColors[colors[neighbor]] = true;
                }
            }

            // Assign the smallest available color to the current vertex
            int color;
            for (color = 0; color < numVertices; color++)
            {
                if (!adjacentColors[color])
                {
                    break;
                }
            }
            colors[vertex] = color;
        }

        // Return the maximum color used (plus one, as colors are zero-indexed)
        return colors.Max() + 1;
    }

    // Method to count the number of conflicts (edges) in the graph
    private static int CountConflicts(int[,] graph)
    {
        int conflicts = 0;
        int numVertices = graph.GetLength(0);

        // Count the number of edges by summing the adjacency matrix
        for (int i = 0; i < numVertices; i++)
        {
            for (int j = i + 1; j < numVertices; j++)
            {
                if (graph[i, j] == 1)
                {
                    conflicts++;
                }
            }
        }

        return conflicts;
    }

    public static void Main()
    {
        // Parse the adjacency matrix
        int[,] graph = ParseMatrix();

        // Calculate the chromatic number (minimum separate times for lectures)
        int minTimes = MinimumT(graph);

        // Calculate the number of conflicts (number of edges)
        int minConflicts = CountConflicts(graph);

        // Output the results
        Console.WriteLine("Minimum number of separate times for the lectures: " + minTimes);
        Console.WriteLine("Minimum number of different students with conflicts in lectures: " + minConflicts);
    }
}
