class TreeNode:
    def __init__(self, data):
        self.data = data
        self.left = None
        self.right = None

class BinarySearchTree:
    def __init__(self):
        self.root = None

    def insert(self, data):
        self.root = self._insert(self.root, data)

    def _insert(self, node, data):
        # If the node is None, create a new node with the given data
        if node is None:
            return TreeNode(data)
        # If data is less than the node's data, insert into the left subtree
        if data < node.data:
            node.left = self._insert(node.left, data)
        # If data is greater than the node's data, insert into the right subtree
        elif data > node.data:
            node.right = self._insert(node.right, data)
        return node

    def inorder_traversal(self, node):
        # Perform inorder traversal: left subtree, root, right subtree
        if node is not None:
            self.inorder_traversal(node.left)
            print(node.data, end=' ')
            self.inorder_traversal(node.right)

    def preorder_traversal(self, node):
        # Perform preorder traversal: root, left subtree, right subtree
        if node is not None:
            print(node.data, end=' ')
            self.preorder_traversal(node.left)
            self.preorder_traversal(node.right)

    def postorder_traversal(self, node):
        # Perform postorder traversal: left subtree, right subtree, root
        if node is not None:
            self.postorder_traversal(node.left)
            self.postorder_traversal(node.right)
            print(node.data, end=' ')

def main():
    bst = BinarySearchTree()

    # Take user input for the number of integers and the integers themselves
    n = int(input("Enter the number of integers: "))
    print("Enter the integers:")
    for _ in range(n):
        num = int(input())
        bst.insert(num)

    while True:
        print("\nMenu:")
        print("1. Display inorder traversal")
        print("2. Display preorder traversal")
        print("3. Display postorder traversal")
        print("4. Exit program")
        choice = int(input("Enter your choice: "))

        if choice == 1:
            print("Inorder Traversal:", end=' ')
            bst.inorder_traversal(bst.root)
        elif choice == 2:
            print("Preorder Traversal:", end=' ')
            bst.preorder_traversal(bst.root)
        elif choice == 3:
            print("Postorder Traversal:", end=' ')
            bst.postorder_traversal(bst.root)
        elif choice == 4:
            print("Exiting program.")
            break
        else:
            print("Invalid choice. Please choose again.")

if __name__ == "__main__":
    main()
