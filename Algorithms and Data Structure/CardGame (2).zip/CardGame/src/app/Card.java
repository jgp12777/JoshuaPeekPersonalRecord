package app;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

class Card {
    private String suit;
    private String value;

    public Card(String suit, String value) {
        this.suit = suit;
        this.value = value; //this. is for only the current method or constructor 
    }

    public String getSuit() {
        return suit;
    }

    public String getValue() {
        return value;
    }
}

class Deck {
    private List<Card> cards;
    private int topCardIndex;

    public Deck() {
        cards = new ArrayList<>();
        topCardIndex = 0;
        createDeck();
        shuffle();
    }
    //private because these values will never change
    private void createDeck() {
        String[] suits = {"Hearts", "Diamonds", "Clubs", "Spades"};
        String[] values = {"2", "3", "4", "5", "6", "7", "8", "9", "10", "Jack", "Queen", "King", "Ace"};

        for (String suit : suits) {
            for (String value : values) {
                cards.add(new Card(suit, value));
            }
        }
    }
    //very handy tool (.shuffle) found on https://www.geeksforgeeks.org/collections-shuffle-method-in-java-with-examples/
    public void shuffle() {
        Collections.shuffle(cards);
    }
    //Value will change with top cards so must be public 
    public Card dealCard() {
        if (topCardIndex < cards.size()) {
            Card card = cards.get(topCardIndex);
            topCardIndex++;
            return card;
        } else {
            System.out.println("No cards left in the deck.");
            return null;
        }
    }
}


