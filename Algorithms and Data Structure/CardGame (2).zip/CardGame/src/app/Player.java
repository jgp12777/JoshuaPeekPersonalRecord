package app;
import java.util.Scanner;
class Player {
    private String name;
    private Hand hand;

    public Player(int playerNumber, Scanner scanner) {
        this.hand = new Hand();
        this.setName(playerNumber, scanner);
    }

    private void setName(int playerNumber, Scanner scanner) {
        System.out.print("Enter the name of Player " + playerNumber + ": ");
        this.name = scanner.nextLine();
    }

    public String getName() {
        return name;
    }

    public Hand getHand() {
        return hand;
    }

    public void addCardToHand(Card card) {
        hand.addCard(card);
    }

    public int getHandTotal() {
        return hand.getHandTotal();
    }
}
