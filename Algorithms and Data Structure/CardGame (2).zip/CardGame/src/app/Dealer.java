package app;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
class Dealer {
    private Deck deck;
    private List<Player> players;
    private Hand hand;

    public Dealer(Deck deck) {
        this.deck = deck;
        this.players = new ArrayList<>();
        this.hand = new Hand();
    }

    public void addPlayer(Player player) {
        players.add(player);
    }

    public List<Player> getPlayers() {
        return players;
    }

    public void startDeal() {
        for (Player player : players) {
            player.addCardToHand(deck.dealCard());
            player.addCardToHand(deck.dealCard());
        }

        hand.addCard(deck.dealCard()); // Dealer's first card
        hand.addCard(deck.dealCard()); // Dealer's second card (hidden)
    }

    public void performPlayerTurn(Player player, Scanner scanner) {
        System.out.println("Player " + player.getName() + "'s turn:");

        while (player.getHandTotal() < 21) {
            System.out.println("Current Hand: " + player.getHandTotal());
            System.out.print("Do you want to hit? (y/n): ");
            char choice = scanner.next().charAt(0);

            if (choice == 'y' || choice == 'Y') {
                player.addCardToHand(deck.dealCard());
            } else if (choice == 'n' || choice == 'N') {
                break;
            } else {
                System.out.println("Invalid choice. Please enter 'y' or 'n'.");
            }
        }
    }

    public void performDealerTurn() {
        System.out.println("Dealer's turn:");

        while (hand.getHandTotal() < 17) {
            hand.addCard(deck.dealCard());
        }
    }

    public void determineWinners() {
        int dealerTotal = hand.getHandTotal();

        System.out.println("\nResults:");

        for (Player player : players) {
            int playerTotal = player.getHandTotal();

            System.out.println(player.getName() + "'s Hand: " + playerTotal);

            if (playerTotal > 21 || (dealerTotal <= 21 && dealerTotal >= playerTotal)) {
                System.out.println(player.getName() + " loses.");
            } else {
                System.out.println(player.getName() + " wins!");
            }
        }

        System.out.println("Dealer's Hand: " + dealerTotal);
    }

    public void displayHands() {
        System.out.println("\nHands:");

        for (Player player : players) {
            System.out.println(player.getName() + "'s Hand: " + player.getHandTotal());
        }

        System.out.println("Dealer's Hand: " + hand.getHandTotal());
    }
}