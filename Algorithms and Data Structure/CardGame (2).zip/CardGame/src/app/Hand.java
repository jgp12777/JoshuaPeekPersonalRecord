package app;
import java.util.ArrayList;
import java.util.List;
class Hand {
    private List<Card> cards;

    public Hand() {
        cards = new ArrayList<>();
    }

    public void addCard(Card card) {
        cards.add(card);
    }

    public int getHandTotal() {
        int total = 0;
        int numAces = 0;

        for (Card card : cards) {
            String value = card.getValue();

            if (value.equals("Jack") || value.equals("Queen") || value.equals("King")) {
                total += 10;
            } else if (value.equals("Ace")) {
                total += 11;
                numAces++;
            } else {
                total += Integer.parseInt(value);
            }
        }

        // Handle Aces
        while (numAces > 0 && total > 21) {
            total -= 10;
            numAces--;
        }

        return total;
    }
}
