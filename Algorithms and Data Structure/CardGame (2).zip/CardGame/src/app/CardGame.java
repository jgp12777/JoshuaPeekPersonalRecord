package app;

import java.util.Scanner;
public class CardGame {
    public static void main(String[] args) {
        // Create a deck
        Deck deck = new Deck();

        // Use Scanner for user input
        Scanner scanner = new Scanner(System.in);

        // Prompt user for the number of players (up to six)
        int numPlayers = 0;
        try {
            System.out.print("Enter the number of players (up to 6): ");
            numPlayers = scanner.nextInt();
            scanner.nextLine();  // Consume the newline character
        } catch (Exception e) {
            System.out.println("Invalid input. Please enter a valid number.");
            System.exit(1);
        }

        // Create a dealer with the deck
        Dealer dealer = new Dealer(deck);

        // Create players and add them to the dealer
        for (int i = 1; i <= numPlayers; i++) {
            Player player = new Player(i, scanner);
            dealer.addPlayer(player);
        }

        // Start the deal
        dealer.startDeal();

        // Perform player turns
        for (Player player : dealer.getPlayers()) {
            dealer.performPlayerTurn(player, scanner);
        }

        // Perform dealer turn
        dealer.performDealerTurn();

        // Display hands
        dealer.displayHands();

        // Determine winners
        dealer.determineWinners();

        // Close scanner
        scanner.close();
    }
}