/**
 * 
 */
/**
 * 
 */
module CardGame {
}