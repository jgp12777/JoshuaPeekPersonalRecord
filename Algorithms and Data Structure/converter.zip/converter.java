package app;
import java.util.Scanner;

public class converter {

	public static void main(String[] args) {
	System.out.println("Enter a value in Celcius!");
	Scanner scnr = new Scanner(System.in);	
	double cVal = scnr.nextFloat();
	double fVal = (1.8 * cVal) + 32;
	System.out.println("The value you entered was " + cVal + " Celcius.");
	System.out.print("That value in Farenheight is ");
	System.out.printf("%.1f%n", fVal);
	System.out.println("Now enter a value in Farenheight!");
	fVal = scnr.nextFloat();
	cVal = ((fVal - 32) * 5/9);
	System.out.println("The value you entered was " + fVal + " Farenheight.");
	System.out.print("That value in Celcius is ");
	System.out.printf("%.1f%n", cVal);
	

	}

}
