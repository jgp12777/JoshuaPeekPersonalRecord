﻿using System;
using System.Collections.Generic;

class SortingAnalysis
{   
    //Joshua Peek 21081733 
    static Random random = new Random(); // Random object for shuffling
    static void Main()
    {
        // Prompt user to enter the size of the array (n)
        Console.Write("Enter the size of the array (n): ");
        int n = int.Parse(Console.ReadLine()); // Parse input to integer

        int repetitions = 100; // Number of times to repeat the sorting process for averaging

        // Variables to store the sum of comparisons and exchanges for each sorting algorithm
        double selectionComparisons = 0, selectionExchanges = 0;
        double bubbleComparisons = 0, bubbleExchanges = 0;
        double mergeComparisons = 0, mergeExchanges = 0;
        double quickComparisons = 0, quickExchanges = 0;

        // Repeat sorting and data tracking for a set number of repetitions (100 in this case)
        for (int i = 0; i < repetitions; i++)
        {
            // Create a new array from 1 to n and shuffle it
            int[] array = CreateArray(n);
            ShuffleArray(array);

            int comparisons, exchanges; // Variables to store comparisons and exchanges per run

            // Selection Sort
            int[] tempArray = (int[])array.Clone(); // Clone array to keep the original shuffled state
            (comparisons, exchanges) = SelectionSort(tempArray); // Sort and get metrics
            selectionComparisons += comparisons; // Accumulate comparisons
            selectionExchanges += exchanges; // Accumulate exchanges

            // Bubble Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = BubbleSort(tempArray); // Sort and get metrics
            bubbleComparisons += comparisons; // Accumulate comparisons
            bubbleExchanges += exchanges; // Accumulate exchanges

            // Merge Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = MergeSort(tempArray); // Sort and get metrics
            mergeComparisons += comparisons; // Accumulate comparisons
            mergeExchanges += exchanges; // Accumulate exchanges

            // Quick Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = QuickSort(tempArray, 0, n - 1); // Sort and get metrics
            quickComparisons += comparisons; // Accumulate comparisons
            quickExchanges += exchanges; // Accumulate exchanges

        }

        // Output the average comparisons and exchanges for each sorting algorithm
        Console.WriteLine("Average comparisons and exchanges for each algorithm over 100 runs:");
        Console.WriteLine($"Selection Sort - Comparisons: {selectionComparisons / repetitions}, Exchanges: {selectionExchanges / repetitions}");
        Console.WriteLine($"Bubble Sort - Comparisons: {bubbleComparisons / repetitions}, Exchanges: {bubbleExchanges / repetitions}");
        Console.WriteLine($"Merge Sort - Comparisons: {mergeComparisons / repetitions}, Exchanges: {mergeExchanges / repetitions}");
        Console.WriteLine($"Quick Sort - Comparisons: {quickComparisons / repetitions}, Exchanges: {quickExchanges / repetitions}");

    }

    // Function to create an array with numbers from 1 to n
    static int[] CreateArray(int n)
    {
        int[] array = new int[n];
        for (int i = 0; i < n; i++)
            array[i] = i + 1; // Fill array with numbers from 1 to n
        return array;
    }

    // Function to shuffle the array using Fisher-Yates shuffle
    static void ShuffleArray(int[] array)
    {
        for (int i = array.Length - 1; i > 0; i--)
        {
            int j = random.Next(i + 1); // Pick a random index to swap with
            (array[i], array[j]) = (array[j], array[i]); // Swap elements
        }
    }

    // Selection Sort implementation with comparison and exchange count tracking
    static (int, int) SelectionSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        for (int i = 0; i < array.Length - 1; i++)
        {
            int minIndex = i; // Assume the minimum is the current index
            for (int j = i + 1; j < array.Length; j++)
            {
                comparisons++; // Count comparisons
                if (array[j] < array[minIndex])
                    minIndex = j;
            }
            if (minIndex != i)
            {
                (array[i], array[minIndex]) = (array[minIndex], array[i]); // Swap if necessary
                exchanges++; // Count exchanges
            }
        }
        return (comparisons, exchanges);
    }

    // Bubble Sort implementation with comparison and exchange count tracking
    static (int, int) BubbleSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        for (int i = 0; i < array.Length - 1; i++)
        {
            for (int j = 0; j < array.Length - i - 1; j++)
            {
                comparisons++; // Count comparisons
                if (array[j] > array[j + 1])
                {
                    (array[j], array[j + 1]) = (array[j + 1], array[j]); // Swap if elements are out of order
                    exchanges++; // Count exchanges
                }
            }
        }
        return (comparisons, exchanges);
    }

    // Merge Sort wrapper to track comparisons and exchanges
    static (int, int) MergeSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        MergeSortHelper(array, 0, array.Length - 1, ref comparisons, ref exchanges); // Call recursive helper
        return (comparisons, exchanges);
    }

    // Recursive helper function for Merge Sort
    static void MergeSortHelper(int[] array, int left, int right, ref int comparisons, ref int exchanges)
    {
        if (left < right)
        {
            int mid = (left + right) / 2;
            MergeSortHelper(array, left, mid, ref comparisons, ref exchanges); // Sort left half
            MergeSortHelper(array, mid + 1, right, ref comparisons, ref exchanges); // Sort right half
            Merge(array, left, mid, right, ref comparisons, ref exchanges); // Merge sorted halves
        }
    }

    // Merge function to combine two sorted halves
    static void Merge(int[] array, int left, int mid, int right, ref int comparisons, ref int exchanges)
    {
        int[] temp = new int[right - left + 1];
        int i = left, j = mid + 1, k = 0;

        while (i <= mid && j <= right)
        {
            comparisons++; // Count comparisons
            if (array[i] <= array[j])
                temp[k++] = array[i++];
            else
                temp[k++] = array[j++];
        }

        // Copy remaining elements, if any
        while (i <= mid) temp[k++] = array[i++];
        while (j <= right) temp[k++] = array[j++];

        // Copy temp array back into original array and count exchanges
        for (i = left, k = 0; i <= right; i++, k++)
        {
            exchanges++; // Count exchanges for copying
            array[i] = temp[k];
        }
    }

    // Quick Sort with partitioning and tracking of comparisons and exchanges
    static (int, int) QuickSort(int[] array, int left, int right)
    {
        int comparisons = 0, exchanges = 0;
        if (left < right)
        {
            int pivotIndex = Partition(array, left, right, ref comparisons, ref exchanges); // Partition array
            var (leftComparisons, leftExchanges) = QuickSort(array, left, pivotIndex - 1); // Sort left partition
            var (rightComparisons, rightExchanges) = QuickSort(array, pivotIndex + 1, right); // Sort right partition
            comparisons += leftComparisons + rightComparisons;
            exchanges += leftExchanges + rightExchanges;
        }
        return (comparisons, exchanges);
    }

    // Partition function for Quick Sort
    static int Partition(int[] array, int left, int right, ref int comparisons, ref int exchanges)
    {
        int pivot = array[right]; // Choose pivot as the last element
        int i = left - 1;
        for (int j = left; j < right; j++)
        {
            comparisons++; // Count comparisons
            if (array[j] < pivot)
            {
                i++;
                (array[i], array[j]) = (array[j], array[i]); // Swap elements to arrange around pivot
                exchanges++; // Count exchanges
            }
        }
        (array[i + 1], array[right]) = (array[right], array[i + 1]); // Place pivot in correct position
        exchanges++; // Count final pivot exchange
        return i + 1;
    }
}
/* The program prompts the user for an integer n to set the size of an array.
 *  It then creates an array of numbers from 1 to n, shuffles it, and repeatedly sorts it 100 times using various sorting algorithms:
 *  Selection Sort, Bubble Sort, Merge Sort, Quick Sort, and an optimized built-in sort (Array.Sort).
 *  Each algorithm sorts a fresh clone of the shuffled array to ensure consistency.
 *  During each sort, the program tracks the number of comparisons and exchanges, accumulating these counts to calculate averages.
 *  Finally, it outputs the average comparisons and exchanges for each algorithm, providing a comparative analysis of their efficiency.
*/ 
