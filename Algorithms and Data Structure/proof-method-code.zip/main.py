def is_prime(num):
    """
    Check if a number is prime.
    
    Args:
    - num: The number to be checked
    
    Returns:
    - True if the number is prime, False otherwise
    """
    # Base cases: 0, 1 are not prime
    if num <= 1:
        return False
    # 2 and 3 are prime
    if num <= 3:
        return True
    # Any number divisible by 2 or 3 is not prime (except 2 and 3)
    if num % 2 == 0 or num % 3 == 0:
        return False
    # Check divisibility up to the square root of the number
    i = 5
    while i * i <= num:
        # Check divisibility by i and i+2
        if num % i == 0 or num % (i + 2) == 0:
            return False
        # Increment i by 6 (optimization for checking primes)
        i += 6
    return True

def divisors(num):
    """
    Find all divisors of a given number.
    
    Args:
    - num: The number whose divisors are to be found
    
    Returns:
    - List of divisors of the given number
    """
    divs = [1]  # Start with 1 as all numbers are divisible by 1
    for i in range(2, num):
        if num % i == 0:
            divs.append(i)  # Add the divisor to the list
    return divs

def perfect_numbers():
    """
    Find perfect numbers for prime numbers less than 10.
    
    This function iterates through prime numbers less than 10,
    calculates the corresponding perfect number using the formula,
    and finds all divisors of the perfect number.
    """
    for n in range(2, 10):  # Loop through prime numbers less than 10
        if is_prime(n):  # Check if n is prime
            # Calculate Mersenne prime and perfect number
            mersenne_prime = pow(2, n) - 1
            perfect_number = pow(2, n - 1) * mersenne_prime
            
            # Find divisors of the perfect number
            perfect_divisors = divisors(perfect_number)
            
            # Print the prime number, perfect number, and its divisors
            print(f"n = {n}, pow(2, n-1) * (pow(2, n) - 1) = {perfect_number}")
            print(f"Divisors of pow(2, n-1) * (pow(2, n) - 1): {perfect_divisors}")
            print()

def check_user_input():
    """
    Allow the user to input a number and check if it's a prime number less than 10.
    """
    user_input = input("Enter a number to check if it's a prime number less than 10: ")
    try:
        user_input = int(user_input)
        if user_input >= 2 and user_input < 10:
            if is_prime(user_input):
                print(f"{user_input} is a prime number less than 10.")
            else:
                print(f"{user_input} is not a prime number less than 10.")
        else:
            print("Please enter a number between 2 and 9.")
    except ValueError:
        print("Invalid input. Please enter a valid number.")

# Call the function to find perfect numbers for prime numbers less than 10
perfect_numbers()

# Call the function to allow the user to input a number and check if it's a prime number less than 10
check_user_input()
