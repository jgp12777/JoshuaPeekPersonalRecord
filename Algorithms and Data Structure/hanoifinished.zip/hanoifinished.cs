using System;

class TowerOfHanoiDiskMoves
{
    static void Main()
    {
        try
        {
            // Prompt the user to enter the total number of disks (n)
            Console.Write("Enter the total number of disks (n): ");
            // Read the input from the console and parse it to an integer
            int n = int.Parse(Console.ReadLine());

            // Check if the number of disks is a positive integer
            if (n <= 0)
            {
                Console.WriteLine("Invalid number of disks.");
                return; // Exit the program if the input is invalid
            }

            // Prompt the user to enter the disk index (i)
            Console.Write($"Enter the disk index (i) (1 ≤ i ≤ {n}): ");
            // input from the console and parse it to an integer
            int i = int.Parse(Console.ReadLine());

            // Check if the disk index is within the valid range
            if (i < 1 || i > n)
            {
                Console.WriteLine("Invalid disk index.");
                return; // Exit program if input is invalid
            }

            // calculate the number of moves made by the ith largest disk
            long moves = CalculateDiskMoves(n, i);

            // Output the result to the console
            Console.WriteLine($"The number of moves made by disk {i} is {moves}.");
        }
        catch (FormatException)
        {
            // input is not a valid integer
            Console.WriteLine("Invalid input. Please enter integer values.");
        }
        catch (OverflowException)
        {
            // input is too large to be stored in an int
            Console.WriteLine("Input value is too large.");
        }
        Console.ReadKey();
    }

    /// summary:
    /// Calculates the number of moves made by the ith largest disk in the Tower of Hanoi puzzle.
    
    // "n"> Total number of disks in the puzzle.
    // "i"> Index of the disk for which to calc the number of moves (1 ≤ i ≤ n)
    // The number of moves made by the ith largst disk
    static long CalculateDiskMoves(int n, int i)
    {
        // The number of moves for the ith largest disk is 2^(n - i)
        // Explanation:
        // Each disk moves twice as many times as the disk immediately larger than it
        // The largest disk (disk n) moves exactly once
        // the ith largest disk moves 2^(n - i) times
        return (long)Math.Pow(2, n - i);
    }
}
