﻿using System;

class SortingAnalysis
{
    static Random random = new Random(); // Random object for shuffling arrays

    static void Main()
    {
        // Prompt the user to enter the array size (n)
        Console.Write("Enter the size of the array (n): ");
        int n = int.Parse(Console.ReadLine());
        int repetitions = 100; // Number of times to repeat each sorting algorithm to average results

        // Initialize variables to accumulate total comparisons and swaps for each algorithm
        double selectionComparisons = 0, selectionExchanges = 0;
        double bubbleComparisons = 0, bubbleExchanges = 0;
        double mergeComparisons = 0, mergeExchanges = 0;
        double quickComparisons = 0, quickExchanges = 0;
        double hybridComparisonsSum = 0, hybridSwapsSum = 0;

        // Repeat sorting and tracking for each algorithm 100 times
        for (int i = 0; i < repetitions; i++)
        {
            // Step 2: Create an array with values 1 to n and shuffle it
            int[] array = CreateArray(n);
            ShuffleArray(array);

            int comparisons, exchanges;

            // Selection Sort
            int[] tempArray = (int[])array.Clone(); // Clone to maintain shuffled state
            (comparisons, exchanges) = SelectionSort(tempArray); // Sort and get metrics
            selectionComparisons += comparisons;
            selectionExchanges += exchanges;

            // Bubble Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = BubbleSort(tempArray); // Sort and get metrics
            bubbleComparisons += comparisons;
            bubbleExchanges += exchanges;

            // Merge Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = MergeSort(tempArray); // Sort and get metrics
            mergeComparisons += comparisons;
            mergeExchanges += exchanges;

            // Quick Sort
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = QuickSort(tempArray, 0, n - 1); // Sort and get metrics
            quickComparisons += comparisons;
            quickExchanges += exchanges;

            // Hybrid Sort (Quick Sort + Insertion Sort)
            tempArray = (int[])array.Clone(); // Clone original shuffled array
            (comparisons, exchanges) = HybridSort(tempArray); // Sort and get metrics
            hybridComparisonsSum += comparisons;
            hybridSwapsSum += exchanges;
        }

        // Output the average comparisons and swaps for each sorting algorithm
        Console.WriteLine("Average comparisons and exchanges for each algorithm over 100 runs:");
        Console.WriteLine($"Selection Sort - Comparisons: {selectionComparisons / repetitions}, Exchanges: {selectionExchanges / repetitions}");
        Console.WriteLine($"Bubble Sort - Comparisons: {bubbleComparisons / repetitions}, Exchanges: {bubbleExchanges / repetitions}");
        Console.WriteLine($"Merge Sort - Comparisons: {mergeComparisons / repetitions}, Exchanges: {mergeExchanges / repetitions}");
        Console.WriteLine($"Quick Sort - Comparisons: {quickComparisons / repetitions}, Exchanges: {quickExchanges / repetitions}");
        Console.WriteLine($"Hybrid Sort (Quick Sort + Insertion Sort) - Comparisons: {hybridComparisonsSum / repetitions}, Swaps: {hybridSwapsSum / repetitions}");
    }

    // Function to create an array of numbers from 1 to n
    static int[] CreateArray(int n)
    {
        int[] array = new int[n];
        for (int i = 0; i < n; i++)
            array[i] = i + 1; // Fill array with values from 1 to n
        return array;
    }

    // Function to shuffle the array using Fisher-Yates shuffle algorithm
    static void ShuffleArray(int[] array)
    {
        for (int i = array.Length - 1; i > 0; i--)
        {
            int j = random.Next(i + 1); // Pick a random index to swap with
            (array[i], array[j]) = (array[j], array[i]); // Swap elements
        }
    }

    // Selection Sort implementation with tracking of comparisons and swaps
    static (int, int) SelectionSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        for (int i = 0; i < array.Length - 1; i++)
        {
            int minIndex = i; // Assume the minimum is at the current index
            for (int j = i + 1; j < array.Length; j++)
            {
                comparisons++; // Increment comparison count
                if (array[j] < array[minIndex])
                    minIndex = j;
            }
            if (minIndex != i)
            {
                (array[i], array[minIndex]) = (array[minIndex], array[i]); // Swap elements if needed
                exchanges++; // Increment swap count
            }
        }
        return (comparisons, exchanges); // Return total comparisons and swaps
    }

    // Bubble Sort implementation with tracking of comparisons and swaps
    static (int, int) BubbleSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        for (int i = 0; i < array.Length - 1; i++)
        {
            for (int j = 0; j < array.Length - i - 1; j++)
            {
                comparisons++; // Increment comparison count
                if (array[j] > array[j + 1])
                {
                    (array[j], array[j + 1]) = (array[j + 1], array[j]); // Swap elements
                    exchanges++; // Increment swap count
                }
            }
        }
        return (comparisons, exchanges); // Return total comparisons and swaps
    }

    // Merge Sort implementation with tracking of comparisons and swaps
    static (int, int) MergeSort(int[] array)
    {
        int comparisons = 0, exchanges = 0;
        MergeSortHelper(array, 0, array.Length - 1, ref comparisons, ref exchanges); // Recursive helper
        return (comparisons, exchanges);
    }

    // Recursive helper function for Merge Sort
    static void MergeSortHelper(int[] array, int left, int right, ref int comparisons, ref int exchanges)
    {
        if (left < right)
        {
            int mid = (left + right) / 2;
            MergeSortHelper(array, left, mid, ref comparisons, ref exchanges); // Sort left half
            MergeSortHelper(array, mid + 1, right, ref comparisons, ref exchanges); // Sort right half
            Merge(array, left, mid, right, ref comparisons, ref exchanges); // Merge sorted halves
        }
    }

    // Merging function for Merge Sort with tracking
    static void Merge(int[] array, int left, int mid, int right, ref int comparisons, ref int exchanges)
    {
        int[] temp = new int[right - left + 1]; // Temporary array for merged elements
        int i = left, j = mid + 1, k = 0;

        // Compare and merge elements from two halves
        while (i <= mid && j <= right)
        {
            comparisons++; // Count each comparison
            if (array[i] <= array[j])
                temp[k++] = array[i++];
            else
                temp[k++] = array[j++];
        }

        // Copy any remaining elements from both halves
        while (i <= mid) temp[k++] = array[i++];
        while (j <= right) temp[k++] = array[j++];

        // Copy merged elements back to the original array
        for (i = left, k = 0; i <= right; i++, k++)
        {
            exchanges++; // Count each write-back as an exchange
            array[i] = temp[k];
        }
    }

    // Quick Sort implementation with tracking of comparisons and swaps
    static (int, int) QuickSort(int[] array, int left, int right)
    {
        int comparisons = 0, exchanges = 0;
        if (left < right)
        {
            int pivotIndex = Partition(array, left, right, ref comparisons, ref exchanges); // Partition array
            var (leftComparisons, leftExchanges) = QuickSort(array, left, pivotIndex - 1);
            var (rightComparisons, rightExchanges) = QuickSort(array, pivotIndex + 1, right);
            comparisons += leftComparisons + rightComparisons; // Total comparisons
            exchanges += leftExchanges + rightExchanges; // Total exchanges
        }
        return (comparisons, exchanges); // Return total comparisons and swaps
    }

    // Partition function for Quick Sort with tracking
    static int Partition(int[] array, int left, int right, ref int comparisons, ref int exchanges)
    {
        int pivot = array[right]; // Choose pivot as the last element
        int i = left - 1;
        for (int j = left; j < right; j++)
        {
            comparisons++; // Count each comparison
            if (array[j] < pivot)
            {
                i++;
                (array[i], array[j]) = (array[j], array[i]); // Swap elements
                exchanges++; // Count swap
            }
        }

        (array[i + 1], array[right]) = (array[right], array[i + 1]); // Place pivot in correct position
        exchanges++; // Final swap for pivot
        return i + 1; // Return pivot index
    }

    // Hybrid Sort (Quick Sort + Insertion Sort) with tracking
    static (int, int) HybridSort(int[] array)
    {
        int comparisons = 0;
        int swaps = 0;
        HybridQuickSort(array, 0, array.Length - 1, ref comparisons, ref swaps); // Call hybrid sort
        return (comparisons, swaps); // Return total comparisons and swaps
    }

    // Hybrid Quick Sort implementation with a threshold to switch to Insertion Sort
    static void HybridQuickSort(int[] array, int left, int right, ref int comparisons, ref int swaps, int threshold = 10)
    {
        // Switch to Insertion Sort if partition size is below threshold
        if (right - left < threshold)
        {
            InsertionSort(array, left, right, ref comparisons, ref swaps); // Use Insertion Sort for small partitions
            return;
        }

        // Otherwise, proceed with Quick Sort
        if (left < right)
        {
            int pivotIndex = Partition(array, left, right, ref comparisons, ref swaps); // Partition array
            HybridQuickSort(array, left, pivotIndex - 1, ref comparisons, ref swaps, threshold); // Sort left partition
            HybridQuickSort(array, pivotIndex + 1, right, ref comparisons, ref swaps, threshold); // Sort right partition
        }
    }

    // Insertion Sort for small partitions within Hybrid Sort
    static void InsertionSort(int[] array, int left, int right, ref int comparisons, ref int swaps)
    {
        for (int i = left + 1; i <= right; i++)
        {
            int key = array[i];
            int j = i - 1;
            while (j >= left && array[j] > key)
            {
                comparisons++; // Count each comparison
                array[j + 1] = array[j];
                j--;
                swaps++; // Count each shift as a swap
            }
            array[j + 1] = key;
            swaps++; // Count insertion as a swap
        }
    }
}
