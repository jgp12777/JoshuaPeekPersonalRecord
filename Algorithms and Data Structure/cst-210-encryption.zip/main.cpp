//Joshua Peek CST 210 Jan 28 2024
#include <iostream>
#include <vector>
#include <cctype>

 using namespace std;

 
// Function to encrypt a word based on a given shift
  string encrypt (const string & word, int shift)
{
  
string encryptedWord = "";

for (char ch:word)
      { 
if (isalpha (ch))
	{
char base = isupper (ch) ? 'A' : 'a';
	 
	 // Shift the letter by the specified amount
	 char shiftedChar = (ch - base + shift) % 26 + base;
	 
encryptedWord += shiftedChar;
	 
}
	 else
	 {
	 
	 // Keep non-alphabetic characters unchanged
	 encryptedWord += ch;
	 
}
	 
}
	 
return encryptedWord;
	 
}

	 
 
// Function to display the original and encrypted words in tabular format
	 void displayTable (const vector < string > &words, int shift)
	 {
	 
cout << "Original Word\tEncrypted Word" << endl;

for (const string & word:words)
	 { 
string encryptedWord = encrypt (word, shift);
	 
cout << word << "\t\t" << encryptedWord << endl;
	 
} 
} 
 
int main ()
	 {
	 
int shift; 
cout << "Enter the shift value: "; 
cin >> shift; 
cin.ignore ();	// Clear the newline character from the input buffer
	 
vector < string > words; 
cout << "Enter a list of words to be encrypted (separated by spaces): "; 
 
string word; 
getline (cin, word);	// Read the entire line including spaces
	 size_t start = 0, end;
	 
while ((end = word.find (' ', start)) != string::npos)
	 {
	 
words.push_back (word.substr (start, end - start));
	 
start = end + 1; 
}
	 
words.push_back (word.substr (start));	// Add the last word
	 
displayTable (words, shift); 
 
return 0; 
}

	 
