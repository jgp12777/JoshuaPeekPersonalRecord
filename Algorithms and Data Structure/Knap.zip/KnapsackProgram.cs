﻿using System;

class KnapsackProblem
{
    // Knapsack using Greedy Technique (Dynamic)
    public static double KnapsackGreedyDynamic(int[] weights, int[] values, int capacity)
    {
        int n = weights.Length;
        double[] ratio = new double[n];

        // Calculate value-to-weight ratio for each item
        for (int i = 0; i < n; i++)
        {
            ratio[i] = (double)values[i] / weights[i];
        }

        // Sort items by value-to-weight ratio in descending order
        // This sorting helps in selecting items with the highest value per unit weight first
        Array.Sort(ratio, weights);
        Array.Sort(ratio, values);
        Array.Reverse(ratio);
        Array.Reverse(weights);
        Array.Reverse(values);

        double totalValue = 0; // To store the total value of items in the knapsack
        int steps = 0; // To count the number of steps taken in the algorithm

        // Iterate through all items and add them to the knapsack if possible
        for (int i = 0; i < n; i++)
        {
            steps++; // Increment step count for each iteration

            // If the entire item can fit in the remaining capacity, add it
            if (capacity >= weights[i])
            {
                capacity -= weights[i]; // Reduce the capacity of the knapsack
                totalValue += values[i]; // Add the value of the item to the total value
                Console.WriteLine($"Item {i + 1}: Added full item with weight {weights[i]} and value {values[i]}");
            }
            else
            {
                // If only part of the item can fit, take the fraction of it
                totalValue += ratio[i] * capacity; // Add the proportional value to the total value
                Console.WriteLine($"Item {i + 1}: Added partial item with weight {capacity} and value {ratio[i] * capacity}");
                capacity = 0; // Knapsack is now full
                break; // Exit the loop since no more items can be added
            }
        }

        // Display the number of steps taken (Complexity: O(n log n) for sorting + O(n) for selection)
        Console.WriteLine($"Greedy Dynamic Technique Steps: {steps}");

        return totalValue; // Return the maximum value that can be obtained
    }

    // Knapsack with multiple quantities using Greedy Technique (Dynamic)
    public static double KnapsackGreedyDynamicWithQuantities(int[] weights, int[] values, int[] quantities, int capacity)
    {
        int n = weights.Length;
        double[] ratio = new double[n];

        // Calculate value-to-weight ratio for each item
        for (int i = 0; i < n; i++)
        {
            ratio[i] = (double)values[i] / weights[i];
        }

        // Sort items by value-to-weight ratio in descending order
        Array.Sort(ratio, weights);
        Array.Sort(ratio, values);
        Array.Sort(ratio, quantities);
        Array.Reverse(ratio);
        Array.Reverse(weights);
        Array.Reverse(values);
        Array.Reverse(quantities);

        double totalValue = 0; // To store the total value of items in the knapsack
        int steps = 0; // To count the number of steps taken in the algorithm

        // Iterate through all items and add them to the knapsack if possible, considering quantities
        for (int i = 0; i < n; i++)
        {
            int count = quantities[i];
            while (count > 0 && capacity > 0)
            {
                steps++; // Increment step count for each iteration

                // If the entire item can fit in the remaining capacity, add it
                if (capacity >= weights[i])
                {
                    capacity -= weights[i]; // Reduce the capacity of the knapsack
                    totalValue += values[i]; // Add the value of the item to the total value
                    count--; // Decrease the quantity of the current item
                    Console.WriteLine($"Item {i + 1}: Added full item with weight {weights[i]} and value {values[i]}");
                }
                else
                {
                    // If only part of the item can fit, take the fraction of it
                    totalValue += ratio[i] * capacity; // Add the proportional value to the total value
                    Console.WriteLine($"Item {i + 1}: Added partial item with weight {capacity} and value {ratio[i] * capacity}");
                    capacity = 0; // Knapsack is now full
                    break; // Exit the loop since no more items can be added
                }
            }
        }

        // Display the number of steps taken (Complexity: O(n log n) for sorting + O(n * quantities[i]) for selection)
        Console.WriteLine($"Greedy Dynamic Technique with Quantities Steps: {steps}");

        return totalValue; // Return the maximum value that can be obtained
    }

    static void Main(string[] args)
    {
        int[] weights = { 20, 30, 40, 60, 70, 90 };
        int[] values = { 70, 80, 90, 110, 120, 200 };
        int capacity = 280;

        // Solve using Greedy Technique (Dynamic)
        double maxValueGreedyDynamic = KnapsackGreedyDynamic(weights, values, capacity);
        Console.WriteLine($"Maximum value using Greedy Dynamic Technique: {maxValueGreedyDynamic}\n");

        // Solve using Greedy Technique with Quantities (Dynamic)
        int[] quantities = { 1, 2, 1, 3, 1, 2 };
        double maxValueGreedyDynamicWithQuantities = KnapsackGreedyDynamicWithQuantities(weights, values, quantities, capacity);
        Console.WriteLine($"Maximum value using Greedy Dynamic Technique with Quantities: {maxValueGreedyDynamicWithQuantities}\n");
    }
}
