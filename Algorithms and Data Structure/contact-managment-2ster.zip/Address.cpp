#include "Address.h"
#include <iostream>

Address::Address() : streetAddress(""), state(""), zip("") {}

Address::Address(const std::string& street, const std::string& st, const std::string& z)
    : streetAddress(street), state(st), zip(z) {}

Address::Address(const Address& other)
    : streetAddress(other.streetAddress), state(other.state), zip(other.zip) {}

void Address::setStreetAddress(const std::string& street) {
    streetAddress = street;
}

void Address::setState(const std::string& st) {
    state = st;
}

void Address::setZip(const std::string& z) {
    zip = z;
}

std::string Address::getStreetAddress() const {
    return streetAddress;
}

std::string Address::getState() const {
    return state;
}

std::string Address::getZip() const {
    return zip;
}

void Address::showAddress() const {
    std::cout << streetAddress << ", " << state << " " << zip << std::endl;
}
std::ostream& operator<<(std::ostream& out, const Address& address) {
    out << address.streetAddress << std::endl;
    out << address.state << std::endl;
    out << address.zip << std::endl;
    return out;
}

std::istream& operator>>(std::istream& in, Address& address) {
    std::getline(in, address.streetAddress);
    std::getline(in, address.state);
    std::getline(in, address.zip);
    return in;
}