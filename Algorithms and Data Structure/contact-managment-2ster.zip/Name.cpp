#include "Name.h"
#include <iostream>

Name::Name() : last_name(""), first_name(""), middle_name("") {}

Name::Name(const std::string& last, const std::string& first, const std::string& middle)
    : last_name(last), first_name(first), middle_name(middle) {}

Name::Name(const Name& other)
    : last_name(other.last_name), first_name(other.first_name), middle_name(other.middle_name) {}

void Name::setLastName(const std::string& last) {
    last_name = last;
}

void Name::setFirstName(const std::string& first) {
    first_name = first;
}

void Name::setMiddleName(const std::string& middle) {
    middle_name = middle;
}

std::string Name::getLastName() const {
    return last_name;
}

std::string Name::getFirstName() const {
    return first_name;
}

std::string Name::getMiddleName() const {
    return middle_name;
}

void Name::showName() const {
    std::cout << last_name << ", " << first_name << " " << middle_name << std::endl;
}
std::ostream& operator<<(std::ostream& out, const Name& name) {
    out << name.last_name << std::endl;
    out << name.first_name << std::endl;
    out << name.middle_name << std::endl;
    return out;
}

std::istream& operator>>(std::istream& in, Name& name) {
    std::getline(in, name.last_name);
    std::getline(in, name.first_name);
    std::getline(in, name.middle_name);
    return in;
}