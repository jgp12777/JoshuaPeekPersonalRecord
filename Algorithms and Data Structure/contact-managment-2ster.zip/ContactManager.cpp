#include "ContactManager.h"

ContactManager::ContactManager() {}

Contact ContactManager::getContact(int index) const {
    if (index >= 0 && index < contacts.size()) {
        return contacts[index];
    }
    // Return a default contact if index is out of bounds
    return Contact();
}

std::vector<Contact> ContactManager::getContacts(std::string last_name) const {
    std::vector<Contact> matchingContacts;
    for (const auto& contact : contacts) {
        if (contact.getLastName() == last_name) {
            matchingContacts.push_back(contact);
        }
    }
    return matchingContacts;
}

void ContactManager::addContact() {
    // Prompt user for new contact data and add it to contacts vector
    std::string last, first, middle, street, state, zip, phone;
    std::cout << "Enter last name: ";
    std::cin >> last;
    std::cout << "Enter first name: ";
    std::cin >> first;
    std::cout << "Enter middle name: ";
    std::cin >> middle;
    std::cout << "Enter street address: ";
    std::cin >> street;
    std::cout << "Enter state: ";
    std::cin >> state;
    std::cout << "Enter zip: ";
    std::cin >> zip;
    std::cout << "Enter phone: ";
    std::cin >> phone;

    Contact newContact(last, first, middle, street, state, zip, phone);
    contacts.push_back(newContact);
}

void ContactManager::showContacts() const {
    for (const auto& contact : contacts) {
        contact.showContact();
        std::cout << std::endl;
    }
}

void ContactManager::saveContacts(std::ostream& out) const {
    for (const auto& contact : contacts) {
        out << contact.getLastName() << " "
            << contact.getFirstName() << " "
            << contact.getMiddleName() << " "
            << contact.getStreetAddress() << " "
            << contact.getState() << " "
            << contact.getZip() << " "
            << contact.getPhone() << std::endl;
    }
}

void ContactManager::loadContacts(std::istream& in) {
    std::string last, first, middle, street, state, zip, phone;
    while (in >> last >> first >> middle >> street >> state >> zip >> phone) {
        Contact newContact(last, first, middle, street, state, zip, phone);
        contacts.push_back(newContact);
    }
}
