#include "Contact.h"
#include <iostream>

Contact::Contact() : name(), address(), phone("") {}

Contact::Contact(const std::string& last, const std::string& first, const std::string& middle,
        const std::string& street, const std::string& st, const std::string& z,
        const std::string& ph)
    : name(last, first, middle), address(street, st, z), phone(ph) {}

Contact::Contact(const Contact& other)
    : name(other.name), address(other.address), phone(other.phone) {}

void Contact::setName(const std::string& last, const std::string& first, const std::string& middle) {
    name.setLastName(last);
    name.setFirstName(first);
    name.setMiddleName(middle);
}

void Contact::setAddress(const std::string& street, const std::string& st, const std::string& z) {
    address.setStreetAddress(street);
    address.setState(st);
    address.setZip(z);
}

void Contact::setPhone(const std::string& ph) {
    phone = ph;
}

std::string Contact::getLastName() const {
    return name.getLastName();
}

std::string Contact::getFirstName() const {
    return name.getFirstName();
}

std::string Contact::getMiddleName() const {
    return name.getMiddleName();
}

std::string Contact::getStreetAddress() const {
    return address.getStreetAddress();
}

std::string Contact::getState() const {
    return address.getState();
}

std::string Contact::getZip() const {
    return address.getZip();
}

std::string Contact::getPhone() const {
    return phone;
}

void Contact::showContact() const {
    std::cout << "Name: ";
    name.showName();
    std::cout << "Address: ";
    address.showAddress();
    std::cout << "Phone: " << phone << std::endl;
}
std::ostream& operator<<(std::ostream& out, const Contact& contact) {
    out << contact.name;
    out << contact.address;
    out << contact.phone << std::endl;
    return out;
}

std::istream& operator>>(std::istream& in, Contact& contact) {
    in >> contact.name;
    in >> contact.address;
    std::getline(in, contact.phone);
    return in;
}