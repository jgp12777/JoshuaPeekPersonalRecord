#ifndef ADDRESS_H
#define ADDRESS_H

#include <string>

class Address {
private:
    std::string streetAddress;
    std::string state;
    std::string zip;

public:
    Address();
    Address(const std::string& street, const std::string& st, const std::string& z);
    Address(const Address& other);

    void setStreetAddress(const std::string& street);
    void setState(const std::string& st);
    void setZip(const std::string& z);

    std::string getStreetAddress() const;
    std::string getState() const;
    std::string getZip() const;

    void showAddress() const;
    friend std::ostream& operator<<(std::ostream& out, const Address& address);
    friend std::istream& operator>>(std::istream& in, Address& address);
};

#endif // ADDRESS_H
