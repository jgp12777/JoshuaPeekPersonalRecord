#ifndef NAME_H
#define NAME_H

#include <string>

class Name {
private:
    std::string last_name;
    std::string first_name;
    std::string middle_name;

public:
    Name();
    Name(const std::string& last, const std::string& first, const std::string& middle);
    Name(const Name& other);

    void setLastName(const std::string& last);
    void setFirstName(const std::string& first);
    void setMiddleName(const std::string& middle);

    std::string getLastName() const;
    std::string getFirstName() const;
    std::string getMiddleName() const;

    void showName() const;
    friend std::ostream& operator<<(std::ostream& out, const Name& name);
    friend std::istream& operator>>(std::istream& in, Name& name); 
};

#endif // NAME_H
