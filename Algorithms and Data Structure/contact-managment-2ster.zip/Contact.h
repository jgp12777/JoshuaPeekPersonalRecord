#ifndef CONTACT_H
#define CONTACT_H

#include "Name.h"
#include "Address.h"
#include <string>

class Contact {
private:
    Name name;
    Address address;
    std::string phone;

public:
    Contact();
    Contact(const std::string& last, const std::string& first, const std::string& middle,
            const std::string& street, const std::string& st, const std::string& z,
            const std::string& ph);
    Contact(const Contact& other);

    void setName(const std::string& last, const std::string& first, const std::string& middle);
    void setAddress(const std::string& street, const std::string& st, const std::string& z);
    void setPhone(const std::string& ph);

    std::string getLastName() const;
    std::string
    getFirstName() const;
    std::string getMiddleName() const;
    std::string getStreetAddress() const;
    std::string getState() const;
    std::string getZip() const;
    std::string getPhone() const;

    void showContact() const;
    friend std::ostream& operator<<(std::ostream& out, const Contact& contact);
    friend std::istream& operator>>(std::istream& in, Contact& contact);
};

#endif // CONTACT_H
