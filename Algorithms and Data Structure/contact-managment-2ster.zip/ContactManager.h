#ifndef CONTACTMANAGER_H
#define CONTACTMANAGER_H

#include "Contact.h"
#include <vector>
#include <string>
#include <iostream>

class ContactManager {
private:
    std::vector<Contact> contacts;

public:
    ContactManager();

    Contact getContact(int index) const;
    std::vector<Contact> getContacts(std::string last_name) const;
    void addContact();
    void showContacts() const;
    void saveContacts(std::ostream& out) const;
    void loadContacts(std::istream& in);
};

#endif // CONTACTMANAGER_H
