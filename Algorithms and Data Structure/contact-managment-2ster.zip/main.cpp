#include <iostream>
#include "ContactManager.h"

int main() {
    ContactManager contactManager;

    std::cout << "Welcome to the Contact Management System!" << std::endl;

    int choice;
    do {
        std::cout << "\nMenu:\n";
        std::cout << "1. Add Contact\n";
        std::cout << "2. Show Contacts\n";
        std::cout << "3. Save Contacts\n";
        std::cout << "4. Load Contacts\n";
        std::cout << "5. Exit\n";
        std::cout << "Enter your choice: ";
        std::cin >> choice;

        switch (choice) {
            case 1:
                contactManager.addContact();
                break;
            case 2:
                contactManager.showContacts();
                break;
            case 3:
                contactManager.saveContacts(std::cout);
                break;
            case 4:
                contactManager.loadContacts(std::cin);
                break;
            case 5:
                std::cout << "Exiting program.\n";
                break;
            default:
                std::cout << "Invalid choice. Please try again.\n";
                break;
        }
    } while (choice != 5);

    return 0;
}