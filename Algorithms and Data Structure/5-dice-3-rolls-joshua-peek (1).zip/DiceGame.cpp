//Joshua Peek
#include <iostream>
#include <cstdlib>
#include <ctime>
#include "Die.h"

 using namespace std;

 
void
showDice (Die dice[], int size)
{
  
for (int i = 0; i < size; ++i)
	{
	  
cout << " ------- ";
	
} 
cout << endl;
  
for (int i = 0; i < size; ++i)
	{
	  
cout << "|     " << "| ";
	
} 
cout << endl;
  
for (int i = 0; i < size; ++i)
	{
	  
cout << "|  " << dice[i].getValue () << "  | ";
	
} 
cout << endl;
  
for (int i = 0; i < size; ++i)
	{
	  
cout << "|_____" << "| ";
	
} 
cout << endl;

} 
 
int

getTotalScore (Die dice[], int size)
{
  
int total = 0;
  
for (int i = 0; i < size; ++i)
	{
	  
total += dice[i].getValue ();
	
} 
return total;

}


 
int
main ()
{
  
srand (time (0));			// Seed the random number generator
  
const int numDice = 5;
  
Die dice[numDice];
  
 
	// Roll each die in the array
	for (int i = 0; i < numDice; ++i)
	{
	  
dice[i].roll ();
	
} 
 
	// Show the initial dice values
	showDice (dice, numDice);
  
 
	// Get total score
	cout << "Total Score: " << getTotalScore (dice, numDice) << endl;
  
 
	// Allow user to re-roll three times
	for (int i = 0; i < 3; ++i)
	{
	  
char choice;
	  
cout << "Do you want to re-roll the dice? (y/n): ";
	  
cin >> choice;
	  
 
if (choice == 'y' || choice == 'Y')
		{
		  
			// Re-roll the dice
			for (int j = 0; j < numDice; ++j)
			{
			  
dice[j].roll ();
			
} 
 
			// Show the new dice values
			showDice (dice, numDice);
		  
 
			// Get total score
			cout << "Total Score: " << getTotalScore (dice, numDice) << endl;
		
}
	  else
		{
		  
cout << "No re-roll. Exiting..." << endl;
		  
break;
		
}
	
}
  
 
return 0;

}


