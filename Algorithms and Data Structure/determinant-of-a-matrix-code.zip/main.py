def determinant(matrix):
  """
  This function calculates the determinant of a square matrix using recursion.

  Args:
      matrix: A list of lists representing the square matrix.

  Returns:
      The determinant of the matrix.
  """
  # Base case: 1x1 matrix
  if len(matrix) == 1: #len returns number of items in an object
    return matrix[0][0]

  # Recursive case: Larger matrices
  n = len(matrix)
  determinant_sum = 0
  for col in range(n):
    # Get the minor matrix by excluding the first row and current column
    minor = [row[:col] + row[col+1:] for row in matrix[1:]]

    # Calculate the cofactor
    cofactor = determinant(minor) * (-1) ** (1 + col)

    # Add the product of element and cofactor to the sum
    determinant_sum += matrix[0][col] * cofactor

  return determinant_sum

# Example usage
matrix = [[1, 2, 3], [4, 5, 6], [7, 1, 9]]
det = determinant(matrix)
print("Determinant of the matrix:", det)