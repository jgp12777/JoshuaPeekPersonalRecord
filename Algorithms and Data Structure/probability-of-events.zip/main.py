# Joshua Peek 21081733
import random

def generate_random_numbers():
    return random.randint(1, 6), random.randint(1, 6) #https://www.w3schools.com/python/ref_random_randint.asp

def calculate_probabilities(num_experiments):
    same_value_count = 0
    sum_equals_seven_count = 0

    for _ in range(num_experiments):
        first_num, second_num = generate_random_numbers()
        
        if first_num == second_num:
            same_value_count += 1
        
        if first_num + second_num == 7:
            sum_equals_seven_count += 1
    
    prob_same_value = same_value_count / num_experiments
    prob_sum_equals_seven = sum_equals_seven_count / num_experiments

    return prob_same_value, prob_sum_equals_seven

# Run the experiment 1000 times
num_experiments = 1000
prob_same_value, prob_sum_equals_seven = calculate_probabilities(num_experiments)

print(f"Number of events where the random numbers have the same value: {prob_same_value * num_experiments}")
print(f"Probability of same value: {prob_same_value:.4f}")
print(f"Number of events where the sum of random numbers equals 7: {prob_sum_equals_seven * num_experiments}")
print(f"Probability of sum equals 7: {prob_sum_equals_seven:.4f}")

