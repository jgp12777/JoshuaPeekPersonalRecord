#ifndef CHICKEN_H
#define CHICKEN_H

#include "Animal.h"

class Chicken : public Animal {
public:
    Chicken(const std::string& name, int weight);
    virtual ~Chicken();

    void eat() override;
    void gainWeight() override;
    void speak() const override;
    int getTopWeight() const override;
    std::string getType() const override;
};

#endif // CHICKEN_H
