#include "Cow.h"
#include <iostream>

Cow::Cow(const std::string& name, int weight) : Animal(name, weight) {}

Cow::~Cow() {}

void Cow::eat() {
    std::cout << getName() << " is grazing." << std::endl;
    weight += 10; // Cow gains 10 pounds per eat
}

void Cow::gainWeight() {
    weight += 10; // Cow gains 10 pounds per eat
}

void Cow::speak() const {
    std::cout << "Moo" << std::endl;
}

int Cow::getTopWeight() const {
    return 1350;
}
std::string Cow::getType() const {
    return "Cow";
}
