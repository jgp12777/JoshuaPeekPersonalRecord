#ifndef ANIMAL_H
#define ANIMAL_H

#include <string>

class Animal {
protected:
    std::string name;
    int weight;

public:
    Animal(const std::string& name, int weight);
    virtual ~Animal();

    virtual void eat() = 0;
    virtual void gainWeight() = 0;
    virtual void speak() const = 0;
    virtual int getTopWeight() const = 0;
    virtual std::string getType() const = 0;

    std::string getName() const;
    int getWeight() const;
    void setName(const std::string& name);
    void setWeight(int weight);
};

#endif // ANIMAL_H
