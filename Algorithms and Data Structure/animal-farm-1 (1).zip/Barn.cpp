#include "Barn.h"
#include "Pig.h"
#include "Cow.h"
#include "Chicken.h"
#include <iostream>

Barn::Barn() {
    // Populate the Animal array with new objects
    for (int i = 0; i < 5; ++i) {
        animals[i] = new Pig("Barnum", 200); // Initial weight for pigs set to 200
    }
    for (int i = 5; i < 10; ++i) {
        animals[i] = new Cow("Rosy", 1000); // Initial weight for cows set to 1000
    }
    for (int i = 10; i < 15; ++i) {
        animals[i] = new Chicken("Prissy", 12); // Initial weight for chickens set to 12
    }
}
void Barn::showAll() const {
    std::cout << "Animals in the barn:" << std::endl;
    for (Animal* animal : animals) {
        std::cout << animal->getName() << " - Weight: " << animal->getWeight() << std::endl;
    }
}

void Barn::feedAnimals() {
    for (Animal* animal : animals) {
        animal->eat();
    }
}

void Barn::outToPasture() {
    for (Animal* animal : animals) {
        if (animal->getWeight() >= animal->getTopWeight()) {
            std::cout << animal->getName() << " the " << animal->getType() << " was replaced with a sister." << std::endl;
            delete animal; // Remove animal from memory
            // Replace with a new animal of the same species
            if (animal->getType() == "Pig") {
                animal = new Pig("Big Chuck", 225);
            } else if (animal->getType() == "Cow") {
                animal = new Cow("Evil Betty", 8);
            } else if (animal->getType() == "Chicken") {
                animal = new Chicken("Prissy", 12);
            }
        }
    }
}

void Barn::addPig(Pig* pig) {
    animals[0] = pig;
}

void Barn::addCow(Cow* cow) {
    animals[1] = cow;
}

void Barn::addChicken(Chicken* chicken) {
    animals[2] = chicken;
}

void Barn::feedPigs() {
    std::cout << "Feeding pigs:" << std::endl;
    for (int i = 0; i < 5; ++i) {
        animals[i]->eat();
        std::cout << animals[i]->getName() << " gained " << animals[i]->getWeight() - 200 << " pounds." << std::endl;
    }
}

void Barn::feedCows() {
    std::cout << "Feeding cows:" << std::endl;
    for (int i = 5; i < 10; ++i) {
        animals[i]->eat();
        std::cout << animals[i]->getName() << " gained " << animals[i]->getWeight() - 1000 << " pounds." << std::endl;
    }
}

void Barn::feedChickens() {
    std::cout << "Feeding chickens:" << std::endl;
    for (int i = 10; i < 15; ++i) {
        animals[i]->eat();
        std::cout << animals[i]->getName() << " gained " << animals[i]->getWeight() - 12 << " pounds." << std::endl;
    }
}

Barn::~Barn() {
    // Clean up memory allocated to animals
    for (Animal* animal : animals) {
        delete animal;
    }
}
