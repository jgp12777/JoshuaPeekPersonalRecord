#include "Animal.h"

Animal::Animal(const std::string& name, int weight) : name(name), weight(weight) {}

Animal::~Animal() {}

std::string Animal::getName() const {
    return name;
}

int Animal::getWeight() const {
    return weight;
}

void Animal::setName(const std::string& name) {
    this->name = name;
}

void Animal::setWeight(int weight) {
    this->weight = weight;
}
