#include "Barn.h"
#include <iostream>

int main() {
    Barn barn;
    barn.showAll();
    std::cout << "Feeding all the animals..." << std::endl;
    barn.feedAnimals();
    std::cout << std::endl;
    std::cout << "After feeding and checking, here are the animals in the barn:" << std::endl;
    barn.showAll(); // Display all animals and their weights
    std::cout << "Putting animals out to pasture..." << std::endl;
    barn.outToPasture();
    std::cout << std::endl;

    

    return 0;
}
