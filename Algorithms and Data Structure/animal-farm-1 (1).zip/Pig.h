#ifndef PIG_H
#define PIG_H

#include "Animal.h"

class Pig : public Animal {
public:
    Pig(const std::string& name, int weight);
    virtual ~Pig();

    void eat() override;
    void gainWeight() override;
    void speak() const override;
    int getTopWeight() const override;
    std::string getType() const override;
};

#endif // PIG_H
