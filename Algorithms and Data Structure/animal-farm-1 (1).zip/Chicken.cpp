#include "Chicken.h"
#include <iostream>

Chicken::Chicken(const std::string& name, int weight) : Animal(name, weight) {}

Chicken::~Chicken() {}

void Chicken::eat() {
    std::cout << getName() << " is pecking." << std::endl;
    weight += 1; // Chicken gains 1 pound per eat
}

void Chicken::gainWeight() {
    weight += 1; // Chicken gains 1 pound per eat
}

void Chicken::speak() const {
    std::cout << "Cluck" << std::endl;
}

int Chicken::getTopWeight() const {
    return 12;
}
std::string Chicken::getType() const {
    return "Chicken";
}