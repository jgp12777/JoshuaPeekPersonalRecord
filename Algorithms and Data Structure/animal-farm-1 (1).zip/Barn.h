#ifndef BARN_H
#define BARN_H

#include "Pig.h"
#include "Cow.h"
#include "Chicken.h"

class Barn {
private:
    Animal* animals[15];

public:
    Barn();
    void feedAnimals();
    void outToPasture();
    ~Barn();
    void addPig(Pig* pig);
    void addCow(Cow* cow);
    void addChicken(Chicken* chicken);
    void feedPigs();
    void feedCows();
    void feedChickens();
    void showAll() const; // Declaration of showAll method
};
#endif