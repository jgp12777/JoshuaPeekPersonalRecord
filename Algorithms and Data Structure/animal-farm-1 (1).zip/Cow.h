#ifndef COW_H
#define COW_H

#include "Animal.h"

class Cow : public Animal {
public:
    Cow(const std::string& name, int weight);
    virtual ~Cow();

    void eat() override;
    void gainWeight() override;
    void speak() const override;
    int getTopWeight() const override;
    std::string getType() const override;
};

#endif // COW_H
