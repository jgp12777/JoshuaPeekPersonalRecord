#include "Pig.h"
#include <iostream>

Pig::Pig(const std::string& name, int weight) : Animal(name, weight) {}

Pig::~Pig() {}

void Pig::eat() {
    std::cout << getName() << " is munching." << std::endl;
    weight += 5; // Pig gains 5 pounds per eat
}

void Pig::gainWeight() {
    weight += 5; // Pig gains 5 pounds per eat
}

void Pig::speak() const {
    std::cout << "Oink" << std::endl;
}

int Pig::getTopWeight() const {
    return 280;
}
std::string Pig::getType() const {
    return "Pig";
}
