using System;
using System.Collections.Generic;

public class AnagramChecker
{
    public static bool IsAnagram(string word1, string word2)
    {
        // Check if lengths are different, return false if they are
        if (word1.Length != word2.Length)
            return false;

        // Create two stacks to store characters from both words
        Stack<char> stack1 = new Stack<char>();
        Stack<char> stack2 = new Stack<char>();

        // Push all characters from word1 into stack1
        foreach (char c in word1)
        {
            stack1.Push(c);
        }

        // Push all characters from word2 into stack2
        foreach (char c in word2)
        {
            stack2.Push(c);
        }

        // Now compare both stacks character by character
        while (stack1.Count > 0 && stack2.Count > 0)
        {
            char char1 = stack1.Pop();
            char char2 = stack2.Pop();

            // If the characters don't match, it's not an anagram
            if (char1 != char2)
                return false;
        }

        // If all characters matched, it's an anagram
        return true;
    }

    public static void Main(string[] args)
    {
        string? word1 = null;
        string? word2 = null;

        // Input validation loop for word1
        while (string.IsNullOrWhiteSpace(word1))
        {
            Console.Write("Enter the first word: ");
            word1 = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(word1))
            {
                Console.WriteLine("Input cannot be null or empty. Please try again.");
            }
        }

        // Input validation loop for word2
        while (string.IsNullOrWhiteSpace(word2))
        {
            Console.Write("Enter the second word: ");
            word2 = Console.ReadLine();

            if (string.IsNullOrWhiteSpace(word2))
            {
                Console.WriteLine("Input cannot be null or empty. Please try again.");
            }
        }

        // Check if they are anagrams
        bool result = IsAnagram(word1, word2);

        // Output the result
        Console.WriteLine(result ? "The words are anagrams." : "The words are not anagrams.");

        // Keep the console open after execution
        Console.WriteLine("Press any key to exit.");
        Console.ReadKey();
    }
}
