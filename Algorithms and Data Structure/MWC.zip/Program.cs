﻿using System;
using System.Collections.Generic;

namespace GraphAlgorithms
{
    class Program
    {
        // Joshua Peek 21081733 cst 201 
        static void Main(string[] args)
        {
            // Define the number of vertices
            int vertices = 4;
            int INFINITY = int.MaxValue;
            int[,] graph = {
                { 0, 3, INFINITY, INFINITY, 1 },
                { INFINITY, 0, 6, INFINITY, 3 },
                { 1, INFINITY, 0, INFINITY, INFINITY },
                { -4, INFINITY, 5, 0, INFINITY },
                { INFINITY, INFINITY, 2, 2, 0}
            };

            // Find and print all minimum weight cycles
            FindAllMinimumWeightCycles(graph, vertices);
        }

        // Function to find and print all minimum weight cycles in a graph
        static void FindAllMinimumWeightCycles(int[,] graph, int vertices)
        {
            // List to store all cycles
            List<Tuple<List<int>, int>> cycles = new List<Tuple<List<int>, int>>();

            // Counter for the number of comparisons
            int comparisonCount = 0;

            // Loop through each node to use as a starting point
            for (int start = 0; start < vertices; start++)
            {
                // Array to track visited nodes
                bool[] visited = new bool[vertices];
                List<int> path = new List<int>();

                // Start a Depth-First Search (DFS) from the starting node
                DFS(graph, start, start, vertices, visited, path, cycles, ref comparisonCount);
            }

            // Output all cycles with their weights
            Console.WriteLine("Cycles found:");
            foreach (var cycle in cycles)
            {
                Console.Write("Cycle: ");
                foreach (int node in cycle.Item1)
                {
                    Console.Write(node + " ");
                }
                Console.WriteLine($"Weight: {cycle.Item2}");
            }

            // Output the number of comparisons
            Console.WriteLine($"Total number of comparisons: {comparisonCount}");
        }

        // Depth-First Search function to detect cycles and calculate their weights
        static void DFS(int[,] graph, int start, int current, int vertices, bool[] visited, List<int> path, List<Tuple<List<int>, int>> cycles, ref int comparisonCount)
        {
            // Mark the current node as visited and add it to the path
            visited[current] = true;
            path.Add(current);

            // Iterate through all possible next nodes
            for (int next = 0; next < vertices; next++)
            {
                // Increment the comparison counter
                comparisonCount++;

                // Skip if there's no edge or it's a self-loop
                if (graph[current, next] == 0 || current == next) continue;

                // If we find the start node and the path length is greater than 2, we found a cycle
                if (next == start && path.Count > 2)
                {
                    // Calculate the weight of the cycle
                    int weight = 0;
                    for (int i = 0; i < path.Count - 1; i++)
                    {
                        weight += graph[path[i], path[i + 1]];
                    }
                    weight += graph[path[path.Count - 1], start];

                    // Add the found cycle to the list
                    cycles.Add(new Tuple<List<int>, int>(new List<int>(path), weight));
                }
                // If the next node hasn't been visited yet, continue DFS
                else if (!visited[next])
                {
                    DFS(graph, start, next, vertices, visited, path, cycles, ref comparisonCount);
                }
            }

            // Backtrack: unmark the current node as visited and remove it from the path
            visited[current] = false;
            path.RemoveAt(path.Count - 1);
        }
    }
}

/*
Explanation:
1. The graph is represented as an adjacency matrix, with negative weights allowed.
2. A Depth-First Search (DFS) algorithm is used to explore all possible paths from each vertex.
3. The function tracks visited nodes to prevent edge reuse in the same cycle.
4. When a cycle is detected (returning to the starting point), it calculates the weight of the cycle.
5. All found cycles and their respective weights are printed.
6. The number of comparisons made during the execution of the algorithm is also counted and displayed.

Complexity Analysis:
- Time Complexity: The time complexity of this algorithm is O(V * (V + E)!), where V is the number of vertices and E is the number of edges. 
    This is because the DFS explores all possible paths, which can lead to a large number of comparisons in the worst case, 
    especially for graphs with multiple edges and cycles.
- Space Complexity: The space complexity is O(V), which is required for storing the visited nodes and path information.
- Number of Comparisons: In each DFS call, we iterate over all possible vertices (O(V)), and for each recursive call, 
    we potentially explore all edges connected to the current vertex.
- Data Exchanges: The primary data exchanges occur during the backtracking phase, where nodes are added to and removed from the path list. 
    The number of exchanges depends on the depth of the recursion and the number of cycles found.
*/
