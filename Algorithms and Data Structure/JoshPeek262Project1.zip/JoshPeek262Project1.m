% Joshua Peek
% 21081733
format compact 
a = 3;
b = 3;
c = 7;
d = 13;

P1B = (a+b)*log(abs(c-15))+sin(log10(factorial(b)))-(b-c)*tan(a/(d+1))
P1C = 0 % do later
P1D = 0 %do later 

M1 = [ a+1 b ; c d+1];
M2 = [ -a 2*b+1 -3*c ; a+b c-d a+c];
M3 = [ a^2 -a^2 ; -b^2 b^2 ; c^2 -c^2];
M4 = [ a*b 0 c*d ; -1 b*c 1 ; a*c 0 a*d];

P2B = 8*M1*M2 - 4*M2
P2C = -3*M4^2 + 7*M3*M2
P2D = (5*M2*M3).*(M1^3)
P2E = (6*M4*M3).*(M3.^2)

% 4x + 4y = -9
% 8x + 14y = -4 

P3AM = [a+1 b+1 -9 ; c+1 d+1 -4 ]
P3A = rref(P3AM)

P3BM = [ a+1 b+1 ; c+1 d+1 ]
P3BV = [-9 ; -4 ]
P3B = inv(P3BM)* P3BV

P3C1 = [ a+1 ; b+1 ] 
P3C2 = [ c+1 ; d+1 ] 
P3C = P3C1 * (P3C2)' 

P3DM = [ a+2 b+2 ; c+2 d+2 ]
syms z 
P3D = solve(z^2 - (trace(P3DM))*z+det(P3DM)==0,z)

P3EM = [a+2 a+b ; c+2 d+2]
P3E = eig(P3EM)