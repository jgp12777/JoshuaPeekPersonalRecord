class TrashCan {
    constructor(height = 2, baseRadius = 0.5, topRadius = 0.75, segments = 16, alias = 'trash-can') {
        this.alias = alias;
        this.height = height;
        this.baseRadius = baseRadius;
        this.topRadius = topRadius;
        this.segments = segments;
        this.vertices = [];
        this.indices = [];
        this.normals = [];

        this.wireframe = false;
        this.diffuse = [0.3, 0.3, 0.3, 1.0]; // Dark gray color for a trash can

        this.build();
    }

    build() {
        const step = 2 * Math.PI / this.segments;

        // Generate vertices for the base and top circles
        for (let i = 0; i <= this.segments; i++) {
            const theta = i * step;
            const xBase = this.baseRadius * Math.cos(theta);
            const zBase = this.baseRadius * Math.sin(theta);
            const xTop = this.topRadius * Math.cos(theta);
            const zTop = this.topRadius * Math.sin(theta);

            // Base ring
            this.vertices.push(xBase, 0, zBase);
            // Top ring (open top)
            this.vertices.push(xTop, this.height, zTop);
        }

        // Generate side faces
        for (let i = 0; i < this.segments; i++) {
            const baseIndex1 = i * 2;
            const baseIndex2 = ((i + 1) % this.segments) * 2;
            const topIndex1 = i * 2 + 1;
            const topIndex2 = ((i + 1) % this.segments) * 2 + 1;

            // Two triangles per segment
            this.indices.push(baseIndex1, topIndex1, baseIndex2);
            this.indices.push(baseIndex2, topIndex1, topIndex2);

            // Calculate normals (approximate for conical shape)
            const dx1 = this.vertices[topIndex1 * 3] - this.vertices[baseIndex1 * 3];
            const dy1 = this.height;
            const dz1 = this.vertices[topIndex1 * 3 + 2] - this.vertices[baseIndex1 * 3 + 2];
            const length1 = Math.sqrt(dx1 * dx1 + dy1 * dy1 + dz1 * dz1);
            const nx1 = dx1 / length1;
            const ny1 = dy1 / length1;
            const nz1 = dz1 / length1;

            this.normals.push(nx1, ny1, nz1);
            this.normals.push(nx1, ny1, nz1);
            this.normals.push(nx1, ny1, nz1);
            this.normals.push(nx1, ny1, nz1);
            this.normals.push(nx1, ny1, nz1);
            this.normals.push(nx1, ny1, nz1);
        }
    }
}