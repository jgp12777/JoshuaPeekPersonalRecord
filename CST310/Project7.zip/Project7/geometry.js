/**
 * Enhanced Geometry Module for Alien City L-System
 * Provides architectural primitives with alien aesthetics
 */

class Geometry {
    /**
     * Creates a glowing cube module (living spaces/offices)
     * @param {number} size - Size of the cube
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Cube mesh with emissive material
     */
    static createCube(size, color) {
        const geometry = new THREE.BoxGeometry(size, size, size);
        const material = new THREE.MeshPhongMaterial({
            color,
            transparent: true,
            opacity: 0.9,
            emissive: new THREE.Color(color).multiplyScalar(0.1),
            shininess: 30
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a pyramid spire (communication/ceremonial towers)
     * @param {number} size - Size of the pyramid
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Pyramid mesh with emissive material
     */
    static createPyramid(size, color) {
        const geometry = new THREE.TetrahedronGeometry(size);
        const material = new THREE.MeshPhongMaterial({
            color,
            transparent: true,
            opacity: 0.8,
            emissive: new THREE.Color(color).multiplyScalar(0.15),
            shininess: 50
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a translucent window panel
     * @param {number} size - Size of the window
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Window mesh with high transparency
     */
    static createWindow(size, color) {
        const geometry = new THREE.PlaneGeometry(size * 0.8, size * 0.8);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0x00ffff,
            transparent: true,
            opacity: 0.6,
            emissive: new THREE.Color(color || 0x00ffff).multiplyScalar(0.3),
            side: THREE.DoubleSide
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a communication antenna
     * @param {number} length - Length of the antenna
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Antenna mesh with emissive tip
     */
    static createAntenna(length, color) {
        const geometry = new THREE.CylinderGeometry(0.02, 0.02, length, 8);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0xff6600,
            emissive: new THREE.Color(color || 0xff6600).multiplyScalar(0.2),
            shininess: 100
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a solar panel for energy collection
     * @param {number} size - Size of the panel
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Solar panel mesh with metallic appearance
     */
    static createSolarPanel(size, color) {
        const geometry = new THREE.PlaneGeometry(size * 1.5, size * 0.8);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0x000080,
            transparent: true,
            opacity: 0.7,
            emissive: new THREE.Color(color || 0x000080).multiplyScalar(0.1),
            shininess: 80,
            side: THREE.DoubleSide
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a dome structure (gathering spaces/protection)
     * @param {number} radius - Radius of the dome
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Dome mesh (hemisphere)
     */
    static createDome(radius, color) {
        const geometry = new THREE.SphereGeometry(
            radius,
            16,
            8,
            0,
            Math.PI * 2,
            0,
            Math.PI / 2
        );
        const material = new THREE.MeshPhongMaterial({
            color,
            transparent: true,
            opacity: 0.8,
            emissive: new THREE.Color(color).multiplyScalar(0.1),
            shininess: 40
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a crystalline structure (decorative/energy focusing)
     * @param {number} size - Size of the crystal
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Crystal mesh with high reflectivity
     */
    static createCrystal(size, color) {
        const geometry = new THREE.OctahedronGeometry(size);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0x9966ff,
            transparent: true,
            opacity: 0.7,
            emissive: new THREE.Color(color || 0x9966ff).multiplyScalar(0.2),
            shininess: 100
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates a bridge connector between buildings
     * @param {THREE.Vector3} start - Start position
     * @param {THREE.Vector3} end - End position
     * @param {number} thickness - Bridge thickness
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Bridge mesh
     */
    static createBridge(start, end, thickness, color) {
        const length = start.distanceTo(end);
        const geometry = new THREE.BoxGeometry(thickness, thickness * 0.5, length);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0x666666,
            emissive: new THREE.Color(color || 0x666666).multiplyScalar(0.05),
            shininess: 20
        });

        const bridge = new THREE.Mesh(geometry, material);
        const midPoint = start.clone().lerp(end, 0.5);
        bridge.position.copy(midPoint);

        // Orient bridge between points
        const direction = end.clone().sub(start).normalize();
        bridge.lookAt(bridge.position.clone().add(direction));

        return bridge;
    }

    /**
     * Creates a floating platform
     * @param {number} radius - Platform radius
     * @param {number} thickness - Platform thickness
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Platform mesh
     */
    static createPlatform(radius, thickness, color) {
        const geometry = new THREE.CylinderGeometry(radius, radius, thickness, 16);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0x444444,
            emissive: new THREE.Color(color || 0x444444).multiplyScalar(0.1),
            shininess: 30
        });
        return new THREE.Mesh(geometry, material);
    }

    /**
     * Creates an energy orb (power source visualization)
     * @param {number} radius - Orb radius
     * @param {number} color - Color value (hex)
     * @returns {THREE.Mesh} Energy orb mesh
     */
    static createEnergyOrb(radius, color) {
        const geometry = new THREE.SphereGeometry(radius, 16, 16);
        const material = new THREE.MeshPhongMaterial({
            color: color || 0xffff00,
            transparent: true,
            opacity: 0.6,
            emissive: new THREE.Color(color || 0xffff00).multiplyScalar(0.4),
            shininess: 100
        });
        return new THREE.Mesh(geometry, material);
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Geometry;
}