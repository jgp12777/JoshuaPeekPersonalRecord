# Design Rationale

The alien city adopts a **crystalline aesthetic**, inspired by geometric, faceted structures that evoke a sense of otherworldly precision and beauty, like quartz or amethyst formations. The design emphasizes:

- **Recursive Modularity**: Buildings grow vertically with branching "wings" or mirrored segments, mimicking crystal lattice structures. The B symbol drives recursive growth, spawning smaller components (C for windows, P for spires).
- **Symmetry**: The | symbol introduces mirroring, creating symmetrical towers or arches, enhancing the crystalline feel.
- **Color Palette**: Cyan (0x00CED1) for main structures, bright cyan (0x00FFFF) for windows, and blue (0x1E90FF) for spires, creating a glowing, futuristic look against a dark slate ground (0x2F4F4F) and pale sky (0x87CEEB).
- **Spatial Layout**: A grid with randomized offsets ensures a structured yet organic cityscape, avoiding rigid uniformity.
- **Visual Language**: Repetition of cubes and pyramids, combined with polycylinder frameworks, suggests a culture that values geometric perfection and hierarchical growth, like a crystalline civilization.