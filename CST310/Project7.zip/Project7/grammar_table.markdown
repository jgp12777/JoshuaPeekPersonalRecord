# Grammar Table

| Symbol | Meaning | Expansion |
|--------|---------|-----------|
| B | Building base | Generates main structure with branches or mirrored components |
| F | Forward structure | Draws a polycylinder segment, extends building height |
| C | Cube module | Adds a cube representing a window or panel |
| P | Pyramid spire | Adds a pyramid as a spire or decorative element |
| + | Rotate X+ | Rotates structure positively around X-axis |
| - | Rotate X- | Rotates structure negatively around X-axis |
| & | Rotate Y+ | Rotates structure positively around Y-axis |
| ^ | Rotate Y- | Rotates structure negatively around Y-axis |
| \\ | Rotate Z+ | Rotates structure positively around Z-axis |
| / | Rotate Z- | Rotates structure negatively around Z-axis |
| \| | Mirror | Rotates 180 degrees around Z-axis for symmetry |
| [ | Push state | Saves current position and orientation |
| ] | Pop state | Restores last saved position and orientation |