# Alien City L-System

## Overview
This project implements a 3D alien city using an L-System to generate crystalline, recursive buildings. It builds on the Fractal Forest project, adapting the Turtle3D and Polycylinder classes to support cubes and pyramids alongside polycylinders.

## Execution
1. Host `alien_city.html` on a web server or open locally in a browser (ensure internet access for Three.js CDN).
2. The city renders automatically with a flythrough camera animation.
3. Resize the window to adjust the view; the camera orbits the city center.

## Usage
- **View**: Observe the crystalline city with glowing cyan structures, cube windows, and pyramid spires.
- **Interact**: No user input is required; the camera auto-orbits.
- **Modify**: Edit `city_grammar.txt` to change the L-System rules or adjust parameters in `alien_city.html` (e.g., gridSize, spacing, colors).

## Files
- `alien_city.html`: Main file with Three.js scene, L-System, and Turtle3D implementation.
- `city_grammar.txt`: L-System grammar for crystalline buildings.
- `grammar_table.md`: Symbol definitions and meanings.
- `algorithm_flowchart.md`: Logic flow for generation.
- `design_rationale.md`: Aesthetic and design choices.
- `example_expansions.md`: Sample L-System expansions.

## Notes
- Requires Three.js (loaded via CDN).
- Screenshots can be taken using browser tools (e.g., Ctrl+Shift+S in Chrome).
- For custom grammars, ensure rules produce balanced [ and ] to avoid stack errors.