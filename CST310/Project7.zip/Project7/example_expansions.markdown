# Example Expansions

**Iteration 1** (starting from axiom B):
- Rule applied: B -> F[+C][-P][&B][^B]B
- Result: F[+C][-P][&B][^B]B

**Iteration 2**:
- Apply rules to each symbol in F[+C][-P][&B][^B]B:
  - F -> FF[+C]
  - C -> CC
  - P -> P[P]
  - B (in [&B]) -> F[+C][-P][&B][^B]B
  - B (in [^B]) -> F[|B][+C][-P]B
  - B (end) -> F[+C][-P][&B][^B]B
- Result: FF[+C][+CC][-P[P]][&F[+C][-P][&B][^B]B][^F[|B][+C][-P]B]F[+C][-P][&B][^B]B