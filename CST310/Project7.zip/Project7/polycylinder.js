/**
 * Enhanced Polycylinder Module for Alien City L-System
 * Creates connected cylindrical structures with alien aesthetics
 */

class Polycylinder {
    /**
     * Creates a polycylinder structure connecting multiple points
     * @param {THREE.Scene} scene - Three.js scene object
     * @param {Array<THREE.Vector3>} points - Array of 3D points to connect
     * @param {number} radius - Radius of the cylinders (default: 0.05)
     * @param {number} color - Color value (hex, default: 0x00CED1)
     * @param {Object} options - Additional options
     */
    constructor(scene, points, radius = 0.05, color = 0x00CED1, options = {}) {
        this.scene = scene;
        this.points = points;
        this.radius = radius;
        this.color = color;
        this.options = {
            emissiveIntensity: 0.1,
            opacity: 1.0,
            shininess: 30,
            tapered: true,
            segments: 12,
            ...options
        };

        this.meshes = []; // Store created meshes for cleanup
    }

    /**
     * Draws the polycylinder structure
     */
    draw() {
        if (this.points.length < 2) {
            console.warn('Polycylinder needs at least 2 points');
            return;
        }

        // Create spherical joints at each point
        for (let i = 0; i < this.points.length; i++) {
            const joint = this.createJoint(this.points[i], i);
            this.scene.add(joint);
            this.meshes.push(joint);
        }

        // Create cylindrical segments between points
        for (let i = 0; i < this.points.length - 1; i++) {
            const segment = this.createSegment(this.points[i], this.points[i + 1], i);
            this.scene.add(segment);
            this.meshes.push(segment);
        }
    }

    /**
     * Creates a joint sphere at a point
     * @param {THREE.Vector3} point - Position for the joint
     * @param {number} index - Index of the point
     * @returns {THREE.Mesh} Joint sphere mesh
     */
    createJoint(point, index) {
        const jointRadius = this.radius * 1.2;
        const sphereGeometry = new THREE.SphereGeometry(
            jointRadius,
            this.options.segments,
            this.options.segments
        );

        const sphereMaterial = new THREE.MeshPhongMaterial({
            color: this.color,
            emissive: new THREE.Color(this.color).multiplyScalar(this.options.emissiveIntensity),
            shininess: this.options.shininess,
            transparent: this.options.opacity < 1.0,
            opacity: this.options.opacity
        });

        const sphere = new THREE.Mesh(sphereGeometry, sphereMaterial);
        sphere.position.copy(point);
        sphere.userData = { type: 'joint', index: index };

        return sphere;
    }

    /**
     * Creates a cylindrical segment between two points
     * @param {THREE.Vector3} start - Start point
     * @param {THREE.Vector3} end - End point
     * @param {number} index - Index of the segment
     * @returns {THREE.Mesh} Cylinder segment mesh
     */
    createSegment(start, end, index) {
        const length = start.distanceTo(end);
        const direction = end.clone().sub(start).normalize();

        // Calculate radii for tapered effect
        const startRadius = this.options.tapered ? this.radius * (1 - index * 0.05) : this.radius;
        const endRadius = this.options.tapered ? this.radius * (1 - (index + 1) * 0.05) : this.radius;

        const cylinderGeometry = new THREE.CylinderGeometry(
            Math.max(endRadius, 0.01),
            Math.max(startRadius, 0.01),
            length,
            this.options.segments
        );

        const cylinderMaterial = new THREE.MeshPhongMaterial({
            color: this.color,
            emissive: new THREE.Color(this.color).multiplyScalar(this.options.emissiveIntensity),
            shininess: this.options.shininess,
            transparent: this.options.opacity < 1.0,
            opacity: this.options.opacity
        });

        const cylinder = new THREE.Mesh(cylinderGeometry, cylinderMaterial);

        // Position cylinder at midpoint between start and end
        const midPoint = start.clone().lerp(end, 0.5);
        cylinder.position.copy(midPoint);

        // Orient cylinder to point from start to end
        const quaternion = new THREE.Quaternion().setFromUnitVectors(
            new THREE.Vector3(0, 1, 0),
            direction
        );
        cylinder.quaternion.copy(quaternion);

        cylinder.userData = { type: 'segment', index: index };

        return cylinder;
    }

    /**
     * Creates a branching polycylinder structure
     * @param {THREE.Vector3} basePoint - Base point for branching
     * @param {Array<THREE.Vector3>} branchPoints - Points for each branch
     * @param {number} branchRadius - Radius for branch cylinders
     */
    drawBranches(basePoint, branchPoints, branchRadius) {
        const branchColor = new THREE.Color(this.color).multiplyScalar(0.8);

        for (let i = 0; i < branchPoints.length; i++) {
            const branchPolycylinder = new Polycylinder(
                this.scene,
                [basePoint, branchPoints[i]],
                branchRadius || this.radius * 0.7,
                branchColor,
                {
                    ...this.options,
                    emissiveIntensity: this.options.emissiveIntensity * 1.5
                }
            );
            branchPolycylinder.draw();
            this.meshes.push(...branchPolycylinder.meshes);
        }
    }

    /**
     * Animates the polycylinder with pulsing effect
     * @param {number} time - Animation time
     * @param {number} pulseSpeed - Speed of the pulse effect
     */
    animate(time, pulseSpeed = 1.0) {
        const pulseIntensity = 0.5 + 0.5 * Math.sin(time * pulseSpeed);

        this.meshes.forEach(mesh => {
            if (mesh.material && mesh.material.emissive) {
                mesh.material.emissive = new THREE.Color(this.color)
                    .multiplyScalar(this.options.emissiveIntensity * pulseIntensity);
            }
        });
    }

    /**
     * Creates a helical polycylinder structure
     * @param {THREE.Vector3} center - Center point of the helix
     * @param {number} height - Height of the helix
     * @param {number} helixRadius - Radius of the helix
     * @param {number} turns - Number of turns in the helix
     * @param {number} segments - Number of segments in the helix
     */
    static createHelix(scene, center, height, helixRadius, turns, segments, cylinderRadius, color) {
        const points = [];

        for (let i = 0; i <= segments; i++) {
            const t = i / segments;
            const angle = turns * 2 * Math.PI * t;
            const y = height * t;

            const point = new THREE.Vector3(
                center.x + helixRadius * Math.cos(angle),
                center.y + y,
                center.z + helixRadius * Math.sin(angle)
            );

            points.push(point);
        }

        const helix = new Polycylinder(scene, points, cylinderRadius, color, {
            tapered: true,
            emissiveIntensity: 0.15
        });

        helix.draw();
        return helix;
    }

    /**
     * Creates a network of interconnected polycylinders
     * @param {Array<THREE.Vector3>} nodes - Network nodes
     * @param {Array<Array<number>>} connections - Indices of connected nodes
     */
    static createNetwork(scene, nodes, connections, cylinderRadius, color) {
        const networks = [];

        connections.forEach(connection => {
            const points = connection.map(index => nodes[index]);
            const network = new Polycylinder(scene, points, cylinderRadius, color, {
                segments: 8,
                emissiveIntensity: 0.2
            });
            network.draw();
            networks.push(network);
        });

        return networks;
    }

    /**
     * Removes all meshes from the scene
     */
    cleanup() {
        this.meshes.forEach(mesh => {
            this.scene.remove(mesh);
            if (mesh.geometry) mesh.geometry.dispose();
            if (mesh.material) mesh.material.dispose();
        });
        this.meshes = [];
    }

    /**
     * Updates the polycylinder with new points
     * @param {Array<THREE.Vector3>} newPoints - New points to connect
     */
    update(newPoints) {
        this.cleanup();
        this.points = newPoints;
        this.draw();
    }

    /**
     * Gets the total length of the polycylinder
     * @returns {number} Total length
     */
    getLength() {
        let totalLength = 0;
        for (let i = 0; i < this.points.length - 1; i++) {
            totalLength += this.points[i].distanceTo(this.points[i + 1]);
        }
        return totalLength;
    }

    /**
     * Gets a point along the polycylinder at a specific distance
     * @param {number} distance - Distance along the polycylinder
     * @returns {THREE.Vector3} Point at the specified distance
     */
    getPointAtDistance(distance) {
        let currentDistance = 0;

        for (let i = 0; i < this.points.length - 1; i++) {
            const segmentLength = this.points[i].distanceTo(this.points[i + 1]);

            if (currentDistance + segmentLength >= distance) {
                const t = (distance - currentDistance) / segmentLength;
                return this.points[i].clone().lerp(this.points[i + 1], t);
            }

            currentDistance += segmentLength;
        }

        return this.points[this.points.length - 1];
    }
}

// Export for use in other modules
if (typeof module !== 'undefined' && module.exports) {
    module.exports = Polycylinder;
}