# Algorithm Flowchart

1. **Initialize Scene**:
   - Create Three.js scene, camera, renderer.
   - Add directional and ambient lighting.
   - Add sky dome and platform ground.

2. **Parse Grammar**:
   - Read city_grammar.txt.
   - Extract axiom, rules, iterations, angle using GrammarParser.

3. **Generate L-System**:
   - Initialize LSystem with parsed grammar.
   - Run generate() to produce final string after iterations.

4. **Position Buildings**:
   - Create grid-based positions with slight randomization.
   - For each position:
     - Create new LSystem instance.
     - Generate string.
     - Initialize Turtle3D at position.

5. **Draw Buildings**:
   - Turtle3D interprets L-System string:
     - F: Draw polycylinder segment.
     - C: Add cube (window).
     - P: Add pyramid (spire).
     - +, -, &, ^, \, /, |: Apply rotations or mirroring.
     - [, ]: Manage state stack for branching.
   - Update radius and length for recursive scaling.

6. **Render and Animate**:
   - Set camera for flythrough (sinusoidal path).
   - Render scene with continuous rotation.
   - Handle window resizing.