SELECT  books.Title, books.Genre, books.Cost 
FROM books
WHERE books.Genre = 'Poetry'
AND books.Cost > (SELECT AVG(books.Cost) FROM books);

