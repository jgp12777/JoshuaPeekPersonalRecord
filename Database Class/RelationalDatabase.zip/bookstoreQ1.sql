SELECT 
books.Cost, books.BookID, books.Title
From 
books 
ORDER BY
books.Cost