SELECT a.Name, SUM(b.Cost) AS TotalValue
FROM authors a
JOIN author_of_book ab ON a.AuthorID = ab.authors_AuthorID
JOIN books b ON ab.books_BookID = b.BookID
GROUP BY a.Name
ORDER BY TotalValue DESC;
