USE mybookstore;

-- Insert Authors (starting from AuthorID 120)
INSERT INTO authors (AuthorID, Name, Address, PhoneNumber, HomeCountry) VALUES
    (120, 'Alice Walker', '123 Elm St, Suite 100', '(555) 123-4567', 'USA'),
    (121, 'James Baldwin', '456 Oak Rd, Apt 23', '(555) 234-5678', 'USA'),
    (122, 'Emily Bronte', '789 Pine Ave, Flat 5', '(555) 345-6789', 'UK'),
    (123, 'Robert Frost', '101 Maple Blvd, Floor 2', '(555) 456-7890', 'USA'),
    (124, 'Maya Angelou', '202 Birch Ln, House 1', '(555) 567-8901', 'USA'),
    (125, 'T.S. Eliot', '303 Cedar St, Suite 4A', '(555) 678-9012', 'UK'),
    (126, 'Langston Hughes', '404 Willow Ave, Apt B', '(555) 789-0123', 'USA'),
    (127, 'Sylvia Plath', '505 Spruce Dr, Unit 12', '(555) 890-1234', 'USA');

-- Insert Books (starting from BookID 120)
INSERT INTO books (BookID, Title, Genre, Publisher, YearPublished, ISBN, Cost) VALUES
    -- Poetry Genre (5 Books)
    (120, 'Whispers of the Heart', 'Poetry', 'Silverwood Press', '2022-03-15', 123456, 12.99),
    (121, 'Echoes in the Mind', 'Poetry', 'Emberstone Books', '2021-06-10', 123455, 14.99),
    (122, 'The Shining Light', 'Poetry', 'Iron Quill Publishing', '2020-09-20', 123454, 10.50),
    (123, 'Lantern in the Dark', 'Poetry', 'Gilded Inkworks', '2023-02-25', 123453, 16.00),
    (124, 'Songs of the Soul', 'Poetry', 'Sun & Moon Press', '2022-07-30', 123452, 13.50),
    
    -- Novel Genre (5 Books)
    (125, 'Winds of Change', 'Novel', 'Silverwood Press', '2021-05-12', 123451, 20.00),
    (126, 'The Last Embrace', 'Novel', 'Emberstone Books', '2020-03-22', 123450, 18.75),
    (127, 'Silent Shadows', 'Novel', 'Iron Quill Publishing', '2022-11-15', 123449, 22.50),
    (128, 'Forgotten Paths', 'Novel', 'Gilded Inkworks', '2019-08-30', 123448, 19.99),
    (129, 'Threads of Destiny', 'Novel', 'Sun & Moon Press', '2021-10-10', 123447, 21.00),

    -- Drama Genre (5 Books)
    (130, 'The Eternal Flame', 'Drama', 'Silverwood Press', '2022-01-05', 123446, 17.25),
    (131, 'A Cry for Justice', 'Drama', 'Emberstone Books', '2020-07-17', 123445, 18.75),
    (132, 'Breaking Chains', 'Drama', 'Iron Quill Publishing', '2021-12-25', 123444, 16.50),
    (133, 'Hope in the Dark', 'Drama', 'Gilded Inkworks', '2019-04-14', 123443, 15.99),
    (134, 'Crossroads', 'Drama', 'Sun & Moon Press', '2022-09-12', 123442, 19.25);

-- Insert Author-Book Relationships (starting from author_of_bookID 120)
INSERT INTO author_of_book (author_of_bookID, books_BookID, authors_AuthorID) VALUES
    -- Author 120 (Alice Walker) - Multiple Books
    (120, 120, 120),
    (121, 125, 120),
    (122, 130, 120),
    
    -- Author 121 (James Baldwin) - Multiple Books
    (123, 121, 121),
    (124, 126, 121),
    (125, 131, 121),
    
    -- Author 122 (Emily Bronte) - Multiple Books
    (126, 122, 122),
    (127, 127, 122),
    (128, 132, 122),
    
    -- Author 123 (Robert Frost) - Multiple Books
    (129, 123, 123),
    (130, 128, 123),
    (131, 133, 123),
    
    -- Author 124 (Maya Angelou) - Multiple Books
    (132, 124, 124),
    (133, 129, 124),
    (134, 134, 124),
    
    -- Author 125 (T.S. Eliot) - Multiple Books
    (135, 120, 125),
    (136, 131, 125),
    
    -- Author 126 (Langston Hughes) - Multiple Books
    (137, 122, 126),
    (138, 134, 126),
    
    -- Author 127 (Sylvia Plath) - Multiple Books
    (139, 121, 127),
    (140, 126, 127);
