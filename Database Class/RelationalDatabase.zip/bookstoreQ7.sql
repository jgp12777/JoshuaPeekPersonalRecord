SELECT a.Name, COUNT(b.BookID) AS NumberOfBooks, SUM(b.Cost) AS TotalValue
FROM authors a
JOIN author_of_book ab ON a.AuthorID = ab.authors_AuthorID
JOIN books b ON ab.books_BookID = b.BookID
GROUP BY a.AuthorID, a.Name
ORDER BY NumberOfBooks DESC
LIMIT 1;
