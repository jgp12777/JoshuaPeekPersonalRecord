SELECT YEAR(b.YearPublished) AS Year, COUNT(b.BookID) AS NumberOfBooks
FROM books b
GROUP BY YEAR(b.YearPublished)
ORDER BY NumberOfBooks DESC
LIMIT 1;