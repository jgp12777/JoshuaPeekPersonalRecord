select 
books.Genre, Count(*) as total_books
From 
books
group by 
books.Genre 
