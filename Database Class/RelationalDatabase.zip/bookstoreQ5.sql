SELECT b.Publisher, COUNT(DISTINCT a.AuthorID) AS NumberOfAuthors
FROM books b
JOIN author_of_book ab ON b.BookID = ab.books_BookID
JOIN authors a ON ab.authors_AuthorID = a.AuthorID
GROUP BY b.Publisher;
