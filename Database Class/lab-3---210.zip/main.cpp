#include <iostream>
#include <ctime>
#include <cstdlib>
using namespace std;

int main()
{
    srand(time(NULL));
    int arr[10];
    
    for (int i = 0; i < 10; i++){
        arr[i] = rand() % 20;
    }
    for(int i = 0; i < 10; i++){
        printf("%d  ", arr[i]);
    }
    cout << endl;
    //print the array using only the pointer arrPtr
    //use pointer arithmetic
    int*arrPtr = arr; // initialize arrPtr with the address of the first element of arr

    for (int i = 0; i < 10; i++){  // use pointer arithmetic to access array elements
        cout << *(arrPtr + i) << " ";
    }
}

